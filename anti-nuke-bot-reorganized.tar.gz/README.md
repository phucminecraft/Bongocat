# Anti-Nuke Bot (discord.js v14)

Bot bảo vệ server chống mass-nuke + moderation/automod: phát hiện một tài khoản thực hiện quá nhiều hành động phá hoại trong thời gian ngắn, tự động cách ly/ban/kick kẻ đó, hoàn tác thiệt hại và khôi phục cấu trúc server.

> Bản này đã được rà soát toàn bộ và viết lại phần lõi. Danh sách lỗ hổng logic đã tìm thấy và cách sửa nằm trong **[AUDIT.md](AUDIT.md)**.

## 28 module được giám sát

Mass Bans, **Mass Kicks**, **Member Prune**, Mass Timeouts, Mass Role Adds/Removes, Mass Channel Creation/Deletion/Updates, Mass Category Creation/Deletion, Mass Thread Creation/Deletion, Mass Role Creation/Deletion/Updates, Mass Permission Changes, Mass Webhook Creation/Deletion, Mass Emoji Creation/Deletion, Mass Sticker Creation/Deletion, Mass Invite Creation, Mass Integration Changes, Mass Bot Invites, Server Setting Changes, và **Dangerous Privilege Grants** (in đậm = mới).

Mỗi module có 3 tham số chỉnh được: **limit** (số hành động *kích hoạt*: đạt đến mức này trong cửa sổ thời gian là bị xử lý, vd limit 3 → hành động thứ 3 kích hoạt), **thời gian** (1 giây – 24 giờ), **hình phạt** (`ban`, `kick`, `timeout` ~28 ngày, hoặc `strip` — chỉ gỡ role nguy hiểm).

### Dangerous Privilege Grants (mới, bật mặc định)
Người **không nằm trong whitelist** mà (a) cấp cho ai đó một role có quyền nguy hiểm (Administrator, Manage Roles/Channels/Guild, Ban/Kick Members…) hoặc một role đang được whitelist, hoặc (b) thêm quyền nguy hiểm vào một role → bot **hoàn tác ngay lập tức** (gỡ role vừa cấp / trả quyền cũ cho role) rồi xử lý người đó. Chặn kiểu tấn công "nâng quyền tài khoản phụ từng chút một" mà ngưỡng đếm theo thời gian không bắt được. Nếu server của bạn có mod **không whitelist** thường xuyên cấp role quyền cao, hãy whitelist họ hoặc tắt: `/antinuke toggle module:privilegeEscalation state:false`.

## Cách phát hiện

Bot nghe **một** nguồn duy nhất: sự kiện gateway `guildAuditLogEntryCreate` — Discord đẩy dòng audit log kèm người thực hiện ngay khi hành động xảy ra. Không còn kiểu "nghe event → chờ 300ms → tra audit log" như bản cũ (chậm, bỏ sót, và từng phạt nhầm người vô tội). Cần quyền **View Audit Log** và intent `GuildModeration`.

## Cài đặt

```bash
npm install
cp .env.example .env
```

Điền vào `.env`:
- `DISCORD_TOKEN` — token bot, lấy tại Discord Developer Portal.
- `CLIENT_ID` — application ID của bot.
- `GUILD_ID` — để trống nếu muốn deploy global; điền ID server để test nhanh (slash command cập nhật tức thì).

Trong Developer Portal, mục **Bot**, bật **Server Members Intent** và **Message Content Intent** (2 intent có giới hạn/privileged). Thiếu Server Members Intent thì bot không nhận diện được thành viên/role khi kiểm tra whitelist và khôi phục role; thiếu Message Content Intent thì automod không đọc được nội dung tin nhắn. Các intent Webhooks/Emojis/Invites/Integrations **không còn cần** (giảm lượng sự kiện gateway).

Mời bot vào server với quyền **Administrator** (khuyến nghị) hoặc tối thiểu: **View Audit Log (bắt buộc)**, Ban Members, Kick Members, Moderate Members, Manage Roles, Manage Channels, Manage Webhooks, Manage Guild, Manage Emojis and Stickers, Manage Threads. **Role của bot phải nằm trên mọi role có quyền nguy hiểm** — nếu không, bot không gỡ/cấm được người giữ chúng. `/antinuke status` có mục **Sức khỏe** cảnh báo thiếu quyền / role bot quá thấp / chưa đặt kênh log; bot cũng ghi cảnh báo ra console khi khởi động.

```bash
npm run deploy
npm start
npm test        # 136 test, chạy hoàn toàn offline (dùng bản giả lập discord.js), không cần token
```

## 3 cách gọi lệnh: slash / prefix / tag bot

Mọi lệnh (`/ban`, `/automod ...`, `/antinuke ...`, v.v.) đều gọi được bằng **cả 3 cách** — cùng một logic xử lý, cùng một cơ chế phân quyền, chỉ khác cách gõ:

1. **Slash command**: `/ban user:@ai reason:spam` — cách chuẩn, có gợi ý tham số trên Discord.
2. **Prefix**: gõ thẳng trong kênh chat, vd `!ban @ai 7d spam`. Prefix mặc định là `!`, đổi bằng `/prefix set text:?` (tối đa 5 ký tự, hoặc `text:off` để tắt hẳn prefix). Xem lại prefix hiện tại bằng `/prefix show`.
3. **Tag bot**: `@TênBot ban @ai 7d spam` — luôn hoạt động bất kể prefix đang bật/tắt.

Cách gõ tham số cho prefix/tag bot — theo **thứ tự** khai báo của lệnh (`ban @ai 7d bị report spam` → user, duration, reason theo đúng thứ tự) hoặc gọi **tên** (`ban user:@ai reason:bị report spam duration:7d`, thứ tự tùy ý, giá trị kéo dài tới tên tham số kế tiếp nên không cần ngoặc kép). Có thể trộn cả hai. Lệnh có subcommand/nhóm thì gõ tiếp theo tên lệnh, giống hệt cấu trúc slash: `!automod voice set kind:mute count:5 seconds:20`. Gõ `!help` hoặc `@TênBot help` để xem danh sách lệnh ngay trong Discord.

Quyền hạn xử lý **giống hệt slash command**: mỗi lệnh tự kiểm tra lại quyền của người gọi (không chỉ dựa vào việc Discord ẩn lệnh trên UI), nên ai không đủ quyền gõ prefix/tag cũng bị từ chối y như thiếu quyền dùng slash command.

Gõ prefix (vd chỉ mỗi `!`) mà không khớp lệnh nào thì bot **im lặng bỏ qua** (tránh làm phiền chat thường); nhưng tag thẳng bot mà gõ sai/lệnh không tồn tại thì bot **có phản hồi hướng dẫn**, vì mention là tín hiệu rõ ràng muốn gọi bot.

## Phân quyền `/antinuke`

Bản cũ chỉ dựa vào quyền mặc định "Administrator" của Discord — mà **bất kỳ admin nào** (chính là mối đe dọa của anti-nuke) đều tự thêm mình vào whitelist hoặc tắt module được. Nay:

| Nhóm | Ai dùng được |
|---|---|
| Chỉ xem: `status`, `whitelist list`, `owners list`, `backup status` | Administrator, chủ server, người được ủy quyền |
| Mọi lệnh thay đổi (`setup`, `config`, `toggle`, `whitelist …`, `backup now/interval`, `restore`, `unstrip`) | **Chủ server** + người được ủy quyền |
| `owners add/remove` (ủy quyền cho người khác) | **Chỉ chủ server** |

## Lệnh `/antinuke`

- `/antinuke setup channel:#log` — đặt kênh nhận cảnh báo. Nếu chưa đặt / kênh gửi lỗi, cảnh báo được **DM cho chủ server** (bản cũ im lặng bỏ qua).
- `/antinuke config module:<gõ để tìm> limit amount unit punishment` — chỉnh ngưỡng từng module (dùng autocomplete vì có hơn 25 module, vượt giới hạn 25 lựa chọn của Discord).
- `/antinuke toggle module state` — bật/tắt module.
- `/antinuke whitelist add-user|remove-user|add-role|remove-role|add-bot|remove-bot|list`.
- `/antinuke owners add|remove|list` — ủy quyền cấu hình anti-nuke (chỉ chủ server).
- `/antinuke unstrip user:<...>` — hoàn trả role đã bị bot gỡ nhầm (bot ghi nhớ tối đa 100 người gần nhất).
- `/antinuke status` — cấu hình + kiểm tra sức khỏe.
- `/antinuke backup now|status|interval`, `/antinuke restore confirm:true [snapshot:<số>]` — xem mục khôi phục.

Chủ server, người được ủy quyền và chính bot luôn được miễn trừ.

## Cơ chế phản ứng

Khi một tài khoản đạt ngưỡng:
1. **Cách ly** theo thang leo thang. `ban` cấm theo ID (kể cả khi người đó đã rời server). `strip` gỡ mọi role nguy hiểm gỡ được; nếu còn role không gỡ được (cao hơn bot / role của bot) thì **tự leo thang lên kick**. Nếu kẻ tấn công là **bot** (role managed, không gỡ được) thì `strip`/`timeout` được đổi thành `kick`. Cảnh báo ghi trung thực "Đã vô hiệu hóa: KHÔNG" khi mọi cách đều thất bại — bản cũ báo thành công dù không làm được gì.
2. **Hoàn tác** thiệt hại (song song với cảnh báo, không chờ gửi tin xong): unban nạn nhân, gỡ timeout, trả/gỡ role, trả lại giá trị cũ của role/kênh bị sửa, trả lại (hoặc xóa) permission overwrite của kênh bị sửa/tạo/xóa, xóa kênh/role/emoji/webhook/invite/thread mà kẻ tấn công vừa tạo, kick bot lạ, và khôi phục kênh/category/role bị xóa.
3. **Cách ly 2 phút**: mọi hành động *đến muộn* của người đó (đang bay trên đường truyền lúc bị phạt) bị hoàn tác ngay, không cần chờ đủ ngưỡng lần nữa. Xử lý đồng bộ nên nhiều sự kiện đến cùng lúc chỉ xử phạt đúng 1 lần.
4. **Đóng băng snapshot** 30 phút để trạng thái server đang bị phá không bị chụp làm bản "tốt".

Không tự hoàn tác được (chỉ cảnh báo): Mass Kick, Member Prune, đổi cài đặt server, xóa webhook/emoji/sticker/thread.

## Khôi phục toàn diện (backup / restore)

Snapshot lưu tại `data/guilds/<guildId>.snapshot.json`, gồm **ID thật**, tên, quyền, permission overwrite của mọi role/kênh/category, cùng danh sách thành viên của từng role.

- **Lịch sử tối đa 6 snapshot khác nhau** (không còn ghi đè 1 file duy nhất): snapshot mới trùng trạng thái cũ chỉ cập nhật thời gian, không nhân bản.
- **Chống "đầu độc" snapshot**: nếu số role+kênh tụt xuống dưới 70% bản trước, snapshot mới bị đánh dấu **NGHI VẤN** và `restore` mặc định bỏ qua nó; trạng thái nghi vấn không tự "sạch" chỉ vì chụp lại nhiều lần (24 giờ hoặc chủ server chụp tay bằng `backup now` mới xác nhận là tốt). Snapshot cũng bị **đóng băng** khi đang bị tấn công.
- `/antinuke restore confirm:true [snapshot:N]` (N=1 là mới nhất, xem số bằng `backup status`): đối chiếu **theo ID trước, rồi theo tên từng cái một** → không tạo trùng, xử lý đúng kênh trùng tên, kênh bị đổi tên không bị tạo thêm bản sao; tạo lại category trước rồi gắn lại kênh con mồ côi; permission overwrite trỏ tới role **mới** (không phải ID cũ đã chết); role được gắn lại cho từng thành viên (chạy nền, có báo cáo vào kênh log). Chạy lại nhiều lần an toàn (idempotent) và các lượt chạy chồng nhau được xếp hàng theo từng server.
- Kênh/role do **người tin cậy chủ động xóa** không bị "hồi sinh".
- Danh sách thành viên chỉ lưu khi cache thành viên đầy đủ và server ≤ 50.000 thành viên; ngoài ra restore vẫn tạo lại role nhưng không gán lại thành viên.

Giới hạn: role/kênh tạo lại có ID mới (mention/link cũ không tự cập nhật); vị trí chỉ khôi phục gần đúng; permission overwrite cho từng thành viên chỉ giữ với thành viên còn trong server; lịch sử tin nhắn trong kênh đã xóa không thể phục hồi.

## Lệnh moderation (`/ban /kick /mute /unmute /timeout /unban`)

Các lệnh này độc lập với hệ thống anti-nuke nhưng dùng chung project để tiện quản lý:

- Mỗi lệnh yêu cầu đúng quyền Discord gốc tương ứng (`Ban Members`, `Kick Members`, `Moderate Members`) qua `setDefaultMemberPermissions` — Discord tự ẩn lệnh khỏi người không đủ quyền, không cần bước kiểm tra nào tốn thời gian phía bot. Ngoài ra bot vẫn re-check quyền và **thứ bậc role** (không thể ban/kick/timeout người có role cao hơn hoặc bằng mình, không thể động vào chủ server) để tránh lạm dụng nếu admin chỉnh lại quyền mặc định của lệnh.
- Không có bước tra audit log nào trong lệnh (khác với anti-nuke) — người thực hiện chính là người gõ lệnh, nên gọi thẳng API rồi phản hồi ngay, không có độ trễ nhân tạo.
- `/mute` dùng role "Muted" tự tạo (deny gửi tin/nói ở mọi kênh) — khác `/timeout` (giới hạn 28 ngày của Discord) ở chỗ mute không tự hết hạn, phải `/unmute` thủ công.
- **Tương thích với anti-nuke**: audit log chỉ ghi "bot" là người thực hiện (mà bot luôn được miễn trừ), nên `/ban /kick /timeout /mute` báo thẳng cho anti-nuke với **danh tính moderator ra lệnh**. Mod nào không trong whitelist mà ban/kick/timeout hàng loạt qua bot vẫn bị đếm vào ngưỡng Mass Ban / Mass Kick / Mass Timeout, bị xử lý và nạn nhân được hoàn tác. (Bản cũ đánh dấu "tin cậy" cho hành động đó nên **bất kỳ ai có quyền Ban Members đều nuke được qua bot**.) Mod hay dọn raid nên được **whitelist**. Hành động của chính automod/timer không bị tính.

Cần chạy lại `npm run deploy` sau khi cập nhật để Discord nhận các slash command mới.

## Automod (`/automod`)

- **Lọc từ** (`/automod words add|remove|list|mode|toggle`): hỗ trợ wildcard `*` (vd `fuck*` khớp `fucking`), chế độ khớp nguyên từ (mặc định, tránh cấm nhầm như "class" chứa "ass") hoặc khớp một phần.
- **Chặn invite server khác** (`/automod invites toggle|allow`): phát hiện link `discord.gg/...`, tra ngược xem invite đó dẫn tới đúng server mình không (cache 10 phút để đỡ tốn API), cho phép whitelist theo guild ID.
- **Chống spam ký tự lặp** (`/automod characters toggle|set`): 1 tin gần như chỉ gồm 1 ký tự lặp lại (vd `"aaaaaaaaaa"`, `"!!!!!!!!!!!"`) bị chặn **ngay tin đầu tiên**, không cần đợi gửi nhiều tin (khác rule Chống spam bên dưới, vốn tính theo tần suất). Đạt 1 trong 2 điều kiện là đủ: ký tự giống nhau lặp liên tiếp ≥ `min_run` (mặc định 10), hoặc 1 ký tự chiếm ≥ `min_ratio_percent`% cả tin (mặc định 70%, không cần liên tiếp). Chỉ xét tin dài ≥ `min_length` ký tự (mặc định 12) để tránh cấm nhầm tin ngắn kiểu "ok", "hihi". Mặc định **tắt** (dễ bắt nhầm kiểu gõ đùa "hahaha") — admin tự bật khi cần.
- **Chống spam & flood** (`/automod spam set|off|toggle|builtin`): đếm theo cửa sổ trượt cho 17 loại nội dung khác nhau, xem bảng chi tiết bên dưới.
- **Thread Spam** (`/automod threads toggle|set`): tạo thread liên tục trong thời gian ngắn.
- **Reaction Spam** (`/automod reactions toggle|set`): 1 người thả reaction nhanh hơn tốc độ bấm thật của con người (thường là script/macro).
- **Voice Protection** (`/automod voice toggle|log|set|off`): tương tự cơ chế chống spam tin nhắn nhưng cho **kênh thoại** — xem chi tiết ở mục riêng bên dưới.
- **Hình phạt & xoá tin** (`/automod punish`, `/automod delete`): mỗi rule (words/invites/characters/spam/threads/reactions/voice) tự chọn hình phạt riêng (none/warn/timeout/mute/kick/ban/**disconnect**) và có "xoá" hay không khi vượt ngưỡng — với threads là xoá thread, với reactions là gỡ các reaction vi phạm, với voice thì không áp dụng (không có gì để xoá). `disconnect` chỉ ngắt khỏi kênh thoại hiện tại, không timeout/kick khỏi server — nhẹ hơn `timeout` nhưng cũng không ngăn tham gia lại ngay.
- **Miễn trừ** (`/automod exempt`): theo role hoặc theo kênh — áp dụng cho **mọi** rule ở trên, kể cả Thread Spam (tính theo kênh cha của thread) và Reaction Spam (tính theo kênh chứa tin được react); Administrator/Manage Server/Manage Messages/Manage Channels luôn được miễn trừ mặc định, kể cả chủ server.
- Tin nhắn bị sửa cũng được quét lại cho words/invites/characters (dựa trên nội dung); riêng spam thì không, vì tính theo tần suất gửi chứ không theo nội dung sửa.

### Keyword & Phrase Filters (`/automod keyword`) — 26 rule lọc nội dung mới

Bổ sung cho **Lọc từ** (Bad Words) và **Chặn invite** ở trên. Vì Discord chỉ cho tối đa **25 lựa chọn tĩnh** mỗi option, tham số `rule` của toàn bộ lệnh dưới đây (kể cả `/automod punish` và `/automod delete`, nay cũng gộp chung) dùng **autocomplete** (gõ vài chữ để tìm) thay vì danh sách chọn sẵn — giống hệt cách `/antinuke config module` xử lý 28 module.

```
/automod keyword add    rule:<...> value:<...> [mode:native|js]   # them 1 muc (tu/domain/pattern/cum bat buoc)
/automod keyword remove rule:<...> value:<...>                    # xoa 1 muc
/automod keyword list   rule:<...>                                 # xem danh sach hien tai (chi ban thay)
/automod keyword toggle rule:<...> enabled:true|false             # bat/tat 1 rule
/automod keyword mode   rule:<...> whole_word:true|false          # chi rule dang danh sach tu
/automod keyword channel rule:requiredPhrases action:add|remove channel:<#kenh>
```

**Nguồn danh sách từ** — đọc kỹ trước khi tự thêm nội dung nhạy cảm vào bất kỳ rule nào:

| Nhóm | Rule | Nguồn danh sách |
| --- | --- | --- |
| Preset của Discord (không có danh sách riêng, chỉ `toggle`) | `profanity`, `slurs`, `sexualContent` | Bật = bot tạo 1 **AutoMod rule thật của Discord** (`KeywordPreset`) — Discord tự duy trì và chặn **trước khi tin tới bot**. Cần quyền **Manage Server**. |
| Danh sách trống, server tự nhập | `racism`, `hateSpeech`, `harassment`, `bullying`, `threats`, `selfHarm`, `swearing`, `nsfw` | Không seed sẵn nội dung nhạy cảm/thù ghét/tự hại — nhất là Harassment/Bullying/Threats vốn phụ thuộc ngữ cảnh rất nhiều, khớp từ khoá đơn thuần dễ báo động giả/sót; nên kết hợp kênh #report + người kiểm duyệt thật. |
| Có seed sẵn (nội dung công khai, không nhạy cảm) | `scam`, `phishing`, `cryptoScam`, `advertisement` | Vài cụm lừa đảo/quảng cáo rất phổ biến (`free nitro`, `verify your account`...) — hoạt động ngay khi bật, server tự bổ sung thêm. |
| Danh sách chung server tự định nghĩa | `customKeywords` (khớp **chính xác**, `*` là ký tự thường), `wildcardKeywords` (hỗ trợ `*`, xem lưu ý bên dưới), `blockedPhrases` (cụm nhiều chữ, khớp chính xác) | — |

**Self-Harm Keywords** (`selfHarm`) mặc định **không xoá tin, không tự xử phạt** (`notifyStaff`) — chỉ gửi 1 embed **riêng** vào kênh log để staff chủ động liên hệ, tuyệt đối không gọi tên/ping công khai trong kênh chat. Đây là rule duy nhất có `notifyStaff:true`.

**Wildcard `*`** trong `wildcardKeywords` (và `words` cũ) chỉ thay thế cho 1 chuỗi ký tự chữ/số **liền nhau trong cùng 1 từ** (vd `free*nitro` khớp `freeggnitro`) — **không** vượt qua khoảng trắng để khớp nhiều từ cách nhau; muốn khớp cụm nhiều từ, dùng `blockedPhrases`.

**Cấu trúc/liên kết:**

| Rule | Cơ chế |
| --- | --- |
| `urls` | Chặn **mọi** link `http(s)` trừ domain trong `allowDomains` (mô hình allow-list) |
| `domainBlacklist` | Ngược lại `urls`: chỉ chặn domain có trong danh sách, còn lại cho qua (mô hình blacklist) |
| `ipAddresses` | Địa chỉ IPv4/IPv6 (best-effort, không phải validator RFC đầy đủ) |
| `emailAddresses` | Địa chỉ email |
| `phoneNumbers` | Ưu tiên số có dấu ngăn cách; số gõ liền 9-11 chữ số cũng bắt được nhưng dễ báo động giả (mã đơn hàng, mã xác nhận...) — không nhầm với ID Discord (17-19 số) |

**Regex Filters** (`regexFilters`, `add ... mode:native|js`) — 2 chế độ:
- `native` (**khuyến nghị**, mặc định): Discord tự biên dịch + chạy bằng engine Rust của họ — **không hỗ trợ lookaround/backreference** (chủ đích, để đảm bảo thời gian chạy luôn tuyến tính) nên **không có rủi ro ReDoS**. Tối đa 10 pattern/rule, mỗi pattern ≤ 260 ký tự (giới hạn thật của Discord).
- `js`: chạy tại bot bằng engine JS thường (có backtracking). Bị chặn nested-quantifier/backreference/lookaround **trước khi lưu** (cùng giới hạn với chế độ native, để pattern dùng được cho cả 2 chế độ) và giới hạn độ dài văn bản đưa vào khi chạy thật — giảm rủi ro ReDoS nhưng không phải chứng minh toán học tuyệt đối, chỉ dùng khi native không đáp ứng được (vượt 10 pattern, cần lookaround...).

**Required Phrases** (`requiredPhrases`) — ngược hướng với mọi rule khác: trong các kênh đã gán qua `keyword channel`, tin nhắn **phải chứa** 1 trong các cụm đã khai báo (vd mẫu đơn ứng tuyển), thiếu thì bị coi là vi phạm. **Keyword Whitelist** (`whitelist`) — 1 cụm khớp là miễn trừ **toàn bộ** rule "từ khoá" (words + 26 rule ở trên + Required Phrases) cho tin đó, nhưng **không** miễn trừ invites/characters/spam (khác bản chất).



Cơ chế cửa sổ trượt dùng chung cho mọi loại: 1 tin "quá ngưỡng" một mình (vd 1 tin dính 50 emoji) và nhiều tin nhỏ gộp lại trong 1 khoảng thời gian (vd 5 tin × 3 emoji) đều bị phát hiện như nhau. `/automod spam set kind:<...> count:<n> seconds:<n>` để bật/đổi ngưỡng 1 loại, `/automod spam off kind:<...>` để tắt riêng loại đó.

| `kind` | Bắt gì | Mặc định |
| --- | --- | --- |
| `messages` | Tin nhắn liên tục (rate limit thêm, ngoài built-in bên dưới) | 6 tin / 5s |
| `duplicates` | Tin trùng lặp nội dung | 3 tin / 30s |
| `rapidMessages` | Spam quá nhanh kiểu bot/script (ngưỡng riêng, tách khỏi `messages`) | tắt |
| `mentions` | Mention người + role + @everyone/@here gộp lại | 6 lần / 10s |
| `roleMentions` | Chỉ mention role | tắt |
| `everyoneMentions` | Chỉ `@everyone` | tắt |
| `hereMentions` | Chỉ `@here` | tắt |
| `links` | Link thường | tắt |
| `inviteLinks` | Link mời server, bất kể dẫn tới server nào (khác rule **Chặn invite server khác** ở trên — rule đó chặn link mời tới server *lạ* ngay lập tức; `inviteLinks` chỉ đếm *tần suất* gửi link mời, kể cả invite của chính server) | tắt |
| `emojis` | Emoji (custom + unicode), 1 tin nhiều emoji hoặc nhiều tin liên tiếp | tắt |
| `stickers` | Sticker | tắt |
| `gifs` | Link/ảnh GIF (Tenor, Giphy, file `.gif`) | tắt |
| `attachments` | File đính kèm bất kỳ | tắt |
| `images` | Riêng ảnh (theo content-type hoặc đuôi file) | tắt |
| `videos` | Riêng video | tắt |
| `embeds` | Tin có rich embed | tắt |
| `polls` | Poll | tắt |

**Spam Content built-in của Discord** (`/automod spam builtin enabled:true|false`): độc lập hoàn toàn với bảng trên — tạo/xoá 1 AutoMod rule **gốc của Discord** (loại `Spam`, dùng ML của Discord để chặn nội dung spam chung chung), hoạt động ngay cả khi bot offline. Discord chỉ cho tối đa 1 rule loại này mỗi server (lệnh tự kiểm tra, không tạo trùng); cần bot có quyền **Manage Server**, nếu thiếu quyền lệnh sẽ báo lỗi rõ ràng thay vì âm thầm thất bại.

### Thread Spam & Reaction Spam

- **`/automod threads toggle|set count:<n> seconds:<n>`** — mặc định 3 thread / 30s, tắt sẵn. Vượt ngưỡng: xoá hết các thread đã tạo trong đợt vi phạm + xử phạt người tạo (mặc định timeout 10 phút).
- **`/automod reactions toggle|set count:<n> seconds:<n>`** — mặc định 12 reaction / 8s, tắt sẵn. Vượt ngưỡng: gỡ hết các reaction đã thả trong đợt vi phạm (tắt bằng `/automod delete rule:reactions enabled:false` nếu chỉ muốn xử phạt mà không gỡ) + xử phạt.
- Cả hai không đi qua sự kiện `messageCreate` nên không dùng chung mã với bộ lọc tin nhắn ở trên; Reaction Spam cần intent **`GUILD_MESSAGE_REACTIONS`** (intent thường, không cần bật riêng trong Developer Portal, chỉ cần khai báo trong code — đã có sẵn); Thread Spam không cần intent nào ngoài `GUILDS` đã bật sẵn.

### Voice Protection (`/automod voice`)

Chống các hành vi gây khó chịu trong kênh thoại, dùng đúng cơ chế cửa sổ trượt như chống-spam-tin-nhắn nhưng áp cho 7 loại hành vi riêng (`/automod voice set kind:<...> count:<n> seconds:<n>`, `/automod voice off kind:<...>` để tắt từng loại):

| Loại (`kind`) | Hành vi | Mặc định |
| --- | --- | --- |
| `joinLeave` | Vào/ra kênh thoại liên tục | 6 lần / 30s |
| `channelSwitch` | Nhảy qua lại nhiều kênh ("VC hopping") | 5 lần / 30s |
| `camera` | Bật/tắt camera liên tục | 6 lần / 30s |
| `screenshare` | Bật/tắt chia sẻ màn hình liên tục | 6 lần / 30s |
| `mute` | Bật/tắt mic liên tục | 8 lần / 20s |
| `deafen` | Bật/tắt chế độ deafen liên tục | 8 lần / 20s |
| `soundboard` | Spam soundboard | 5 lần / 20s |

Hai lớp hoạt động **độc lập**, bật/tắt riêng bằng `/automod voice toggle` (đếm ngưỡng + xử phạt) và `/automod voice log` (ghi log):

- **Ghi log làm bằng chứng**: mỗi lần vào/ra/đổi kênh, bật camera, bắt đầu chia sẻ màn hình đều được ghi vào kênh log ngay lập tức (không cần chờ vượt ngưỡng), để admin xem lại được dù không có mặt trực tiếp lúc xảy ra. Riêng mic/deafen **không** ghi log từng lần (đa số người dùng bấm mic thật/PTT liên tục, ghi mỗi lần sẽ làm spam kênh log) — chỉ xuất hiện khi vượt ngưỡng.
- **Xử phạt khi vượt ngưỡng**: áp dụng `cfg.voice.punish` (mặc định `timeout` 10 phút — vừa ngắt khỏi kênh thoại hiện tại vừa ngăn tham gia lại trong thời hạn đó); có thể đổi sang `disconnect` nếu chỉ muốn ngắt nhẹ.

**Giới hạn cần biết riêng cho soundboard**: theo tài liệu gateway của Discord, sự kiện dùng để phát hiện soundboard (`voiceChannelEffectSend`) chỉ được gửi tới bot khi bot **đang ở trong kênh thoại đó** — khác các loại còn lại (vốn nhận được cho toàn server chỉ cần bot có mặt trong server, không cần đang nói chuyện). Bot này không tự động vào kênh thoại nào, nên theo dõi soundboard hiện chưa có tác dụng thực tế trừ khi bot được mở rộng để tham gia voice. Bot cũng không thể "cắt" hay đo độ to của âm thanh đang phát — việc đó cần kết nối audio thật sự (vd `@discordjs/voice` + xử lý PCM/opus), ngoài phạm vi một bot kiểm duyệt chỉ dựa trên dữ liệu văn bản/gateway như bot này.

Cần bật intent **`GUILD_VOICE_STATES`** trong Developer Portal (Bot → Privileged Gateway Intents không yêu cầu, đây là intent thường) để Voice Protection nhận được sự kiện.

## Cases — lịch sử moderator

Mọi hành động (`/ban /kick /mute /timeout /warn` và automod tự động phạt) đều sinh ra một **case** đánh số tăng dần, lưu tại `data/mod/<guildId>.json`:

- `/cases [user] [page]` — liệt kê case, mới nhất trước, lọc theo người dùng nếu cần.
- `/case view id:<n>` — xem chi tiết 1 case (kèm ghi chú nếu có).
- `/case reason id:<n> text:<...>` — sửa lại lý do.
- `/case note id:<n> text:<...>` — thêm ghi chú nội bộ vào case có sẵn; `/note user:<...> text:<...>` để tạo case dạng ghi chú độc lập (không cần vi phạm gì).
- `/warn user:<...> reason:<...>` — cảnh cáo, chỉ ghi case, không tác động Discord.

Mỗi case tự động gửi embed vào kênh log (`/automod logchannel #kênh`) nếu đã cấu hình.

## Mute và slowmode do bot quản lý

- `/mute` dùng role **Muted** tự tạo (deny gửi tin/nói ở mọi kênh khi tạo lần đầu, kênh tạo sau đó cũng tự được chặn) — khác `/timeout` (giới hạn 28 ngày của Discord) ở chỗ không tự hết hạn nếu không đặt `duration`, và **giữ nguyên khi rời rồi vào lại server** (chống lách mute bằng leave/rejoin).
- `/slowmode set duration:<...>` — nếu ≤ 6 giờ, dùng slowmode gốc của Discord; nếu dài hơn (Discord không hỗ trợ), bot tự đặt slowmode gốc ở mức trần 6h rồi **tự cưỡng chế phần vượt trội**: theo dõi thời điểm gửi tin gần nhất của từng người, xoá tin nào gửi sớm hơn ngưỡng và nhắc nhở. Mod có quyền Manage Messages/Manage Channels không bị áp slowmode (giống hành vi gốc của Discord). `/slowmode off`, `/slowmode list` để quản lý.
- Cả timer tự unban/unmute (`/ban duration:` và `/mute duration:`) đều chạy nền, kiểm tra mỗi 5 giây, tự ghi case khi hết hạn.

## Giới hạn cần biết

Nếu kẻ tấn công có role ngang hàng hoặc cao hơn role của bot, hoặc chính là chủ server / có quyền qua `@everyone`, bot không thể gỡ role hay ban được — thứ bậc role quyết định giới hạn thực tế của mọi anti-nuke bot; `/antinuke status` sẽ cảnh báo tình huống này. Một tài khoản **được whitelist** hoặc **chủ server bị chiếm** không bị bot chặn (mô hình tin cậy của whitelist) — hãy giữ whitelist ngắn, bật 2FA cho mọi tài khoản có quyền cao, và cân nhắc dùng `owners` thay vì cấp Administrator rộng rãi. Anti-nuke chỉ giảm thiểu thiệt hại, không thay thế cho việc hạn chế quyền cấp cho người khác.

Prefix/tag-bot command suy luận tham số theo **vị trí** khi không gõ tên tham số — với lệnh có từ 2 chuỗi tự do trở lên (vd `ban` có cả `duration` lẫn `reason`), nếu chỉ gõ đúng 1 cụm từ mơ hồ (không rõ có phải định dạng thời hạn hay không, vd `!ban @ai spam`), bot ưu tiên gán cho tham số **cuối cùng** (thường là `reason`) thay vì tham số đứng trước nó, để tránh báo lỗi "thời hạn không hợp lệ" một cách khó hiểu. Muốn chắc chắn, gõ tên tham số tường minh: `duration:7d`.

Bản này đã được kiểm chứng bằng kiểm tra cú pháp và 136 test chạy trên **bản giả lập** discord.js; **chưa được chạy trên Discord thật** (môi trường phát triển không có mạng). Hãy thử trên một server thử nghiệm trước: tạo kênh/role rồi xóa hàng loạt bằng một tài khoản phụ không whitelist và xem kết quả.

Cấu hình anti-nuke lưu tại `data/guilds/<guildId>.json`, snapshot tại `data/guilds/<guildId>.snapshot.json`; cases/automod/mute/slowmode tại `data/mod/<guildId>.json`. File bị hỏng được **đổi tên thành `*.corrupt-<thời gian>`** (không bị ghi đè) để cứu dữ liệu. Ghi file dùng cơ chế ghi tạm rồi đổi tên (nguyên tử) nên mất điện giữa chừng không làm hỏng dữ liệu.
