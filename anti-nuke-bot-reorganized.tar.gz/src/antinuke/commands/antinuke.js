'use strict';
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType, MessageFlags } = require('discord.js');
const { MODULE_DEFS, MAX_WINDOW_MS, MIN_WINDOW_MS } = require('../config');
const storage = require('../storage');
const backup = require('../backup');
const engine = require('../engine');
const { sendAlert } = require('../logger');
const { checkHealth } = require('../health');

const EPH = MessageFlags.Ephemeral;

// > 25 module nen KHONG the dung addChoices (Discord gioi han 25 lua chon) -> dung autocomplete.
const moduleOption = (o) => o.setName('module').setDescription('Module').setRequired(true).setAutocomplete(true);

const data = new SlashCommandBuilder()
  .setName('antinuke')
  .setDescription('Cau hinh he thong Anti-Nuke')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .setDMPermission(false)
  .addSubcommand((sc) => sc.setName('status').setDescription('Xem trang thai cau hinh + kiem tra suc khoe Anti-Nuke'))
  .addSubcommand((sc) =>
    sc
      .setName('setup')
      .setDescription('Dat kenh nhan canh bao')
      .addChannelOption((o) => o.setName('channel').setDescription('Kenh nhan canh bao').addChannelTypes(ChannelType.GuildText).setRequired(true))
  )
  .addSubcommand((sc) =>
    sc
      .setName('toggle')
      .setDescription('Bat/tat mot module bao ve')
      .addStringOption(moduleOption)
      .addBooleanOption((o) => o.setName('state').setDescription('true = bat, false = tat').setRequired(true))
  )
  .addSubcommand((sc) =>
    sc
      .setName('config')
      .setDescription('Chinh nguong, thoi gian va hinh phat cho mot module')
      .addStringOption(moduleOption)
      .addIntegerOption((o) => o.setName('limit').setDescription('So hanh dong KICH HOAT (dat den muc nay la bi xu ly)').setRequired(true).setMinValue(1).setMaxValue(100))
      .addIntegerOption((o) => o.setName('amount').setDescription('Gia tri thoi gian').setRequired(true).setMinValue(1).setMaxValue(1000))
      .addStringOption((o) =>
        o
          .setName('unit')
          .setDescription('Don vi thoi gian')
          .setRequired(true)
          .addChoices({ name: 'Giay', value: 'seconds' }, { name: 'Phut', value: 'minutes' }, { name: 'Gio', value: 'hours' })
      )
      .addStringOption((o) =>
        o
          .setName('punishment')
          .setDescription('Hinh phat ap dung')
          .setRequired(true)
          .addChoices(
            { name: 'Ban (cam vinh vien)', value: 'ban' },
            { name: 'Kick (duoi khoi server)', value: 'kick' },
            { name: 'Timeout (~28 ngay)', value: 'timeout' },
            { name: 'Strip (chi go role nguy hiem)', value: 'strip' }
          )
      )
  )
  .addSubcommand((sc) =>
    sc
      .setName('restore')
      .setDescription('Khoi phuc toan dien channel/role tu snapshot (dung khi server bi nuke nang)')
      .addBooleanOption((o) => o.setName('confirm').setDescription('Xac nhan thuc hien khoi phuc (bat buoc = true)').setRequired(true))
      .addIntegerOption((o) => o.setName('snapshot').setDescription('Snapshot so may (1 = moi nhat). Bo trong = moi nhat khong nghi van').setMinValue(1).setMaxValue(10))
  )
  .addSubcommand((sc) =>
    sc
      .setName('unstrip')
      .setDescription('Hoan tra role da bi Anti-Nuke go nham cho mot nguoi')
      .addUserOption((o) => o.setName('user').setDescription('Nguoi can hoan tra role').setRequired(true))
  )
  .addSubcommandGroup((g) =>
    g
      .setName('backup')
      .setDescription('Quan ly snapshot dung de khoi phuc toan dien')
      .addSubcommand((sc) => sc.setName('now').setDescription('Chup snapshot ngay bay gio va coi la trang thai TOT'))
      .addSubcommand((sc) => sc.setName('status').setDescription('Xem lich su snapshot'))
      .addSubcommand((sc) =>
        sc
          .setName('interval')
          .setDescription('Dat khoang cach tu dong chup snapshot')
          .addIntegerOption((o) => o.setName('amount').setDescription('Gia tri thoi gian').setRequired(true).setMinValue(1).setMaxValue(1440))
          .addStringOption((o) =>
            o.setName('unit').setDescription('Don vi thoi gian').setRequired(true).addChoices({ name: 'Phut', value: 'minutes' }, { name: 'Gio', value: 'hours' })
          )
      )
  )
  .addSubcommandGroup((g) =>
    g
      .setName('whitelist')
      .setDescription('Quan ly danh sach mien tru')
      .addSubcommand((sc) => sc.setName('list').setDescription('Xem danh sach mien tru'))
      .addSubcommand((sc) => sc.setName('add-user').setDescription('Them nguoi dung vao whitelist').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true)))
      .addSubcommand((sc) => sc.setName('remove-user').setDescription('Xoa nguoi dung khoi whitelist').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true)))
      .addSubcommand((sc) => sc.setName('add-role').setDescription('Them role vao whitelist').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)))
      .addSubcommand((sc) => sc.setName('remove-role').setDescription('Xoa role khoi whitelist').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)))
      .addSubcommand((sc) => sc.setName('add-bot').setDescription('Them bot tin cay vao whitelist').addUserOption((o) => o.setName('bot').setDescription('Bot').setRequired(true)))
      .addSubcommand((sc) => sc.setName('remove-bot').setDescription('Xoa bot khoi whitelist').addUserOption((o) => o.setName('bot').setDescription('Bot').setRequired(true)))
  )
  .addSubcommandGroup((g) =>
    g
      .setName('owners')
      .setDescription('Nguoi duoc chu server uy quyen chinh cau hinh Anti-Nuke')
      .addSubcommand((sc) => sc.setName('list').setDescription('Xem danh sach'))
      .addSubcommand((sc) => sc.setName('add').setDescription('Uy quyen cho mot nguoi (chi chu server)').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true)))
      .addSubcommand((sc) => sc.setName('remove').setDescription('Thu hoi uy quyen (chi chu server)').addUserOption((o) => o.setName('user').setDescription('Nguoi dung').setRequired(true)))
  );

// ---------------------------------------------------------------- phan quyen
// Truoc day lenh chi dua vao setDefaultMemberPermissions(Administrator) -> day chi la mac dinh phia client, admin
// server doi duoc, va BAT KY admin nao (chinh la mo hinh de doa cua anti-nuke) deu tu them minh vao whitelist / tat module
// roi nuke thoai mai. Nay: thay doi cau hinh chi danh cho chu server + nguoi chu server uy quyen.
const READ_ONLY = new Set(['status', 'whitelist.list', 'owners.list', 'backup.status']);
const REAL_OWNER_ONLY = new Set(['owners.add', 'owners.remove']);

function authorize(i, config, key) {
  const isOwner = i.user.id === i.guild.ownerId;
  const isController = isOwner || config.extraOwners.includes(i.user.id);
  if (READ_ONLY.has(key)) return isController || i.memberPermissions?.has(PermissionFlagsBits.Administrator) ? null : 'Ban can quyen Administrator de xem muc nay.';
  if (REAL_OWNER_ONLY.has(key)) return isOwner ? null : 'Chi chu server moi duoc them/xoa nguoi duoc uy quyen.';
  return isController ? null : 'Chi chu server (hoac nguoi duoc chu server uy quyen bang `/antinuke owners add`) moi duoc thay doi cau hinh Anti-Nuke.';
}

// ---------------------------------------------------------------- tien ich
const say = (i, content) => (i.deferred || i.replied ? i.editReply({ content }) : i.reply({ content, flags: EPH }));
const unitToMs = (amount, unit) => amount * (unit === 'seconds' ? 1000 : unit === 'minutes' ? 60_000 : 3_600_000);
const fmtWindow = (ms) => (ms % 3_600_000 === 0 ? `${ms / 3_600_000}h` : ms % 60_000 === 0 ? `${ms / 60_000}m` : `${(ms / 1000).toFixed(0)}s`);
const requireModule = (key) => (Object.hasOwn(MODULE_DEFS, key) ? null : 'Module khong hop le.');

// ---------------------------------------------------------------- xu ly tung lenh
const handlers = {
  async status(i, config) {
    const health = checkHealth(i.guild, config);
    const embed = new EmbedBuilder()
      .setTitle('Trang thai Anti-Nuke')
      .setColor(health.ok ? 0x57f287 : 0xfaa61a)
      .setDescription(
        `Kenh log: ${config.logChannelId ? `<#${config.logChannelId}>` : 'Chua dat'}\n` +
          `Whitelist: ${config.whitelistedUsers.length} nguoi dung, ${config.whitelistedRoles.length} role, ${config.whitelistedBots.length} bot\n` +
          `Nguoi duoc uy quyen: ${config.extraOwners.length}`
      );
    const lines = Object.entries(config.modules).map(([key, m]) => `${m.enabled ? '[BAT]' : '[TAT]'} ${MODULE_DEFS[key].label} - ${m.limit} lan / ${fmtWindow(m.windowMs)} - ${m.punishment}`);
    for (let n = 0; n < lines.length; n += 8) embed.addFields({ name: n === 0 ? 'Module' : '​', value: lines.slice(n, n + 8).join('\n') });
    embed.addFields({ name: 'Suc khoe', value: health.ok ? 'Tot' : health.problems.map((p) => `- ${p}`).join('\n').slice(0, 1000) });
    return i.reply({ embeds: [embed], flags: EPH });
  },

  async setup(i, config) {
    const channel = i.options.getChannel('channel', true);
    if (!channel.permissionsFor(i.guild.members.me)?.has(PermissionFlagsBits.SendMessages)) return say(i, 'Bot khong co quyen gui tin vao kenh do.');
    config.logChannelId = channel.id;
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, `Kenh log Anti-Nuke: <#${channel.id}>`);
  },

  async toggle(i, config) {
    const key = i.options.getString('module', true);
    const bad = requireModule(key);
    if (bad) return say(i, bad);
    const state = i.options.getBoolean('state', true);
    config.modules[key].enabled = state;
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, `${MODULE_DEFS[key].label}: ${state ? 'BAT' : 'TAT'}`);
  },

  async config(i, config) {
    const key = i.options.getString('module', true);
    const bad = requireModule(key);
    if (bad) return say(i, bad);
    const limit = i.options.getInteger('limit', true);
    const amount = i.options.getInteger('amount', true);
    const unit = i.options.getString('unit', true);
    const punishment = i.options.getString('punishment', true);
    const windowMs = unitToMs(amount, unit);
    if (windowMs < MIN_WINDOW_MS || windowMs > MAX_WINDOW_MS) return say(i, 'Cua so thoi gian phai tu 1 giay den 24 gio.');
    config.modules[key] = { ...config.modules[key], limit, windowMs, punishment };
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, `${MODULE_DEFS[key].label} -> nguong ${limit} hanh dong / ${fmtWindow(windowMs)}, hinh phat: ${punishment}.`);
  },

  async restore(i) {
    if (!i.options.getBoolean('confirm', true)) return say(i, 'Huy: can dat `confirm: true` de thuc hien khoi phuc.');
    const index = i.options.getInteger('snapshot');
    const snap = backup.pickSnapshot(i.guild.id, index);
    if (!snap) return say(i, 'Chua co snapshot nao de khoi phuc tu do. Dung `/antinuke backup now` truoc.');
    await i.deferReply({ flags: EPH });
    const r = await backup.restoreAll(i.guild, { snapshotIndex: index, reason: `Anti-Nuke: khoi phuc thu cong boi ${i.user.tag}` });
    const config = storage.getGuildConfig(i.guild.id);
    if (r.membersTask) {
      r.membersTask.then((n) => sendAlert(i.guild, config, { title: 'Anti-Nuke: gan lai role cho thanh vien xong', description: `Da gan lai role cho **${n}/${r.membersQueued}** thanh vien.`, color: 0x57f287 })).catch(() => {});
    }
    return i.editReply(
      `Snapshot <t:${Math.floor(snap.takenAt / 1000)}:R>${snap.suspect ? ' (**NGHI VAN**)' : ''}: tao lai ${r.rolesCreated} role, ${r.categoriesCreated} category, ${r.channelsCreated} channel, gan lai category cho ${r.reparented} kenh` +
        (r.membersQueued ? `; dang gan role cho ${r.membersQueued} thanh vien (chay nen, se bao vao kenh log)` : '') +
        (r.errors ? ` (${r.errors} muc loi, xem log console).` : '.')
    );
  },

  async unstrip(i, config) {
    const user = i.options.getUser('user', true);
    const rec = config.strippedRoles[user.id];
    if (!rec) return say(i, 'Khong co du lieu role da bi go cua nguoi nay.');
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    if (!member) return say(i, 'Nguoi nay khong con trong server.');
    const roles = rec.roleIds.filter((id) => i.guild.roles.cache.get(id)?.editable);
    if (roles.length) await member.roles.add(roles, `Anti-Nuke: hoan tra role boi ${i.user.tag}`);
    storage.takeStripped(i.guild.id, user.id);
    engine.quarantine.delete(`${i.guild.id}:${user.id}`); // ngung cach ly de khong bi phat lai ngay
    return say(i, `Da hoan tra ${roles.length}/${rec.roleIds.length} role cho <@${user.id}>. Nen them nguoi nay vao whitelist neu la nguoi tin cay.`);
  },

  async 'backup.now'(i) {
    await i.deferReply({ flags: EPH });
    const res = await backup.takeSnapshot(i.guild, { force: true });
    if (!res.snapshot) return i.editReply(`Khong chup duoc snapshot (${res.reason || res.status}).`);
    const s = res.snapshot;
    return i.editReply(`Da chup snapshot: ${s.roles.length} role, ${s.channels.length} channel/category${s.roleMembers ? '' : ' (khong kem danh sach thanh vien cua role: cache thanh vien chua day du)'}.`);
  },

  async 'backup.status'(i) {
    const list = backup.listSnapshots(i.guild.id);
    if (!list.length) return say(i, 'Chua co snapshot nao. Dung `/antinuke backup now` de tao ngay.');
    const lines = list.map((s, n) => `**#${n + 1}** <t:${Math.floor(s.takenAt / 1000)}:R> - ${s.roles.length} role, ${s.channels.length} channel${s.suspect ? ' - **NGHI VAN**' : ''}${s.roleMembers ? '' : ' - khong kem thanh vien'}`);
    const note = backup.isFrozen(i.guild.id) ? '\nDang DONG BANG chup tu dong (phat hien hanh dong pha hoai gan day).' : '';
    return say(i, `${lines.join('\n')}${note}`);
  },

  async 'backup.interval'(i, config) {
    const amount = i.options.getInteger('amount', true);
    const unit = i.options.getString('unit', true);
    config.snapshotIntervalMs = amount * (unit === 'hours' ? 3_600_000 : 60_000);
    storage.saveGuildConfig(i.guild.id, config);
    backup.reschedule(i.guild.id);
    return say(i, `Tu dong chup snapshot moi ${amount} ${unit === 'hours' ? 'gio' : 'phut'} (co hieu luc ngay).`);
  },

  async 'whitelist.list'(i, config) {
    const fmt = (arr, pre) => (arr.length ? arr.map((id) => `<${pre}${id}>`).join(' ') : 'khong');
    const embed = new EmbedBuilder()
      .setTitle('Whitelist Anti-Nuke')
      .addFields(
        { name: 'Nguoi dung', value: fmt(config.whitelistedUsers, '@').slice(0, 1000) },
        { name: 'Role', value: fmt(config.whitelistedRoles, '@&').slice(0, 1000) },
        { name: 'Bot', value: fmt(config.whitelistedBots, '@').slice(0, 1000) }
      );
    return i.reply({ embeds: [embed], flags: EPH });
  },

  async 'owners.list'(i, config) {
    return say(i, `Chu server: <@${i.guild.ownerId}>\nUy quyen: ${config.extraOwners.map((id) => `<@${id}>`).join(' ') || 'khong'}`);
  },

  async 'owners.add'(i, config) {
    const u = i.options.getUser('user', true);
    if (u.bot) return say(i, 'Khong the uy quyen cho bot.');
    if (!config.extraOwners.includes(u.id)) config.extraOwners.push(u.id);
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, `Da uy quyen cho <@${u.id}> chinh cau hinh Anti-Nuke (dong thoi duoc mien tru).`);
  },

  async 'owners.remove'(i, config) {
    const u = i.options.getUser('user', true);
    config.extraOwners = config.extraOwners.filter((id) => id !== u.id);
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, 'Da thu hoi uy quyen.');
  },
};

// Whitelist: [ten list, them?, lay doi tuong, kiem tra loi]
const WL = {
  'add-user': ['whitelistedUsers', true, (i) => i.options.getUser('user', true), (t) => (t.bot ? 'Day la bot, dung `add-bot`.' : null)],
  'remove-user': ['whitelistedUsers', false, (i) => i.options.getUser('user', true)],
  'add-role': ['whitelistedRoles', true, (i) => i.options.getRole('role', true), (t, i) => (t.id === i.guild.id ? 'Khong the whitelist @everyone.' : null)],
  'remove-role': ['whitelistedRoles', false, (i) => i.options.getRole('role', true)],
  'add-bot': ['whitelistedBots', true, (i) => i.options.getUser('bot', true), (t) => (t.bot ? null : 'Day khong phai bot, dung `add-user`.')],
  'remove-bot': ['whitelistedBots', false, (i) => i.options.getUser('bot', true)],
};
for (const [sub, [listName, add, getTarget, validate]] of Object.entries(WL)) {
  handlers[`whitelist.${sub}`] = async (i, config) => {
    const target = getTarget(i);
    const err = validate?.(target, i);
    if (err) return say(i, err);
    if (add) {
      if (!config[listName].includes(target.id)) config[listName].push(target.id);
    } else {
      config[listName] = config[listName].filter((id) => id !== target.id);
    }
    storage.saveGuildConfig(i.guild.id, config);
    return say(i, 'Da cap nhat whitelist.');
  };
}

async function execute(interaction) {
  if (!interaction.inGuild() || !interaction.guild) return interaction.reply({ content: 'Lenh nay chi dung trong server.', flags: EPH });
  const config = storage.getGuildConfig(interaction.guild.id);
  const group = interaction.options.getSubcommandGroup(false);
  const sub = interaction.options.getSubcommand();
  const key = group ? `${group}.${sub}` : sub;

  const denied = authorize(interaction, config, key);
  if (denied) return say(interaction, denied);

  const handler = handlers[key];
  if (!handler) return say(interaction, 'Lenh khong hop le.');
  return handler(interaction, config);
}

async function autocomplete(interaction) {
  const q = String(interaction.options.getFocused() || '').toLowerCase();
  const choices = Object.entries(MODULE_DEFS)
    .filter(([k, d]) => !q || k.toLowerCase().includes(q) || d.label.toLowerCase().includes(q))
    .slice(0, 25)
    .map(([value, d]) => ({ name: d.label, value }));
  return interaction.respond(choices);
}

module.exports = { data, execute, autocomplete, authorize };
