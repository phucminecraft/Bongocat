'use strict';
// Cach ly + xu phat nguoi vuot nguong, gui canh bao, va hoan tac thiet hai.
const { MODULE_DEFS, DANGEROUS_PERMS } = require('./config');
const { MAX_TIMEOUT_MS } = require('../util/constants');
const storage = require('./storage');
const { sendAlert } = require('./logger');
const { mitigate } = require('./mitigate');

// Go cac role nguy hiem ma bot con du thu bac de quan ly. Tra ve role da go va role KET (khong go duoc).
async function defang(guild, member, reason) {
  const dangerous = member.roles.cache.filter((r) => r.id !== guild.id && DANGEROUS_PERMS.some((p) => r.permissions.has(p)));
  const removable = dangerous.filter((r) => r.editable);
  const stuck = dangerous.filter((r) => !r.editable); // role cua bot/integration hoac cao hon bot
  if (removable.size) await member.roles.remove(removable, reason);
  return { removed: [...removable.keys()], stuck: [...stuck.keys()] };
}

// Ap dung hinh phat theo thang leo thang; tra ve ket qua chi tiet de canh bao trung thuc
// (truoc day "strip" that bai van bao "da xu ly").
async function contain({ guild, member, executorId, punishment, reason }) {
  const result = { actions: [], errors: [], neutralized: false, stripped: [], mode: punishment };
  const attempt = async (name, fn, neutralizes) => {
    try {
      await fn();
      result.actions.push(name);
      if (neutralizes) result.neutralized = true;
      return true;
    } catch (err) {
      result.errors.push(`${name}: ${err.message}`);
      return false;
    }
  };

  // Bot khong co role "go" duoc (role managed) -> strip/timeout vo nghia, phai kick.
  let mode = punishment;
  if (member?.user?.bot && mode !== 'ban') {
    mode = 'kick';
    result.mode = 'kick';
    result.actions.push('(bot: doi strip/timeout -> kick)');
  }

  if (mode === 'ban') {
    // Ban theo ID, dung ca khi nguoi do da roi server.
    await attempt('ban', () => guild.members.ban(executorId, { reason }), true);
    return result;
  }
  if (!member) {
    result.actions.push('nguoi thuc hien khong con trong server');
    result.neutralized = true;
    return result;
  }

  if (mode === 'kick') {
    const kicked = await attempt('kick', () => member.kick(reason), true);
    if (kicked) return result;
    // Kick that bai (thu bac) -> it nhat go role nguy hiem.
  }

  const tasks = [
    attempt(
      'strip',
      async () => {
        const r = await defang(guild, member, reason);
        result.stripped = r.removed;
        if (r.stuck.length) throw new Error(`con ${r.stuck.length} role nguy hiem khong go duoc (thu bac/managed)`);
        if (!r.removed.length) {
          result.nothingToStrip = true;
          result.actions.push('(khong co role nguy hiem de go - can nhac doi hinh phat sang kick/ban)');
        }
      },
      false
    ),
  ];
  if (mode === 'timeout') tasks.push(attempt('timeout', () => member.timeout(MAX_TIMEOUT_MS, reason), false));
  await Promise.all(tasks);

  const stripFailed = result.errors.some((e) => e.startsWith('strip'));
  if (!stripFailed && !result.nothingToStrip) result.neutralized = true;
  else if (stripFailed && mode !== 'kick') {
    // Strip khong du (role cao hon bot / managed) -> leo thang len kick neu bot du thu bac.
    await attempt('kick (leo thang)', () => member.kick(reason), true);
  }
  return result;
}

async function applyPunishment(client, guild, executorId, moduleKey, guildConfig, entries, { late = false } = {}) {
  const moduleConfig = guildConfig.modules[moduleKey];
  const label = MODULE_DEFS[moduleKey]?.label || moduleKey;
  if (executorId === guild.ownerId || executorId === client.user.id) return null;

  const member = guild.members.cache.get(executorId) ?? (await guild.members.fetch(executorId).catch(() => null));
  const reason = `Anti-Nuke: dat nguong ${label} (${entries.length} hanh dong)`.slice(0, 500);

  const result = await contain({ guild, member, executorId, punishment: moduleConfig.punishment, reason });
  if (result.stripped.length) storage.recordStripped(guild.id, executorId, result.stripped, moduleKey);

  // Canh bao va hoan tac chay song song: khong bao gio cho gui tin xong roi moi khoi phuc.
  const jobs = [mitigate(client, guild, moduleKey, entries, guildConfig)];
  if (!late || !result.neutralized) {
    const fields = [
      { name: 'Hanh dong xu ly', value: result.actions.join(', ') || 'khong co', inline: true },
      { name: 'So lan phat hien', value: `${entries.length}`, inline: true },
      { name: 'Da vo hieu hoa', value: result.neutralized ? 'Co' : 'KHONG - kiem tra role cua bot phai nam tren role cua nguoi nay', inline: false },
    ];
    if (result.errors.length) fields.push({ name: 'Loi', value: result.errors.join('\n'), inline: false });
    if (result.stripped.length) fields.push({ name: 'Role da go', value: `${result.stripped.map((id) => `<@&${id}>`).join(' ')}\nHoan tra neu phat nham: \`/antinuke unstrip\``, inline: false });
    jobs.push(
      sendAlert(guild, guildConfig, {
        title: `Anti-Nuke: ${label}${late ? ' (hanh dong bo sung)' : ''}`,
        description: `<@${executorId}> (\`${executorId}\`) da dat nguong **${moduleConfig.limit}** hanh dong trong **${(moduleConfig.windowMs / 1000).toFixed(0)}s**.`,
        color: result.neutralized ? 0xed4245 : 0xfaa61a,
        fields,
      })
    );
  }
  await Promise.allSettled(jobs);
  return result;
}

module.exports = { applyPunishment, contain, defang };
