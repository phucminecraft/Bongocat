'use strict';
// Diem trung tam: moi hanh dong (tu audit log hoac tu lenh moderation cua bot) deu qua day de
// kiem tra whitelist, dem nguong, cach ly va hoan tac.
const storage = require('./storage');
const tracker = require('./tracker');
const backup = require('./backup');
const { MODULE_DEFS } = require('./config');
const { isWhitelisted } = require('./whitelist');
const { applyPunishment } = require('./punish');
const { mitigate } = require('./mitigate');

const QUARANTINE_MS = 2 * 60_000; // sau khi bi xu phat, moi hanh dong tiep theo cua nguoi nay bi hoan tac ngay
const RECONTAIN_MS = 5_000; // toi da 5s / lan thu cach ly lai
const DESTRUCTIVE_FREEZE_MS = 3 * 60_000;
const BREACH_FREEZE_MS = 30 * 60_000;

// guild:executor -> { until, lastContain }. Duoc dat DONG BO truoc moi `await`, nen cac su kien
// den cung luc khong the kich hoat xu phat 2 lan (ban cu: nhieu lan ban/khoi phuc chong nhau).
const quarantine = new Map();

setInterval(() => {
  const now = Date.now();
  for (const [k, q] of quarantine) if (q.until <= now) quarantine.delete(k);
}, 60_000).unref?.();

async function _handle(client, guild, executorId, moduleKey, meta) {
  if (!executorId || !guild) return;
  const config = storage.getGuildConfig(guild.id);
  const def = MODULE_DEFS[moduleKey];

  const whitelisted = await isWhitelisted(guild, executorId, config, client);
  if (whitelisted) {
    // Xoa co chu dich cua nguoi tin cay -> restore sau nay khong duoc hoi sinh no.
    if (meta?.kind && meta.targetId) backup.markLegitDelete(guild.id, meta.kind, meta.targetId);
    return;
  }

  const moduleConfig = config.modules[moduleKey];
  if (!moduleConfig?.enabled) return;
  if (def?.destructive) backup.freeze(guild.id, DESTRUCTIVE_FREEZE_MS); // dung de snapshot chup phai trang thai dang bi pha

  const now = Date.now();
  const qKey = `${guild.id}:${executorId}`;
  const q = quarantine.get(qKey);
  if (q && q.until > now) {
    // Da bi xu phat nhung van con hanh dong bay toi: hoan tac ngay, khong cho nguong.
    q.until = now + QUARANTINE_MS;
    const entry = { ts: now, meta };
    if (now - q.lastContain >= RECONTAIN_MS) {
      q.lastContain = now;
      await applyPunishment(client, guild, executorId, moduleKey, config, [entry], { late: true });
    } else {
      await mitigate(client, guild, moduleKey, [entry], config);
    }
    return;
  }

  const entries = tracker.hit(guild.id, executorId, moduleKey, moduleConfig.windowMs, meta);
  if (entries.length >= moduleConfig.limit) {
    tracker.reset(guild.id, executorId, moduleKey);
    quarantine.set(qKey, { until: now + QUARANTINE_MS, lastContain: now });
    backup.freeze(guild.id, BREACH_FREEZE_MS);
    await applyPunishment(client, guild, executorId, moduleKey, config, entries);
  } else if (def?.instantMitigate) {
    await mitigate(client, guild, moduleKey, [{ ts: now, meta }], config);
  }
}

async function handleAction(client, guild, executorId, moduleKey, meta = null) {
  try {
    await _handle(client, guild, executorId, moduleKey, meta);
  } catch (err) {
    console.error(`[antinuke] handleAction(${moduleKey}) loi:`, err);
  }
}

module.exports = { handleAction, quarantine, QUARANTINE_MS };
