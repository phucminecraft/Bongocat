'use strict';
// Kiem tra mien tru: chu server, bot, nguoi duoc uy quyen, user/role/bot trong whitelist.
const MISS_TTL_MS = 10_000;
const missing = new Map(); // "guild:user" -> expiresAt (nguoi da roi server: khong fetch lap lai moi su kien)

async function isWhitelisted(guild, executorId, config, client) {
  if (!executorId) return true;
  if (client?.user && executorId === client.user.id) return true;
  if (executorId === guild.ownerId) return true;
  if (config.whitelistedUsers.includes(executorId)) return true;
  if (config.whitelistedBots.includes(executorId)) return true;
  if (config.extraOwners.includes(executorId)) return true;
  if (!config.whitelistedRoles.length) return false;

  // Whitelist theo role: member co the chua nam trong cache -> fetch (truoc day bo qua = phat nham nguoi whitelist).
  let member = guild.members.cache.get(executorId);
  if (!member) {
    const key = `${guild.id}:${executorId}`;
    if ((missing.get(key) ?? 0) > Date.now()) return false;
    member = await guild.members.fetch(executorId).catch(() => null);
    if (!member) {
      if (missing.size > 2000) missing.clear();
      missing.set(key, Date.now() + MISS_TTL_MS);
      return false;
    }
  }
  return config.whitelistedRoles.some((id) => member.roles.cache.has(id));
}

module.exports = { isWhitelisted };
