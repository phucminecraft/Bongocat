'use strict';
// Lap rap toan bo module Anti-Nuke vao mot Discord client co san.
const { Events, MessageFlags } = require('discord.js');
const engine = require('./engine');
const storage = require('./storage');
const tracker = require('./tracker');
const backup = require('./backup');
const auditStream = require('./auditStream');
const deletedCache = require('./deletedCache');
const { checkHealth } = require('./health');
const antinukeCommand = require('./commands/antinuke');

function setupAntiNuke(client) {
  // Snapshot dinh ky + kiem tra suc khoe can guild cache day du -> cho toi khi client san sang.
  client.once(Events.ClientReady, () => {
    backup.startAutoSnapshot(client);
    for (const guild of client.guilds.cache.values()) {
      const health = checkHealth(guild, storage.getGuildConfig(guild.id));
      if (!health.ok) console.warn(`[antinuke] ${guild.name} (${guild.id}) co van de:\n  - ${health.problems.join('\n  - ')}`);
    }
  });

  deletedCache.register(client); // nho du lieu kenh/role vua bi xoa de khoi phuc chinh xac
  auditStream.register(client); // nguon phat hien duy nhat: guildAuditLogEntryCreate

  client.on(Events.GuildDelete, (guild) => {
    if (guild.available === false) return; // mat ket noi tam thoi
    tracker.clearGuild(guild.id);
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isAutocomplete() && interaction.commandName === 'antinuke') {
        await antinukeCommand.autocomplete(interaction);
        return;
      }
      if (!interaction.isChatInputCommand() || interaction.commandName !== 'antinuke') return;
      await antinukeCommand.execute(interaction);
    } catch (err) {
      console.error('[antinuke] loi khi xu ly interaction:', err);
      if (interaction.isAutocomplete?.()) return;
      const payload = { content: 'Da xay ra loi khi xu ly lenh.', flags: MessageFlags.Ephemeral };
      if (interaction.deferred || interaction.replied) interaction.editReply({ content: payload.content }).catch(() => {});
      else interaction.reply(payload).catch(() => {});
    }
  });
}

module.exports = {
  setupAntiNuke,
  handleAction: engine.handleAction,
  flushStorage: storage.flushAll,
  antinukeCommandData: antinukeCommand.data,
};
