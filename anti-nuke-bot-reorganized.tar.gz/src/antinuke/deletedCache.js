'use strict';
// Nho tam (15 phut) du lieu DAY DU cua channel/role vua bi xoa, lay tu doi tuong song ngay luc su kien
// channelDelete / roleDelete. Khi phat hien nuke, restore dung dung du lieu nay (chinh xac hon audit log).
const { Events } = require('discord.js');
const { serializeChannel, serializeRole } = require('./serialize');

const TTL_MS = 15 * 60_000;
const MAX_ITEMS = 5000;
const store = new Map(); // "guild:kind:id" -> { data, exp }

const k = (guildId, kind, id) => `${guildId}:${kind}:${id}`;

function remember(guildId, kind, id, data) {
  if (store.size >= MAX_ITEMS) sweep();
  if (store.size >= MAX_ITEMS) store.delete(store.keys().next().value);
  store.set(k(guildId, kind, id), { data, exp: Date.now() + TTL_MS });
}

function recall(guildId, kind, id) {
  const hit = store.get(k(guildId, kind, id));
  return hit && hit.exp > Date.now() ? hit.data : null;
}

function sweep(now = Date.now()) {
  for (const [key, v] of store) if (v.exp <= now) store.delete(key);
}

function register(client) {
  client.on(Events.ChannelDelete, (channel) => {
    if (!channel.guild) return;
    try {
      remember(channel.guild.id, 'channel', channel.id, serializeChannel(channel.guild, channel));
    } catch (err) {
      console.warn(`[antinuke] khong nho duoc channel bi xoa: ${err.message}`);
    }
  });
  client.on(Events.GuildRoleDelete, (role) => {
    try {
      remember(role.guild.id, 'role', role.id, serializeRole(role));
    } catch (err) {
      console.warn(`[antinuke] khong nho duoc role bi xoa: ${err.message}`);
    }
  });
  const t = setInterval(() => sweep(), 60_000);
  t.unref?.();
}

module.exports = { register, remember, recall, sweep };
