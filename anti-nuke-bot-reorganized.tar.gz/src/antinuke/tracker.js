'use strict';
// Dem hanh dong theo cua so thoi gian truot (sliding window) cho tung (guild, nguoi thuc hien, module).
// Co don rac dinh ky: khong con ro ri bo nho theo so nguoi tung thuc hien hanh dong.
class ActionTracker {
  constructor() {
    this.buckets = new Map(); // "guild:executor:module" -> { windowMs, items: [{ ts, meta }] }
    this.sweeper = setInterval(() => this.sweep(), 60_000);
    this.sweeper.unref?.();
  }

  _key(guildId, executorId, moduleKey) {
    return `${guildId}:${executorId}:${moduleKey}`;
  }

  // Ghi nhan 1 hanh dong, tra ve danh sach hanh dong con trong cua so thoi gian.
  hit(guildId, executorId, moduleKey, windowMs, meta = null) {
    const key = this._key(guildId, executorId, moduleKey);
    const now = Date.now();
    let bucket = this.buckets.get(key);
    if (!bucket) {
      bucket = { windowMs, items: [] };
      this.buckets.set(key, bucket);
    }
    bucket.windowMs = windowMs;
    const cutoff = now - windowMs;
    bucket.items = bucket.items.filter((i) => i.ts >= cutoff);
    bucket.items.push({ ts: now, meta });
    return bucket.items;
  }

  reset(guildId, executorId, moduleKey) {
    this.buckets.delete(this._key(guildId, executorId, moduleKey));
  }

  clearGuild(guildId) {
    const prefix = `${guildId}:`;
    for (const key of this.buckets.keys()) if (key.startsWith(prefix)) this.buckets.delete(key);
  }

  sweep(now = Date.now()) {
    for (const [key, b] of this.buckets) {
      const last = b.items[b.items.length - 1];
      if (!last || now - last.ts > b.windowMs) this.buckets.delete(key);
    }
  }
}

module.exports = new ActionTracker();
module.exports.ActionTracker = ActionTracker;
