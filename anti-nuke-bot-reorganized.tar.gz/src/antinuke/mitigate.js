'use strict';
// Hoan tac thiet hai cua tung loai hanh dong. Chay khi 1 nguoi vuot nguong, va ca voi cac hanh dong
// den MUON (con dang bay tren duong truyen luc nguoi do bi xu phat) trong thoi gian cach ly.
const { PermissionFlagsBits } = require('discord.js');
const { requestRestore } = require('./backup');
const deletedCache = require('./deletedCache');
const { OVERWRITE_MEMBER } = require('./serialize');

const RESTORE_MODULES = new Set(['massChannelDelete', 'massCategoryDelete', 'massRoleDelete']);
const REASON = 'Anti-Nuke: hoan tac hanh dong trai phep';

// Huy nhung thu ke tan cong vua TAO ra (kenh/role/emoji/webhook/invite... spam).
const UNDO_CREATE = {
  massChannelCreate: (g, m) => g.channels.cache.get(m.channelId)?.delete(REASON),
  massCategoryCreate: (g, m) => g.channels.cache.get(m.channelId)?.delete(REASON),
  massRoleCreate: (g, m) => {
    const role = g.roles.cache.get(m.roleId);
    return role?.editable ? role.delete(REASON) : null;
  },
  massEmojiCreate: (g, m) => m.emojiId && g.emojis.delete(m.emojiId, REASON),
  massStickerCreate: (g, m) => m.stickerId && g.stickers.delete(m.stickerId, REASON),
  massInviteCreate: (g, m) => m.code && g.invites.delete(m.code, REASON),
  massThreadCreate: async (g, m) => (await g.client.channels.fetch(m.threadId).catch(() => null))?.delete(REASON),
  massWebhookCreate: async (g, m) => (await g.client.fetchWebhook(m.webhookId).catch(() => null))?.delete(REASON),
};

// Gom theo thanh vien de moi nguoi chi tac dong 1 lan API.
function groupRoles(metas) {
  const byMember = new Map();
  for (const m of metas) {
    if (!m.memberId || !m.roleIds?.length) continue;
    if (!byMember.has(m.memberId)) byMember.set(m.memberId, new Set());
    for (const id of m.roleIds) byMember.get(m.memberId).add(id);
  }
  return byMember;
}

const memberOf = (guild, id) => guild.members.cache.get(id) ?? guild.members.fetch(id).catch(() => null);

// Cac thay doi lien tiep tren cung 1 doi tuong: gia tri "old" DAU TIEN moi la trang thai goc.
function firstOldValues(metas, idKey) {
  const byId = new Map();
  for (const m of metas) {
    const id = m[idKey];
    if (!id) continue;
    const patch = byId.get(id) ?? {};
    for (const c of m.changes || []) if (c.old !== undefined && !(c.key in patch)) patch[c.key] = c.old;
    byId.set(id, patch);
  }
  return byId;
}

async function revertRoles(guild, metas) {
  const jobs = [];
  for (const [roleId, old] of firstOldValues(metas, 'roleId')) {
    const role = guild.roles.cache.get(roleId);
    if (!role || !role.editable) continue;
    const patch = {};
    if (old.permissions !== undefined) patch.permissions = BigInt(old.permissions);
    for (const k of ['name', 'color', 'hoist', 'mentionable']) if (old[k] !== undefined) patch[k] = old[k];
    if (Object.keys(patch).length) jobs.push(role.edit({ ...patch, reason: REASON }));
  }
  return Promise.allSettled(jobs);
}

// bigint allow/deny -> dang { TenQuyen: true|false } day du CA 3 trang thai (true/false/null cho tung
// quyen) ma PermissionOverwriteManager#create/edit dung. Liet ke DAY DU (khong chi cac bit đã set) de
// dam bao hoan tac chinh xac tuyet doi: bat ky quyen nao KHONG con trong allow/deny cu deu phai duoc
// dat lai ve null (ke thua) chu khong duoc "giu nguyen" gia tri hien tai (co the la do ke tan cong dat).
function overwriteOptionsFromBits(allow, deny) {
  const opts = {};
  for (const [name, bit] of Object.entries(PermissionFlagsBits)) {
    if (typeof bit !== 'bigint' || bit === 0n) continue;
    if ((allow & bit) === bit) opts[name] = true;
    else if ((deny & bit) === bit) opts[name] = false;
    else opts[name] = null;
  }
  return opts;
}

// Hoan tac permission overwrite tung kenh (massPermissionChange, phan ChannelOverwriteCreate/Update/Delete
// - xem readOverwriteChange trong auditStream.js). Giu nguyen tac "old DAU TIEN la trang thai goc" giong
// firstOldValues, nhung khoa theo CAP (kenh, doi tuong bi overwrite) vi 1 cua so co the gom nhieu kenh/role/member khac nhau.
async function revertChannelOverwrites(guild, metas) {
  const byKey = new Map();
  for (const m of metas) {
    const ow = m.overwrite;
    if (!ow?.targetId) continue;
    const key = `${m.channelId}:${ow.targetId}`;
    if (!byKey.has(key)) byKey.set(key, { channelId: m.channelId, targetId: ow.targetId, targetType: ow.targetType, roleName: ow.roleName, old: ow.old });
  }
  const jobs = [];
  for (const { channelId, targetId, targetType, roleName, old } of byKey.values()) {
    const ch = guild.channels.cache.get(channelId);
    if (!ch?.permissionOverwrites) continue;
    if (!old) {
      // Overwrite nay KHONG TON TAI truoc do (ke tan cong tu tao ra) -> xoa hoan toan.
      jobs.push(ch.permissionOverwrites.delete(targetId, REASON).catch(() => {}));
      continue;
    }
    // Neu la overwrite cua ROLE: role phai con ton tai (thu tim lai theo ten neu ID cu khong con,
    // giong cach role/backup.js xu ly) va bot phai sua duoc no; neu la MEMBER thi ho phai con trong server.
    let resolvedId = targetId;
    if (targetType !== OVERWRITE_MEMBER) {
      if (!guild.roles.cache.has(targetId)) {
        const byName = roleName ? guild.roles.cache.find((r) => r.name === roleName) : null;
        if (!byName) continue;
        resolvedId = byName.id;
      }
    } else if (!guild.members.cache.has(targetId)) {
      continue;
    }
    const options = overwriteOptionsFromBits(BigInt(old.allow ?? 0), BigInt(old.deny ?? 0));
    // Thu create() truoc (thuong dung khi overwrite hien khong con ton tai do bi XOA); khong duoc thi
    // fallback sang edit() (overwrite van con nhung GIA TRI bi doi) - phu 2 truong hop ma khong can biet
    // truoc overwrite hien co ton tai hay khong.
    jobs.push(
      ch.permissionOverwrites
        .create(resolvedId, options, { type: targetType, reason: REASON })
        .catch(() => ch.permissionOverwrites.edit(resolvedId, options, { type: targetType, reason: REASON }))
        .catch(() => {})
    );
  }
  return Promise.allSettled(jobs);
}

const CHANNEL_KEYS = { name: 'name', topic: 'topic', nsfw: 'nsfw', rate_limit_per_user: 'rateLimitPerUser', bitrate: 'bitrate', user_limit: 'userLimit' };
async function revertChannels(guild, metas) {
  const jobs = [];
  for (const [channelId, old] of firstOldValues(metas, 'channelId')) {
    const ch = guild.channels.cache.get(channelId);
    if (!ch?.edit) continue;
    const patch = {};
    for (const [k, prop] of Object.entries(CHANNEL_KEYS)) if (old[k] !== undefined) patch[prop] = old[k];
    if (old.parent_id !== undefined) patch.parent = old.parent_id;
    if (Object.keys(patch).length) jobs.push(ch.edit({ ...patch, reason: REASON }));
  }
  return Promise.allSettled(jobs);
}

async function mitigate(client, guild, moduleKey, entries, config) {
  const metas = (entries || []).map((e) => e.meta).filter(Boolean);
  if (!metas.length) return;
  try {
    if (moduleKey === 'massBan') {
      const ids = [...new Set(metas.map((m) => m.userId).filter(Boolean))];
      await Promise.allSettled(ids.map((id) => guild.members.unban(id, REASON)));
    } else if (moduleKey === 'massTimeout') {
      await Promise.allSettled(
        metas.map(async (m) => {
          const member = m.memberId && (await memberOf(guild, m.memberId));
          if (!member) return;
          if (m.muteRoleId) await member.roles.remove(m.muteRoleId, REASON);
          else await member.timeout(null, REASON);
        })
      );
    } else if (moduleKey === 'massRoleAdd') {
      await Promise.allSettled([...groupRoles(metas)].map(async ([id, roles]) => (await memberOf(guild, id))?.roles.remove([...roles], REASON)));
    } else if (moduleKey === 'massRoleRemove') {
      await Promise.allSettled([...groupRoles(metas)].map(async ([id, roles]) => (await memberOf(guild, id))?.roles.add([...roles], REASON)));
    } else if (moduleKey === 'privilegeEscalation') {
      const grants = metas.filter((m) => m.type === 'grant');
      const perms = metas.filter((m) => m.type === 'perm');
      await Promise.allSettled([
        ...[...groupRoles(grants)].map(async ([id, roles]) => (await memberOf(guild, id))?.roles.remove([...roles], REASON)),
        revertRoles(guild, perms.map((m) => ({ roleId: m.roleId, changes: m.changes }))),
      ]);
    } else if (moduleKey === 'massBotAdd') {
      const trusted = new Set(config?.whitelistedBots || []);
      const ids = [...new Set(metas.map((m) => m.botId).filter((id) => id && !trusted.has(id)))];
      await Promise.allSettled(ids.map((id) => guild.members.kick(id, REASON)));
    } else if (moduleKey === 'massRoleUpdate') {
      await revertRoles(guild, metas.filter((m) => m.roleId));
    } else if (moduleKey === 'massPermissionChange') {
      // Module nay gom 2 nguon khac nhau: RoleUpdate (doi permissions cua 1 role) va ChannelOverwrite*
      // (doi permission overwrite cua 1 kenh) - hoan tac ca 2, doc lap voi nhau.
      await Promise.allSettled([revertRoles(guild, metas.filter((m) => m.roleId)), revertChannelOverwrites(guild, metas.filter((m) => m.overwrite))]);
    } else if (moduleKey === 'massChannelUpdate') {
      await revertChannels(guild, metas);
    } else if (RESTORE_MODULES.has(moduleKey)) {
      const hints = { channels: [], roles: [] };
      for (const m of metas) {
        if (m.kind === 'channel') {
          const d = deletedCache.recall(guild.id, 'channel', m.targetId) ?? m.audit;
          if (d) hints.channels.push(d);
        } else if (m.kind === 'role') {
          const d = deletedCache.recall(guild.id, 'role', m.targetId) ?? m.audit;
          if (d) hints.roles.push(d);
        }
      }
      await requestRestore(guild, hints);
    } else if (UNDO_CREATE[moduleKey]) {
      await Promise.allSettled(metas.map((m) => Promise.resolve().then(() => UNDO_CREATE[moduleKey](guild, m))));
    }
    // massKick / massPrune / guildSettingChange / xoa webhook,emoji,thread...: khong hoan tac duoc tu dong, chi canh bao.
  } catch (err) {
    console.warn(`[antinuke] mitigate ${moduleKey} loi: ${err.message}`);
  }
}

module.exports = { mitigate };
