'use strict';
// Nguon phat hien DUY NHAT: su kien guildAuditLogEntryCreate cua gateway (Discord day audit log ve ngay
// khi hanh dong xay ra, kem executor). Thay cho co che cu "nghe event -> cho 300ms -> tra audit log", vi co che cu:
//  - tre it nhat 300ms moi su kien, va mat han neu audit log cham hon 300ms (khong co thu lai);
//  - chi doc 5 dong audit log gan nhat: nuke nhanh > 5 hanh dong la bo sot;
//  - khi khong tim thay dong khop lai lay dai dong DAU TIEN cua audit log (co the la cua ai do hom qua) -> phat NHAM nguoi vo toi
//    (webhook / guildUpdate / integration);
//  - bo sot han cac hanh dong: tao/xoa permission overwrite (chi nhin ChannelOverwriteUpdate), kick, prune;
//  - oldMember bi partial -> tinh nham "them het role" (Partials.GuildMember dang bat);
//  - moi lan kiem tra 1 request API -> de dinh rate limit dung luc bi nuke.
const { AuditLogEvent: A, ChannelType, Events } = require('discord.js');
const storage = require('./storage');
const engine = require('./engine');
const deletedCache = require('./deletedCache');
const { DANGEROUS_PERMS, DANGEROUS_MASK } = require('./config');
const { channelFromAudit, roleFromAudit, OVERWRITE_MEMBER } = require('./serialize');

const SEEN_MAX = 5000;
const seen = new Set();
function firstSeen(id) {
  if (!id) return true;
  if (seen.has(id)) return false;
  seen.add(id);
  if (seen.size > SEEN_MAX) seen.delete(seen.values().next().value);
  return true;
}

const toBig = (v) => {
  try {
    return BigInt(v ?? 0);
  } catch {
    return 0n;
  }
};
const slim = (changes) => (changes || []).map((c) => ({ key: c.key, old: c.old, new: c.new }));

// Ghi lai overwrite TRUOC/SAU (allow/deny dang bigint-string) de mitigate.js hoan tac duoc chinh xac
// (xem revertChannelOverwrites trong mitigate.js), khong chi dem+xu phat nhu truoc. Theo tai lieu API
// chinh thuc cua Discord, entry.extra (options) cho 3 hanh dong nay co san "id" + "type" (0=role,1=member)
// + "roleName" (chi khi type=role) de biet overwrite do la CUA AI - CHUA kiem chung tren server that
// (xem AUDIT.md ve gioi han cua bo test gia lap); neu extra.id thieu (phien ban API khac di) thi bo qua
// phan hoan tac, van giu nguyen viec dem+xu phat nhu cu (khong regress).
function readOverwriteChange(entry, guild, channelId, phase) {
  const extra = entry.extra || {};
  const targetId = extra.id;
  if (!targetId) return null;
  const targetType = extra.type === OVERWRITE_MEMBER || extra.type === 'member' ? OVERWRITE_MEMBER : 0;
  const roleName = extra.roleName ?? extra.role_name ?? null;
  const allowC = entry.changes?.find((c) => c.key === 'allow');
  const denyC = entry.changes?.find((c) => c.key === 'deny');
  const current = guild.channels?.cache?.get(channelId)?.permissionOverwrites?.cache?.get(targetId);
  const curAllow = current ? String(current.allow.bitfield) : '0';
  const curDeny = current ? String(current.deny.bitfield) : '0';
  if (phase === 'create') {
    return { targetId, targetType, roleName, old: null, new: { allow: String(allowC?.new ?? 0), deny: String(denyC?.new ?? 0) } };
  }
  if (phase === 'delete') {
    return { targetId, targetType, roleName, old: { allow: String(allowC?.old ?? 0), deny: String(denyC?.old ?? 0) }, new: null };
  }
  // update: mot trong 2 truong (allow/deny) co the khong doi -> Discord khong liet ke trong changes;
  // gia tri hien tai tren kenh chinh la gia tri do (vi no khong doi nen old===new===hien tai).
  return {
    targetId,
    targetType,
    roleName,
    old: { allow: String(allowC?.old ?? curAllow), deny: String(denyC?.old ?? curDeny) },
    new: { allow: String(allowC?.new ?? curAllow), deny: String(denyC?.new ?? curDeny) },
  };
}

function isRiskyRole(guild, config, roleId) {
  if (config.whitelistedRoles.includes(roleId)) return true; // cap role whitelist = cap quyen mien tru
  const role = guild.roles.cache.get(roleId);
  return Boolean(role && DANGEROUS_PERMS.some((p) => role.permissions.has(p)));
}

// entry -> danh sach [{ module, meta }]. Ham thuan tuy, de test.
function classify(entry, guild, config) {
  const change = (key) => entry.changes?.find((c) => c.key === key);
  const tid = entry.targetId;

  switch (entry.action) {
    case A.GuildUpdate:
      return [{ module: 'guildSettingChange', meta: {} }];

    case A.ChannelCreate: {
      const type = change('type')?.new ?? guild.channels?.cache?.get(tid)?.type;
      return [{ module: type === ChannelType.GuildCategory ? 'massCategoryCreate' : 'massChannelCreate', meta: { channelId: tid } }];
    }
    case A.ChannelUpdate:
      return [{ module: 'massChannelUpdate', meta: { channelId: tid, changes: slim(entry.changes) } }];
    case A.ChannelDelete: {
      const type = change('type')?.old ?? deletedCache.recall(guild.id, 'channel', tid)?.type;
      return [
        {
          module: type === ChannelType.GuildCategory ? 'massCategoryDelete' : 'massChannelDelete',
          meta: { kind: 'channel', targetId: tid, audit: channelFromAudit(entry) },
        },
      ];
    }
    case A.ChannelOverwriteCreate:
      return [{ module: 'massPermissionChange', meta: { channelId: tid, overwrite: readOverwriteChange(entry, guild, tid, 'create') } }];
    case A.ChannelOverwriteUpdate:
      return [{ module: 'massPermissionChange', meta: { channelId: tid, overwrite: readOverwriteChange(entry, guild, tid, 'update') } }];
    case A.ChannelOverwriteDelete:
      return [{ module: 'massPermissionChange', meta: { channelId: tid, overwrite: readOverwriteChange(entry, guild, tid, 'delete') } }];

    case A.MemberKick:
      return [{ module: 'massKick', meta: { userId: tid } }];
    case A.MemberPrune:
      return [{ module: 'massPrune', meta: { removed: Number(entry.extra?.removed) || 0 } }];
    case A.MemberBanAdd:
      return [{ module: 'massBan', meta: { userId: tid } }];
    case A.MemberUpdate: {
      const t = change('communication_disabled_until');
      return t?.new && Date.parse(t.new) > Date.now() ? [{ module: 'massTimeout', meta: { memberId: tid } }] : [];
    }
    case A.MemberRoleUpdate: {
      const add = (change('$add')?.new || []).map((r) => r.id);
      const rem = (change('$remove')?.new || []).map((r) => r.id);
      const out = [];
      if (add.length) {
        out.push({ module: 'massRoleAdd', meta: { memberId: tid, roleIds: add } });
        const risky = add.filter((id) => isRiskyRole(guild, config, id));
        if (risky.length) out.push({ module: 'privilegeEscalation', meta: { type: 'grant', memberId: tid, roleIds: risky } });
      }
      if (rem.length) out.push({ module: 'massRoleRemove', meta: { memberId: tid, roleIds: rem } });
      return out;
    }
    case A.BotAdd:
      return [{ module: 'massBotAdd', meta: { botId: tid } }];

    case A.RoleCreate:
      return [{ module: 'massRoleCreate', meta: { roleId: tid } }];
    case A.RoleUpdate: {
      const perms = change('permissions');
      const out = [{ module: perms ? 'massPermissionChange' : 'massRoleUpdate', meta: { roleId: tid, changes: slim(entry.changes) } }];
      if (perms && (toBig(perms.new) & ~toBig(perms.old) & DANGEROUS_MASK) !== 0n) {
        out.push({ module: 'privilegeEscalation', meta: { type: 'perm', roleId: tid, changes: [{ key: 'permissions', old: perms.old }] } });
      }
      return out;
    }
    case A.RoleDelete:
      return [{ module: 'massRoleDelete', meta: { kind: 'role', targetId: tid, audit: roleFromAudit(entry) } }];

    case A.InviteCreate:
      return [{ module: 'massInviteCreate', meta: { code: change('code')?.new } }];
    case A.WebhookCreate:
      return [{ module: 'massWebhookCreate', meta: { webhookId: tid } }];
    case A.WebhookDelete:
      return [{ module: 'massWebhookDelete', meta: {} }];
    case A.EmojiCreate:
      return [{ module: 'massEmojiCreate', meta: { emojiId: tid } }];
    case A.EmojiDelete:
      return [{ module: 'massEmojiDelete', meta: {} }];
    case A.StickerCreate:
      return [{ module: 'massStickerCreate', meta: { stickerId: tid } }];
    case A.StickerDelete:
      return [{ module: 'massStickerDelete', meta: {} }];
    case A.ThreadCreate:
      return [{ module: 'massThreadCreate', meta: { threadId: tid } }];
    case A.ThreadDelete:
      return [{ module: 'massThreadDelete', meta: {} }];
    case A.IntegrationCreate:
    case A.IntegrationUpdate:
    case A.IntegrationDelete:
      return [{ module: 'massIntegrationChange', meta: {} }];
    default:
      return [];
  }
}

async function onEntry(client, entry, guild) {
  if (!entry?.executorId || !guild) return; // hanh dong do he thong Discord thuc hien
  if (!firstSeen(entry.id)) return;
  const config = storage.getGuildConfig(guild.id);
  const actions = classify(entry, guild, config);
  if (!actions.length) return;
  await Promise.allSettled(actions.map((a) => engine.handleAction(client, guild, entry.executorId, a.module, a.meta)));
}

function register(client) {
  client.on(Events.GuildAuditLogEntryCreate, (entry, guild) => {
    onEntry(client, entry, guild).catch((err) => console.error('[antinuke] audit entry loi:', err));
  });
}

module.exports = { register, classify, onEntry, _seen: seen };
