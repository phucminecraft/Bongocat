'use strict';
// Kiem tra "suc khoe" cau hinh: nhung loi trong yen lang lam anti-nuke khong chay (thieu quyen, role bot qua thap...).
const { PermissionFlagsBits: P } = require('discord.js');
const { DANGEROUS_PERMS } = require('./config');

const REQUIRED = [
  [P.ViewAuditLog, 'View Audit Log (BAT BUOC - thieu quyen nay se KHONG phat hien duoc gi)'],
  [P.BanMembers, 'Ban Members'],
  [P.KickMembers, 'Kick Members'],
  [P.ManageRoles, 'Manage Roles'],
  [P.ManageChannels, 'Manage Channels'],
  [P.ModerateMembers, 'Moderate Members'],
];

function checkHealth(guild, config) {
  const problems = [];
  const me = guild.members.me;
  if (!me) return { ok: false, problems: ['Khong lay duoc thong tin bot trong server.'] };

  for (const [perm, label] of REQUIRED) if (!me.permissions.has(perm)) problems.push(`Thieu quyen: ${label}`);

  const myPos = me.roles.highest.position;
  const above = guild.roles.cache.filter((r) => r.id !== guild.id && !r.managed && r.position >= myPos && DANGEROUS_PERMS.some((p) => r.permissions.has(p)));
  if (above.size) problems.push(`${above.size} role co quyen nguy hiem nam NGANG/CAO HON role bot -> bot khong go/ban duoc nguoi giu no. Keo role bot len tren cung.`);

  const ch = config.logChannelId ? guild.channels.cache.get(config.logChannelId) : null;
  if (!ch) problems.push('Chua dat kenh log (`/antinuke setup`) - canh bao se chi gui DM cho chu server.');
  else if (!ch.permissionsFor(me)?.has(P.SendMessages)) problems.push('Bot khong gui duoc tin vao kenh log.');

  return { ok: problems.length === 0, problems };
}

module.exports = { checkHealth };
