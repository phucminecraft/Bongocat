'use strict';
// Gui embed canh bao vao kenh log; neu chua cau hinh / kenh khong gui duoc thi nhan tin rieng cho chu server
// (truoc day cuoc tan cong bi chan trong im lang, khong ai duoc bao).
const { EmbedBuilder } = require('discord.js');

const lastDm = new Map(); // guildId -> ts
const DM_COOLDOWN_MS = 60_000;

const clip = (s, n) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));

async function sendAlert(guild, config, { title, description, color = 0xed4245, fields = [] }) {
  const embed = new EmbedBuilder().setTitle(clip(title, 250)).setDescription(clip(description, 4000)).setColor(color).setTimestamp();
  if (fields.length) embed.addFields(fields.slice(0, 25).map((f) => ({ ...f, name: clip(f.name, 250), value: clip(f.value || '-', 1000) })));

  const channel = config.logChannelId ? guild.channels.cache.get(config.logChannelId) : null;
  if (channel?.isTextBased?.()) {
    try {
      await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
      return true;
    } catch {
      /* roi xuong DM chu server */
    }
  }

  const now = Date.now();
  if (now - (lastDm.get(guild.id) ?? 0) < DM_COOLDOWN_MS) return false;
  lastDm.set(guild.id, now);
  try {
    const owner = await guild.fetchOwner();
    await owner.send({ content: `Canh bao Anti-Nuke tu server **${guild.name}** (chua co kenh log hop le, dung \`/antinuke setup\`):`, embeds: [embed] });
    return true;
  } catch {
    return false;
  }
}

module.exports = { sendAlert };
