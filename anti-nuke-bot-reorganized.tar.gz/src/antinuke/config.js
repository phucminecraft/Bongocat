'use strict';
// Dinh nghia toan bo module bao ve, gia tri mac dinh (limit / thoi gian / hinh phat)
// va cac ham chuan hoa cau hinh doc tu file.
const { PermissionFlagsBits: P } = require('discord.js');

const PUNISHMENTS = ['ban', 'kick', 'timeout', 'strip'];

// limit = so hanh dong KICH HOAT: dat den muc nay trong cua so thoi gian la bi xu ly
// (vd limit 3 -> hanh dong thu 3 se kich hoat, chi 2 hanh dong dau duoc bo qua).
// destructive: xoa dau vet -> dong bang snapshot ngay de khong "chup" trang thai da bi pha.
// instantMitigate: hoan tac NGAY tung hanh dong, khong cho toi nguong.
const MODULE_DEFS = {
  massBan:              { label: 'Mass Bans',                limit: 3, windowMs: 10_000, punishment: 'ban' },
  massKick:             { label: 'Mass Kicks',               limit: 3, windowMs: 10_000, punishment: 'ban' },
  massPrune:            { label: 'Member Prune',             limit: 1, windowMs: 60_000, punishment: 'strip' },
  massTimeout:          { label: 'Mass Timeouts',            limit: 5, windowMs: 15_000, punishment: 'strip' },
  massRoleAdd:          { label: 'Mass Role Adds',           limit: 5, windowMs: 10_000, punishment: 'strip' },
  massRoleRemove:       { label: 'Mass Role Removes',        limit: 5, windowMs: 10_000, punishment: 'strip' },
  massChannelCreate:    { label: 'Mass Channel Creation',    limit: 3, windowMs: 10_000, punishment: 'strip' },
  massChannelDelete:    { label: 'Mass Channel Deletion',    limit: 3, windowMs: 10_000, punishment: 'ban', destructive: true },
  massChannelUpdate:    { label: 'Mass Channel Updates',     limit: 5, windowMs: 10_000, punishment: 'strip' },
  massCategoryCreate:   { label: 'Mass Category Creation',   limit: 3, windowMs: 10_000, punishment: 'strip' },
  massCategoryDelete:   { label: 'Mass Category Deletion',   limit: 3, windowMs: 10_000, punishment: 'ban', destructive: true },
  massThreadCreate:     { label: 'Mass Thread Creation',     limit: 8, windowMs: 10_000, punishment: 'strip' },
  massThreadDelete:     { label: 'Mass Thread Deletion',     limit: 8, windowMs: 10_000, punishment: 'strip' },
  massRoleCreate:       { label: 'Mass Role Creation',       limit: 4, windowMs: 10_000, punishment: 'strip' },
  massRoleDelete:       { label: 'Mass Role Deletion',       limit: 3, windowMs: 10_000, punishment: 'ban', destructive: true },
  massRoleUpdate:       { label: 'Mass Role Updates',        limit: 5, windowMs: 10_000, punishment: 'strip' },
  massPermissionChange: { label: 'Mass Permission Changes',  limit: 4, windowMs: 10_000, punishment: 'ban' },
  massWebhookCreate:    { label: 'Mass Webhook Creation',    limit: 4, windowMs: 10_000, punishment: 'strip' },
  massWebhookDelete:    { label: 'Mass Webhook Deletion',    limit: 4, windowMs: 10_000, punishment: 'strip' },
  massEmojiCreate:      { label: 'Mass Emoji Creation',      limit: 6, windowMs: 10_000, punishment: 'strip' },
  massEmojiDelete:      { label: 'Mass Emoji Deletion',      limit: 6, windowMs: 10_000, punishment: 'strip' },
  massStickerCreate:    { label: 'Mass Sticker Creation',    limit: 6, windowMs: 10_000, punishment: 'strip' },
  massStickerDelete:    { label: 'Mass Sticker Deletion',    limit: 6, windowMs: 10_000, punishment: 'strip' },
  massInviteCreate:     { label: 'Mass Invite Creation',     limit: 5, windowMs: 10_000, punishment: 'strip' },
  massIntegrationChange:{ label: 'Mass Integration Changes', limit: 3, windowMs: 15_000, punishment: 'ban' },
  massBotAdd:           { label: 'Mass Bot Invites',         limit: 2, windowMs: 10_000, punishment: 'ban' },
  guildSettingChange:   { label: 'Server Setting Changes',   limit: 3, windowMs: 30_000, punishment: 'strip' },
  // Nguoi KHONG whitelist cap role co quyen nguy hiem / role whitelist cho ai do, hoac them quyen
  // nguy hiem vao mot role -> hoan tac ngay + xu ly. Chan viec "nang quyen cho tai khoan phu" tung chut mot.
  privilegeEscalation:  { label: 'Dangerous Privilege Grants', limit: 1, windowMs: 60_000, punishment: 'strip', instantMitigate: true },
};

// Quyen coi la nguy hiem: dung de go role khi cach ly va de phat hien nang quyen.
const DANGEROUS_PERMS = [
  P.Administrator,
  P.BanMembers,
  P.KickMembers,
  P.ManageGuild,
  P.ManageRoles,
  P.ManageChannels,
  P.ManageWebhooks,
  P.ManageGuildExpressions,
  P.ManageNicknames,
  P.ModerateMembers,
  P.MentionEveryone,
];
const DANGEROUS_MASK = DANGEROUS_PERMS.reduce((acc, p) => acc | p, 0n);

const DEFAULT_SNAPSHOT_INTERVAL_MS = 15 * 60_000; // 15 phut
const MIN_WINDOW_MS = 1_000;
const MAX_WINDOW_MS = 24 * 3_600_000;

const clampInt = (v, min, max, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.trunc(n))) : fallback;
};

// Chuan hoa 1 module doc tu file: gia tri hong/ngoai pham vi -> ve mac dinh, khong de bot chay voi limit = 0.
function sanitizeModuleConfig(raw, def) {
  const m = raw && typeof raw === 'object' ? raw : {};
  return {
    enabled: typeof m.enabled === 'boolean' ? m.enabled : true,
    limit: clampInt(m.limit, 1, 100, def.limit),
    windowMs: clampInt(m.windowMs, MIN_WINDOW_MS, MAX_WINDOW_MS, def.windowMs),
    punishment: PUNISHMENTS.includes(m.punishment) ? m.punishment : def.punishment,
  };
}

function buildDefaultGuildConfig() {
  const modules = {};
  for (const [key, def] of Object.entries(MODULE_DEFS)) modules[key] = sanitizeModuleConfig(null, def);
  return {
    logChannelId: null,
    whitelistedUsers: [],
    whitelistedRoles: [],
    whitelistedBots: [],
    extraOwners: [], // nguoi duoc chu server uy quyen chinh cau hinh anti-nuke (mac dinh chi chu server)
    strippedRoles: {}, // userId -> { roleIds, at, module } de /antinuke unstrip hoan tra khi bi phat nham
    snapshotIntervalMs: DEFAULT_SNAPSHOT_INTERVAL_MS,
    modules,
  };
}

module.exports = {
  PUNISHMENTS,
  MODULE_DEFS,
  DANGEROUS_PERMS,
  DANGEROUS_MASK,
  DEFAULT_SNAPSHOT_INTERVAL_MS,
  MIN_WINDOW_MS,
  MAX_WINDOW_MS,
  clampInt,
  sanitizeModuleConfig,
  buildDefaultGuildConfig,
};
