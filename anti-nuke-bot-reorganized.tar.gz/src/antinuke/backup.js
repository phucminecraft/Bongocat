'use strict';
// Snapshot cau truc server + khoi phuc toan dien.
//
// Cac loi thiet ke cua ban cu da duoc sua:
//  * Snapshot bi "dau doc": ban cu ghi de 1 file duy nhat moi 15 phut, nen neu server vua bi nuke
//    ma den luc chup thi snapshot tot bi thay bang trang thai da pha -> khong con gi de khoi phuc.
//    Nay: giu LICH SU vai snapshot khac nhau, DONG BANG khi dang bi tan cong, va danh dau
//    "nghi van" neu so luong role/channel tut manh (restore mac dinh bo qua snapshot nghi van).
//  * Restore khop theo ten (name+type) nen 2 kenh trung ten chi duoc tao lai 1 kenh, kenh bi doi
//    ten thi bi tao them ban trung. Nay: khop theo ID truoc, roi moi khop theo ten tung cai mot.
//  * 2 lan restore chay dong thoi tao ra kenh/role trung -> nay co khoa theo guild + gop yeu cau.
//  * Role duoc tao lai khong co thanh vien nao -> nay luu role -> thanh vien va gan lai.
//  * Category duoc tao lai khong nhan lai kenh con; parentId cu tro vao category da chet -> nay map ID cu -> moi.
//  * Ghi file dong bo, khong nguyen tu -> nay ghi bat dong bo + nguyen tu (tmp + rename).
const path = require('path');
const crypto = require('crypto');
const { ChannelType, Events } = require('discord.js');
const { ensureDir, readJson, JsonWriter } = require('../util/fsx');
const { serializeRole, serializeChannel, OVERWRITE_MEMBER } = require('./serialize');
const storage = require('./storage');
const { DEFAULT_SNAPSHOT_INTERVAL_MS } = require('./config');

const DIR = path.join(__dirname, '..', '..', 'data', 'guilds');
ensureDir(DIR);

const MAX_HISTORY = 6;
const MIN_ITEMS_FOR_GUARD = 8; // server qua nho thi khong ap dung canh bao "tut manh"
const SHRINK_RATIO = 0.7; // it hon 70% so muc cua snapshot truoc -> nghi van
const SUSPECT_CLEAR_MS = 24 * 3_600_000;
const MEMBER_FETCH_LIMIT = 50_000;
const MAX_ROLE_ASSIGNMENTS = 250_000;
const LEGIT_TTL_MS = 6 * 3_600_000;
const FOLLOW_UP_MS = 8_000;

const writer = new JsonWriter(200);
const history = new Map(); // guildId -> [snapshot moi nhat truoc]
const fileOf = (guildId) => path.join(DIR, `${guildId}.snapshot.json`);
const isCategory = (c) => c.type === ChannelType.GuildCategory;
const tick = () => new Promise((r) => setImmediate(r));

// ------------------------------------------------------------------ lich su snapshot

const hashOf = (roles, channels) => crypto.createHash('sha1').update(JSON.stringify([roles, channels])).digest('hex');

// Ban cu luu 1 object { takenAt, roles, channels } va overwrite dang { rawId, roleName }: doi sang cau truc moi.
function normalize(s) {
  const channels = (s.channels || []).map((c) =>
    c.overwrites
      ? c
      : {
          ...c,
          id: c.id ?? null,
          parentId: c.parentId ?? null,
          overwrites: (c.permissionOverwrites || []).map((o) => ({
            id: o.rawId ?? o.id,
            type: o.type,
            roleName: o.roleName ?? null,
            allow: o.allow,
            deny: o.deny,
          })),
        }
  );
  const roles = s.roles || [];
  return { ...s, roles, channels, hash: s.hash ?? hashOf(roles, channels) };
}

function loadHistory(guildId) {
  if (history.has(guildId)) return history.get(guildId);
  let list = [];
  const { value } = readJson(fileOf(guildId));
  if (value) {
    if (Array.isArray(value.snapshots)) list = value.snapshots;
    else if (Array.isArray(value.roles) && Array.isArray(value.channels)) list = [value];
  }
  list = list.filter((s) => s && Array.isArray(s.roles) && Array.isArray(s.channels)).map(normalize);
  history.set(guildId, list);
  return list;
}

function persist(guildId) {
  writer.schedule(fileOf(guildId), () => ({ version: 2, snapshots: history.get(guildId) || [] }));
}

function listSnapshots(guildId) {
  return loadHistory(guildId);
}

// index: 1 = moi nhat. Mac dinh: snapshot moi nhat KHONG bi nghi van (neu khong co thi lay moi nhat).
function pickSnapshot(guildId, index = null) {
  const list = loadHistory(guildId);
  if (index) return list[index - 1] ?? null;
  return list.find((s) => !s.suspect) ?? list[0] ?? null;
}

function trim(list) {
  while (list.length > MAX_HISTORY) {
    const keep = list.findIndex((s) => !s.suspect); // khong bao gio vut snapshot tot nhat con lai
    let idx = list.length - 1;
    if (idx === keep) idx -= 1;
    list.splice(idx, 1);
  }
}

// ------------------------------------------------------------------ dong bang / danh dau xoa hop le

const frozen = new Map(); // guildId -> until
function freeze(guildId, ms) {
  const until = Date.now() + ms;
  if (until > (frozen.get(guildId) ?? 0)) frozen.set(guildId, until);
}
const isFrozen = (guildId) => (frozen.get(guildId) ?? 0) > Date.now();

// Chu server / nguoi duoc whitelist chu dong xoa channel/role -> restore khong duoc "hoi sinh" no.
const legit = new Map(); // guildId -> Map("kind:id" -> ts)
function markLegitDelete(guildId, kind, id) {
  if (!id) return;
  let m = legit.get(guildId);
  if (!m) legit.set(guildId, (m = new Map()));
  const now = Date.now();
  if (m.size > 2000) for (const [key, ts] of m) if (now - ts > LEGIT_TTL_MS) m.delete(key);
  m.set(`${kind}:${id}`, now);
}
function isLegitDeleted(guildId, kind, id) {
  const ts = id ? legit.get(guildId)?.get(`${kind}:${id}`) : null;
  return Boolean(ts && Date.now() - ts < LEGIT_TTL_MS);
}

// ------------------------------------------------------------------ chup snapshot

async function ensureMembers(guild) {
  const total = guild.memberCount || 0;
  const have = () => guild.members.cache.size;
  if (!total) return false;
  if (have() >= total * 0.98) return true;
  if (total > MEMBER_FETCH_LIMIT) return have() >= total * 0.9;
  try {
    await guild.members.fetch({ time: 60_000 });
  } catch (err) {
    console.warn(`[backup] Khong fetch du thanh vien guild ${guild.id}: ${err.message}`);
  }
  return have() >= total * 0.9;
}

// role -> danh sach thanh vien (chi khi cache thanh vien day du). Chia nho de khong chan event loop.
async function collectRoleMembers(guild, roleIds) {
  const wanted = new Set(roleIds);
  const out = {};
  let total = 0;
  let n = 0;
  for (const member of guild.members.cache.values()) {
    for (const rid of member.roles.cache.keys()) {
      if (!wanted.has(rid)) continue;
      (out[rid] ??= []).push(member.id);
      total += 1;
    }
    if (++n % 1000 === 0) await tick();
  }
  return total > MAX_ROLE_ASSIGNMENTS ? null : out;
}

async function buildSnapshot(guild, withMembers) {
  const roles = guild.roles.cache
    .filter((r) => r.id !== guild.id && !r.managed) // @everyone va role cua bot/integration khong the tao lai
    .map(serializeRole)
    .sort((a, b) => b.position - a.position || a.id.localeCompare(b.id));
  const channels = guild.channels.cache
    .filter((c) => !c.isThread?.())
    .map((c) => serializeChannel(guild, c))
    .sort((a, b) => Number(isCategory(b)) - Number(isCategory(a)) || a.position - b.position || a.id.localeCompare(b.id));
  const roleMembers = withMembers ? await collectRoleMembers(guild, roles.map((r) => r.id)) : null;
  return { takenAt: Date.now(), hash: hashOf(roles, channels), roles, channels, roleMembers };
}

function commit(guildId, snap, { force = false } = {}) {
  const list = loadHistory(guildId);
  const newest = list[0];
  const size = (s) => s.roles.length + s.channels.length;

  let suspect = false;
  if (!force && newest) {
    if (size(newest) >= MIN_ITEMS_FOR_GUARD && size(snap) < size(newest) * SHRINK_RATIO) suspect = true;
    else if (newest.suspect && newest.hash === snap.hash && Date.now() - (newest.suspectSince ?? newest.takenAt) < SUSPECT_CLEAR_MS) suspect = true;
  }
  snap.suspect = suspect;

  let status;
  if (newest && newest.hash === snap.hash) {
    newest.takenAt = snap.takenAt;
    if (snap.roleMembers) newest.roleMembers = snap.roleMembers;
    if (newest.suspect && !suspect) {
      newest.suspect = false;
      delete newest.suspectSince;
    }
    status = suspect ? 'suspect' : 'unchanged';
  } else {
    if (suspect) snap.suspectSince = snap.takenAt;
    list.unshift(snap);
    trim(list);
    status = suspect ? 'suspect' : 'new';
  }

  // Chi giu danh sach thanh vien cho vai snapshot moi nhat + snapshot tot nhat de file khong phinh to.
  const keep = new Set([0, 1, list.findIndex((s) => !s.suspect)]);
  list.forEach((s, i) => {
    if (!keep.has(i)) delete s.roleMembers;
  });
  persist(guildId);
  return { status, snapshot: list[0], snapshotsKept: list.length };
}

// force = true: nguoi dung xac nhan trang thai hien tai la tot (bo qua dong bang + canh bao tut manh).
async function takeSnapshot(guild, { force = false } = {}) {
  if (guild.available === false) return { status: 'skipped', reason: 'server khong kha dung' };
  if (!force && isFrozen(guild.id)) return { status: 'frozen' };
  if (!guild.channels.cache.size && !guild.roles.cache.size) return { status: 'skipped', reason: 'cache chua san sang' };
  const complete = await ensureMembers(guild);
  const snap = await buildSnapshot(guild, complete);
  if (!force && isFrozen(guild.id)) return { status: 'frozen' }; // co the vua bi tan cong trong luc dang chup
  return commit(guild.id, snap, { force });
}

async function safeSnapshot(guild, opts) {
  try {
    const res = await takeSnapshot(guild, opts);
    if (res.status === 'suspect') console.warn(`[backup] Snapshot guild ${guild.id} bi danh dau NGHI VAN (so role/channel tut manh) - restore se dung snapshot truoc do.`);
    return res;
  } catch (err) {
    console.warn(`[backup] Snapshot that bai cho guild ${guild.id}: ${err.message}`);
    return { status: 'error', error: err.message };
  }
}

// ------------------------------------------------------------------ khoi phuc

const locks = new Map();
function withLock(guildId, fn) {
  const prev = locks.get(guildId) ?? Promise.resolve();
  const run = prev.catch(() => {}).then(fn);
  locks.set(guildId, run);
  run
    .finally(() => {
      if (locks.get(guildId) === run) locks.delete(guildId);
    })
    .catch(() => {});
  return run;
}

function mergeById(base = [], over = []) {
  const map = new Map();
  let i = 0;
  for (const item of base) map.set(item.id ?? `noid:${i++}`, item);
  for (const item of over) map.set(item.id ?? `noid:${i++}`, item); // du lieu luc bi xoa chinh xac hon snapshot
  return [...map.values()];
}

async function assignMembers(guild, jobs, reason) {
  const queue = jobs.slice();
  let ok = 0;
  const worker = async () => {
    while (queue.length) {
      const { memberId, roleId } = queue.shift();
      const member = guild.members.cache.get(memberId) ?? (await guild.members.fetch(memberId).catch(() => null));
      if (!member || member.roles.cache.has(roleId)) continue;
      try {
        await member.roles.add(roleId, reason);
        ok += 1;
      } catch {
        /* thanh vien da roi / thieu quyen */
      }
    }
  };
  await Promise.all(Array.from({ length: 4 }, worker));
  return ok;
}

// Doi chieu trang thai mong muon (snapshot + du lieu vat vua bi xoa) voi trang thai hien tai, chi tao cai con thieu.
// Idempotent: chay lai nhieu lan khong tao trung.
async function reconcile(guild, { snapshotIndex = null, hints = {}, reason = 'Anti-Nuke: khoi phuc sau nuke', restoreMembers = true } = {}) {
  const snap = pickSnapshot(guild.id, snapshotIndex);
  const result = { rolesCreated: 0, categoriesCreated: 0, channelsCreated: 0, reparented: 0, membersQueued: 0, membersTask: null, errors: 0, snapshotAt: snap?.takenAt ?? null };
  const hintRoles = (hints.roles || []).filter(Boolean);
  const hintChannels = (hints.channels || []).filter(Boolean);
  if (!snap && !hintRoles.length && !hintChannels.length) return result;
  const fail = (what, err) => {
    result.errors += 1;
    console.warn(`[backup] restore ${what} loi: ${err.message}`);
  };

  const desiredRoles = mergeById(snap?.roles, hintRoles).filter((r) => r.name && !r.managed && !isLegitDeleted(guild.id, 'role', r.id));
  const desiredChannels = mergeById(snap?.channels, hintChannels).filter((c) => c.name && !isLegitDeleted(guild.id, 'channel', c.id));

  // ---- 1) ROLE
  const roleMap = new Map(); // id cu (trong snapshot) -> Role hien tai
  const usedRoles = new Set();
  for (const r of desiredRoles) {
    const cur = r.id && guild.roles.cache.get(r.id);
    if (cur) {
      roleMap.set(r.id, cur);
      usedRoles.add(cur.id);
    }
  }
  const createdRoles = []; // { role, def }: role moi tao, chua co thanh vien
  const emptyTwins = []; // role trung ten da duoc tao lai truoc do (vd luot restore truoc) nhung trong
  const missingRoles = desiredRoles.filter((r) => !(r.id && roleMap.has(r.id))).sort((a, b) => (b.position ?? 0) - (a.position ?? 0));
  for (const r of missingRoles) {
    const twin = guild.roles.cache.find((x) => x.id !== guild.id && !x.managed && !usedRoles.has(x.id) && x.name === r.name);
    if (twin) {
      usedRoles.add(twin.id);
      if (r.id) roleMap.set(r.id, twin);
      if (twin.members.size === 0) emptyTwins.push({ role: twin, def: r });
      continue;
    }
    try {
      const role = await guild.roles.create({
        name: r.name,
        color: r.color ?? 0,
        hoist: Boolean(r.hoist),
        mentionable: Boolean(r.mentionable),
        permissions: BigInt(r.permissions ?? 0),
        reason,
      });
      usedRoles.add(role.id);
      if (r.id) roleMap.set(r.id, role);
      createdRoles.push({ role, def: r });
      result.rolesCreated += 1;
    } catch (err) {
      fail(`role "${r.name}"`, err);
    }
  }
  // Vi tri role (best-effort, khong the vuot role cao nhat cua bot).
  const me = guild.members.me;
  if (createdRoles.length && me) {
    const cap = me.roles.highest.position - 1;
    if (cap > 0) {
      try {
        await guild.roles.setPositions(createdRoles.map(({ role, def }) => ({ role: role.id, position: Math.max(1, Math.min(def.position || 1, cap)) })));
      } catch {
        /* khong sap xep duoc thi de nguyen */
      }
    }
  }

  // ---- 2) CHANNEL / CATEGORY (category truoc)
  const chMap = new Map(); // id cu -> Channel hien tai
  const usedCh = new Set();
  for (const c of desiredChannels) {
    const cur = c.id && guild.channels.cache.get(c.id);
    if (cur) {
      chMap.set(c.id, cur);
      usedCh.add(cur.id);
    }
  }
  const resolveOverwrites = (c) =>
    (c.overwrites || [])
      .map((o) => {
        let id = null;
        if (o.type === OVERWRITE_MEMBER) id = guild.members.cache.has(o.id) ? o.id : null;
        else if (o.id === guild.id) id = guild.id;
        else id = roleMap.get(o.id)?.id ?? (guild.roles.cache.has(o.id) ? o.id : (o.roleName && guild.roles.cache.find((r) => r.name === o.roleName)?.id) || null);
        return id ? { id, type: o.type, allow: BigInt(o.allow ?? 0), deny: BigInt(o.deny ?? 0) } : null;
      })
      .filter(Boolean);
  const resolveParent = (c) => {
    if (isCategory(c)) return undefined;
    if (c.parentId) {
      const p = chMap.get(c.parentId) ?? guild.channels.cache.get(c.parentId);
      if (p && isCategory(p)) return p.id;
    }
    if (c.parentName) return guild.channels.cache.find((x) => isCategory(x) && x.name === c.parentName)?.id;
    return undefined;
  };

  const missingCh = desiredChannels.filter((c) => !(c.id && chMap.has(c.id)));
  const byPos = (a, b) => (a.position ?? 0) - (b.position ?? 0);
  const ordered = [...missingCh.filter(isCategory).sort(byPos), ...missingCh.filter((c) => !isCategory(c)).sort(byPos)];
  for (const c of ordered) {
    const twin = guild.channels.cache.find((x) => !usedCh.has(x.id) && x.type === c.type && x.name === c.name);
    if (twin) {
      usedCh.add(twin.id);
      if (c.id) chMap.set(c.id, twin);
      continue;
    }
    try {
      const created = await guild.channels.create({
        name: c.name,
        type: c.type,
        parent: resolveParent(c),
        position: c.position,
        topic: c.topic,
        nsfw: c.nsfw,
        bitrate: c.bitrate ? Math.min(c.bitrate, guild.maximumBitrate ?? c.bitrate) : undefined,
        userLimit: c.userLimit,
        rateLimitPerUser: c.rateLimitPerUser,
        permissionOverwrites: resolveOverwrites(c),
        reason,
      });
      usedCh.add(created.id);
      if (c.id) chMap.set(c.id, created);
      if (isCategory(c)) result.categoriesCreated += 1;
      else result.channelsCreated += 1;
    } catch (err) {
      fail(`channel "${c.name}"`, err);
    }
  }

  // ---- 3) Kenh con con song sot nhung mat category cha (category bi xoa -> kenh con thanh "mo coi")
  for (const c of desiredChannels) {
    if (!c.parentId || isCategory(c)) continue;
    const cur = chMap.get(c.id);
    // "Mo coi" = khong co cha, HOAC cha tro toi category da bi xoa (cache co the chua kip cap nhat parentId).
    if (!cur || (cur.parentId && guild.channels.cache.has(cur.parentId))) continue;
    const parent = chMap.get(c.parentId);
    if (!parent || !isCategory(parent)) continue;
    try {
      await cur.setParent(parent.id, { lockPermissions: false, reason });
      result.reparented += 1;
    } catch (err) {
      fail(`gan lai category cho "${c.name}"`, err);
    }
  }

  // ---- 4) Gan lai thanh vien cho role vua duoc tao (chay nen, khong chan phan hoi)
  if (restoreMembers && snap?.roleMembers) {
    const jobs = [];
    for (const { role, def } of [...createdRoles, ...emptyTwins]) {
      for (const memberId of snap.roleMembers[def.id] || []) jobs.push({ memberId, roleId: role.id });
    }
    result.membersQueued = jobs.length;
    if (jobs.length) result.membersTask = assignMembers(guild, jobs, reason).catch(() => 0);
  }
  return result;
}

const restoreAll = (guild, opts) => withLock(guild.id, () => reconcile(guild, opts));

// Duoc goi khi phat hien nuke. Cac yeu cau den sat nhau duoc GOP lai thanh 1 luot, va sau do
// chay them 1 luot quet du (vet not nhung hanh dong dang bay tren duong truyen luc bi xu phat).
const queued = new Map();
const followUps = new Map();
function requestRestore(guild, hints = {}) {
  let q = queued.get(guild.id);
  if (q) {
    q.hints.channels.push(...(hints.channels || []));
    q.hints.roles.push(...(hints.roles || []));
    return q.promise;
  }
  q = { hints: { channels: [...(hints.channels || [])], roles: [...(hints.roles || [])] } };
  q.promise = withLock(guild.id, () => {
    queued.delete(guild.id);
    return reconcile(guild, { hints: q.hints });
  });
  queued.set(guild.id, q);
  scheduleFollowUp(guild);
  return q.promise;
}

function scheduleFollowUp(guild) {
  if (followUps.has(guild.id)) return;
  const t = setTimeout(() => {
    followUps.delete(guild.id);
    restoreAll(guild, {}).catch((err) => console.warn(`[backup] Luot quet du that bai: ${err.message}`));
  }, FOLLOW_UP_MS);
  t.unref?.();
  followUps.set(guild.id, t);
}

// ------------------------------------------------------------------ tu dong chup dinh ky

const auto = { client: null, timers: new Map() };

function scheduleFor(guildId) {
  const old = auto.timers.get(guildId);
  if (old) clearInterval(old);
  const config = storage.getGuildConfig(guildId);
  const intervalMs = Math.max(config.snapshotIntervalMs || DEFAULT_SNAPSHOT_INTERVAL_MS, 60_000);
  const timer = setInterval(() => {
    const g = auto.client?.guilds.cache.get(guildId);
    if (g) safeSnapshot(g);
  }, intervalMs);
  timer.unref?.();
  auto.timers.set(guildId, timer);
}

// Doi khoang cach ngay lap tuc (ban cu bat khoi dong lai bot).
function reschedule(guildId) {
  if (auto.client) scheduleFor(guildId);
}

function clearGuild(guildId) {
  const t = auto.timers.get(guildId);
  if (t) clearInterval(t);
  auto.timers.delete(guildId);
  history.delete(guildId);
  frozen.delete(guildId);
  legit.delete(guildId);
}

function startAutoSnapshot(client) {
  auto.client = client;
  for (const g of client.guilds.cache.values()) {
    const t = setTimeout(() => safeSnapshot(g), 2_000 + Math.random() * 20_000); // le thoi diem, tranh don API cung luc
    t.unref?.();
    scheduleFor(g.id);
  }
  client.on(Events.GuildCreate, (g) => {
    safeSnapshot(g);
    scheduleFor(g.id);
  });
  client.on(Events.GuildDelete, (g) => {
    if (g.available === false) return; // mat ket noi tam thoi, khong phai bi kick
    clearGuild(g.id);
  });
  return auto.timers;
}

module.exports = {
  takeSnapshot,
  safeSnapshot,
  restoreAll,
  requestRestore,
  listSnapshots,
  pickSnapshot,
  freeze,
  isFrozen,
  markLegitDelete,
  isLegitDeleted,
  startAutoSnapshot,
  reschedule,
  clearGuild,
  // xuat cho test
  _commit: commit,
  _buildSnapshot: buildSnapshot,
  _reset: () => {
    history.clear();
    frozen.clear();
    legit.clear();
    queued.clear();
  },
};
