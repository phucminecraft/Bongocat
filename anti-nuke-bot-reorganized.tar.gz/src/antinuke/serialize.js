'use strict';
// Chuyen role/channel thanh object JSON thuan (dung cho snapshot va cho bo nho dem vat vua bi xoa).
// Ca 2 hinh thuc (tu doi tuong song va tu audit log) tra ve CUNG MOT cau truc de restore xu ly chung.
const OVERWRITE_MEMBER = 1;

function serializeRole(role) {
  return {
    id: role.id,
    name: role.name,
    color: role.color,
    hoist: role.hoist,
    mentionable: role.mentionable,
    permissions: role.permissions.bitfield.toString(),
    position: role.position,
    managed: Boolean(role.managed),
  };
}

function serializeChannel(guild, c) {
  const ows = c.permissionOverwrites?.cache;
  return {
    id: c.id,
    name: c.name,
    type: c.type,
    parentId: c.parentId ?? null,
    parentName: c.parent?.name ?? null,
    position: c.rawPosition ?? c.position ?? 0,
    topic: c.topic ?? undefined,
    nsfw: c.nsfw ?? undefined,
    bitrate: c.bitrate ?? undefined,
    userLimit: c.userLimit ?? undefined,
    rateLimitPerUser: c.rateLimitPerUser ?? undefined,
    overwrites: ows
      ? ows.map((o) => ({
          id: o.id,
          type: o.type,
          roleName: o.type === OVERWRITE_MEMBER ? null : guild.roles.cache.get(o.id)?.name ?? null,
          allow: o.allow.bitfield.toString(),
          deny: o.deny.bitfield.toString(),
        }))
      : [],
  };
}

const oldOf = (entry, key) => entry.changes?.find((c) => c.key === key)?.old;

// Du phong khi bo nho dem khong co: dung gia tri "old" ma audit log ghi lai luc xoa.
function channelFromAudit(entry) {
  const name = oldOf(entry, 'name');
  if (!name) return null;
  const ows = oldOf(entry, 'permission_overwrites');
  return {
    id: entry.targetId,
    name,
    type: oldOf(entry, 'type') ?? 0,
    parentId: oldOf(entry, 'parent_id') ?? null,
    parentName: null,
    position: oldOf(entry, 'position') ?? 0,
    topic: oldOf(entry, 'topic') ?? undefined,
    nsfw: oldOf(entry, 'nsfw') ?? undefined,
    bitrate: oldOf(entry, 'bitrate') ?? undefined,
    userLimit: oldOf(entry, 'user_limit') ?? undefined,
    rateLimitPerUser: oldOf(entry, 'rate_limit_per_user') ?? undefined,
    overwrites: Array.isArray(ows)
      ? ows.map((o) => ({
          id: o.id,
          type: o.type === OVERWRITE_MEMBER || o.type === 'member' ? OVERWRITE_MEMBER : 0,
          roleName: null,
          allow: String(o.allow ?? 0),
          deny: String(o.deny ?? 0),
        }))
      : [],
  };
}

function roleFromAudit(entry) {
  const name = oldOf(entry, 'name');
  if (!name) return null;
  return {
    id: entry.targetId,
    name,
    color: oldOf(entry, 'color') ?? 0,
    hoist: oldOf(entry, 'hoist') ?? false,
    mentionable: oldOf(entry, 'mentionable') ?? false,
    permissions: String(oldOf(entry, 'permissions') ?? 0),
    position: 0,
    managed: false,
  };
}

module.exports = { serializeRole, serializeChannel, channelFromAudit, roleFromAudit, OVERWRITE_MEMBER };
