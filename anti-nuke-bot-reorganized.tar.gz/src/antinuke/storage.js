'use strict';
// Luu cau hinh tung server ra data/guilds/<guildId>.json, co cache trong bo nho.
// Ghi debounce + nguyen tu (tmp + rename); file hong duoc giu lai thay vi bi ghi de.
const path = require('path');
const { ensureDir, readJson, JsonWriter } = require('../util/fsx');
const { MODULE_DEFS, buildDefaultGuildConfig, sanitizeModuleConfig, clampInt, DEFAULT_SNAPSHOT_INTERVAL_MS } = require('./config');

const DATA_DIR = path.join(__dirname, '..', '..', 'data', 'guilds');
ensureDir(DATA_DIR);

const SNOWFLAKE = /^\d{5,25}$/;
const MAX_STRIPPED = 100;
const cache = new Map();
const writer = new JsonWriter(300);

function filePath(guildId) {
  if (!SNOWFLAKE.test(String(guildId))) throw new Error('guildId khong hop le');
  return path.join(DATA_DIR, `${guildId}.json`);
}

const idList = (v) => [...new Set((Array.isArray(v) ? v : []).map(String).filter((s) => SNOWFLAKE.test(s)))];

function mergeWithDefaults(raw) {
  const def = buildDefaultGuildConfig();
  const src = raw && typeof raw === 'object' ? raw : {};
  const modules = {};
  for (const [key, d] of Object.entries(MODULE_DEFS)) modules[key] = sanitizeModuleConfig(src.modules?.[key], d);

  const stripped = {};
  if (src.strippedRoles && typeof src.strippedRoles === 'object') {
    for (const [uid, rec] of Object.entries(src.strippedRoles)) {
      if (SNOWFLAKE.test(uid) && rec && Array.isArray(rec.roleIds)) {
        stripped[uid] = { roleIds: idList(rec.roleIds), at: Number(rec.at) || 0, module: String(rec.module || '') };
      }
    }
  }

  return {
    ...def,
    logChannelId: SNOWFLAKE.test(String(src.logChannelId)) ? String(src.logChannelId) : null,
    whitelistedUsers: idList(src.whitelistedUsers),
    whitelistedRoles: idList(src.whitelistedRoles),
    whitelistedBots: idList(src.whitelistedBots),
    extraOwners: idList(src.extraOwners),
    strippedRoles: stripped,
    snapshotIntervalMs: clampInt(src.snapshotIntervalMs, 60_000, 24 * 3_600_000, DEFAULT_SNAPSHOT_INTERVAL_MS),
    modules,
  };
}

function getGuildConfig(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const { value, corrupted } = readJson(filePath(guildId));
  if (corrupted) console.error(`[antinuke] Cau hinh guild ${guildId} bi hong -> dung mac dinh (file cu da duoc giu lai de cuu du lieu).`);
  const config = mergeWithDefaults(value);
  cache.set(guildId, config);
  return config;
}

function saveGuildConfig(guildId, config) {
  cache.set(guildId, config);
  writer.schedule(filePath(guildId), () => cache.get(guildId));
}

// Ghi nho role vua bi go de /antinuke unstrip hoan tra neu phat nham.
function recordStripped(guildId, userId, roleIds, moduleKey) {
  if (!roleIds?.length) return;
  const config = getGuildConfig(guildId);
  const prev = config.strippedRoles[userId];
  const merged = [...new Set([...(prev?.roleIds || []), ...roleIds])];
  config.strippedRoles[userId] = { roleIds: merged, at: Date.now(), module: moduleKey };
  const users = Object.keys(config.strippedRoles);
  if (users.length > MAX_STRIPPED) {
    users.sort((a, b) => config.strippedRoles[a].at - config.strippedRoles[b].at);
    for (const u of users.slice(0, users.length - MAX_STRIPPED)) delete config.strippedRoles[u];
  }
  saveGuildConfig(guildId, config);
}

function takeStripped(guildId, userId) {
  const config = getGuildConfig(guildId);
  const rec = config.strippedRoles[userId] || null;
  if (rec) {
    delete config.strippedRoles[userId];
    saveGuildConfig(guildId, config);
  }
  return rec;
}

function flushAll() {
  writer.flushAllSync();
}

module.exports = { getGuildConfig, saveGuildConfig, recordStripped, takeStripped, flushAll, mergeWithDefaults, DATA_DIR };
