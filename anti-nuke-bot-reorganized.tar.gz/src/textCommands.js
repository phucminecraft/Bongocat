'use strict';
// Cau lenh THU 2 va THU 3 ben canh slash command: goi lenh bang prefix (vd "!ban @user spam") hoac
// bang cach tag/mention thang bot (vd "@BongoCat ban @user spam"). Ca hai deu di qua CUNG MOT dong
// logic voi slash command (cmd.execute(i)) - khong viet lai tung lenh. Cach lam: doc SCHEMA that ma
// moi lenh da khai bao qua SlashCommandBuilder (cmd.data.toJSON()) de biet lenh do co subcommand/
// subcommand-group gi, moi option ten gi/kieu gi/co bat buoc khong/co choices gi - roi "dich" chuoi
// text nguoi dung go thanh dung cai i.options.getX(...) ma execute() dang mong doi. Nho vay: THEM
// 1 lenh moi (hoac sua option cua lenh cu) trong commands.js/antinuke.js la TU DONG co ca prefix
// lan tag-command, khong can dong nao code them o day.
//
// An toan: khong tu bo qua permission check. Moi lenh trong commands.js/antinuke.js da tu re-check
// quyen bang i.memberPermissions (xem allowed()/authorize() trong 2 file do) chu KHONG chi dua vao
// Discord an lenh o UI (Discord chi an duoc slash command, khong an duoc tin nhan thuong) - nen chi
// can shim nay gan dung i.memberPermissions = quyen THAT cua nguoi goi la cac lenh tu dong duoc gac
// dung nhu slash command, khong can vict lai logic phan quyen o day.
const { EmbedBuilder } = require('discord.js');
const { commands: moderationCommands } = require('./moderation/commands');
const antinuke = require('./antinuke/commands/antinuke');
const core = require('./moderation/core');

// ------------------------------------------------------------ registry: gop lenh moderation + antinuke, doc san schema 1 lan

const REGISTRY = new Map(
  [...moderationCommands, { data: antinuke.data, execute: antinuke.execute }].map((c) => {
    const schema = c.data.toJSON();
    return [schema.name.toLowerCase(), { schema, execute: c.execute }];
  })
);

// ------------------------------------------------------------ regex nhan dien mention/ID va cac gia tri dac biet

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const RE_USER = /^<@!?(\d{5,25})>$/;
const RE_CHANNEL = /^<#(\d{5,25})>$/;
const RE_ROLE = /^<@&(\d{5,25})>$/;
const RE_ID = /^\d{5,25}$/;
const RE_BOOL = /^(true|false|yes|no|on|off|bat|tat|c[oó]|kh[oô]ng|1|0)$/i;
const RE_TRUE = /^(true|yes|on|bat|c[oó]|1)$/i;
const RE_NUM = /^-?\d+(\.\d+)?$/;

function extractId(token, kind) {
  const re = kind === 'user' ? RE_USER : kind === 'channel' ? RE_CHANNEL : kind === 'role' ? RE_ROLE : null;
  const m = re?.exec(token);
  if (m) return m[1];
  return RE_ID.test(token) ? token : null;
}

// ------------------------------------------------------------ Pass 1: tach cac tham so go tuong minh "ten:gia_tri"

// Voi nhieu tag lien tiep, gia tri cua 1 tag la tu sau dau ":" cua no den truoc tag ke tiep (hoac het
// chuoi) - vay nen ho tro duoc gia tri nhieu tu ma khong can nguoi dung go dau nhay ("reason:bi report
// nhieu lan spam kenh chung duration:1d" -> reason="bi report nhieu lan spam kenh chung", duration="1d").
function splitTags(text, optionNames) {
  if (!optionNames.length) return { prefixText: text, tags: {} };
  const re = new RegExp(`\\b(${optionNames.map(escapeRegex).join('|')})\\s*:\\s*`, 'gi');
  const matches = [...text.matchAll(re)];
  if (!matches.length) return { prefixText: text, tags: {} };
  const tags = {};
  for (let idx = 0; idx < matches.length; idx++) {
    const m = matches[idx];
    const name = m[1].toLowerCase();
    const start = m.index + m[0].length;
    const end = idx + 1 < matches.length ? matches[idx + 1].index : text.length;
    const value = text.slice(start, end).trim().replace(/^["'](.*)["']$/, '$1');
    if (value) tags[name] = value;
  }
  return { prefixText: text.slice(0, matches[0].index), tags };
}

// ------------------------------------------------------------ Pass 2: dien not cac option chua duoc tag, theo vi tri

// options da bi loai tru nhung cai da co trong "tags"; tokens la mang con lai (bi sua tai cho - splice/shift).
// Voi option STRING khong phai option-STRING cuoi cung, chi lay 1 token khi con DU token de danh lai
// cho cac option-STRING con lai phia sau (moi option can it nhat 1 tu) - tranh vi du "!ban @user spam"
// (chi 1 tu, khong dinh keo duration) gan nham "spam" vao duration (dat truoc reason) roi bao loi
// "thoi han khong hop le"; khi ro rang thieu token cho ca 2, tu do se danh cho option-STRING CUOI
// (thuong la reason/text - huu ich hon duration khi phai chon 1 trong 2).
function assignPositional(options, tokens) {
  const raw = {};
  const stringIdxs = options.map((o, idx) => (o.type === 3 ? idx : -1)).filter((idx) => idx !== -1);
  for (let idx = 0; idx < options.length; idx++) {
    const o = options[idx];
    if (o.type === 6 || o.type === 7 || o.type === 8) {
      const kind = o.type === 6 ? 'user' : o.type === 7 ? 'channel' : 'role';
      const i = tokens.findIndex((t) => extractId(t, kind) != null);
      if (i !== -1) raw[o.name] = tokens.splice(i, 1)[0];
    } else if (o.type === 5) {
      const i = tokens.findIndex((t) => RE_BOOL.test(t));
      if (i !== -1) raw[o.name] = tokens.splice(i, 1)[0];
    } else if (o.type === 4 || o.type === 10) {
      const i = tokens.findIndex((t) => RE_NUM.test(t));
      if (i !== -1) raw[o.name] = tokens.splice(i, 1)[0];
    } else if (o.type === 3) {
      const isLastString = stringIdxs[stringIdxs.length - 1] === idx;
      if (isLastString) {
        if (tokens.length) raw[o.name] = tokens.splice(0).join(' ');
      } else {
        const stringSlotsAfter = stringIdxs.filter((i) => i > idx).length;
        if (tokens.length > stringSlotsAfter) raw[o.name] = tokens.shift();
      }
    }
  }
  return raw;
}

// ------------------------------------------------------------ quy doi 1 gia tri tho (string) sang dung kieu discord.js mong doi

async function resolveValue(message, option, raw) {
  if (raw == null) return undefined;
  switch (option.type) {
    case 3: { // STRING
      if (!option.choices?.length) return raw;
      const low = raw.toLowerCase();
      const hit =
        option.choices.find((c) => String(c.value).toLowerCase() === low) ??
        option.choices.find((c) => c.name.toLowerCase() === low) ??
        option.choices.find((c) => c.name.toLowerCase().startsWith(low));
      return hit ? hit.value : raw;
    }
    case 4: case 10: { // INTEGER / NUMBER
      let n = Number(raw);
      if (!Number.isFinite(n)) return undefined;
      if (option.type === 4) n = Math.trunc(n);
      if (option.min_value !== undefined) n = Math.max(option.min_value, n);
      if (option.max_value !== undefined) n = Math.min(option.max_value, n);
      return n;
    }
    case 5: // BOOLEAN
      return RE_TRUE.test(raw);
    case 6: { // USER
      const id = extractId(raw, 'user');
      if (!id) return undefined;
      const member = message.guild.members.cache.get(id) ?? (await message.guild.members.fetch(id).catch(() => null));
      if (member) return { user: member.user, member };
      const user = await message.client.users.fetch(id).catch(() => null);
      return user ? { user, member: null } : undefined;
    }
    case 7: { // CHANNEL
      const id = extractId(raw, 'channel');
      return id ? (message.guild.channels.cache.get(id) ?? undefined) : undefined;
    }
    case 8: { // ROLE
      const id = extractId(raw, 'role');
      return id ? (message.guild.roles.cache.get(id) ?? undefined) : undefined;
    }
    default:
      return raw;
  }
}

async function resolveOptions(message, options, argsText) {
  const { prefixText, tags } = splitTags(argsText, options.map((o) => o.name));
  const untagged = options.filter((o) => !(o.name.toLowerCase() in tags));
  const positionalRaw = assignPositional(untagged, prefixText.trim().length ? prefixText.trim().split(/\s+/) : []);
  const resolved = {};
  for (const o of options) {
    const raw = tags[o.name.toLowerCase()] ?? positionalRaw[o.name];
    if (raw === undefined) continue;
    const v = await resolveValue(message, o, raw);
    if (v !== undefined) resolved[o.name] = v;
  }
  return resolved;
}

// ------------------------------------------------------------ tim subcommand/subcommand-group tu cac token dau tien

function resolvePath(schema, tokens) {
  const first = schema.options?.[0];
  if (!first || (first.type !== 1 && first.type !== 2)) return { node: schema, sub: null, group: null, consumed: 0 };
  const t1 = (tokens[0] || '').toLowerCase();
  const top = schema.options.find((o) => o.name.toLowerCase() === t1);
  if (!top) return { error: `Thiếu subcommand cho \`${schema.name}\`. Các lựa chọn: ${schema.options.map((o) => o.name).join(', ')}` };
  if (top.type === 1) return { node: top, sub: top.name, group: null, consumed: 1 };
  const t2 = (tokens[1] || '').toLowerCase();
  const subNode = (top.options || []).find((o) => o.name.toLowerCase() === t2);
  if (!subNode) return { error: `Thiếu subcommand trong nhóm \`${top.name}\`. Các lựa chọn: ${(top.options || []).map((o) => o.name).join(', ')}` };
  return { node: subNode, sub: subNode.name, group: top.name, consumed: 2 };
}

// ------------------------------------------------------------ shim: gia lap ChatInputCommandInteraction tu 1 Message

function buildInteraction(message, { group, sub, resolvedOptions }) {
  let deferred = false;
  let replied = false;
  let sentMessage = null;
  const stripFlags = (payload) => {
    const p = typeof payload === 'string' ? { content: payload } : { ...payload };
    delete p.flags; // "ephemeral" khong co y nghia voi tin nhan thuong - cu gui binh thuong trong kenh
    return p;
  };
  const get = (name, required, pick) => {
    const v = resolvedOptions[name];
    const val = pick ? pick(v) : v;
    if (val === undefined || val === null) {
      if (required) throw new Error(`Thiếu tham số bắt buộc: ${name}`);
      return null;
    }
    return val;
  };
  return {
    guild: message.guild,
    member: message.member,
    user: message.author,
    channel: message.channel,
    client: message.client,
    // Dung permissionsIn(channel) chu KHONG dung member.permissions thang: member.permissions la quyen
    // CAP GUILD (theo role), con mot slash command that nhan duoc i.memberPermissions da tinh theo TUNG
    // KENH tu Discord (co ap dung channel overwrite). Neu dung member.permissions o day, ai bi mot kenh
    // rieng thu hoi quyen (vd bi overwrite chan Ban Members trong 1 kenh cu the) van co the lach qua
    // lenh prefix/tag-bot trong dung kenh do - dung permissionsIn moi khop chinh xac voi slash command that.
    memberPermissions: message.member.permissionsIn(message.channel),
    inGuild: () => !!message.guild,
    get deferred() { return deferred; },
    get replied() { return replied; },
    deferReply: async () => {
      deferred = true;
      sentMessage = await message.reply('⏳ Đang xử lý...').catch(() => null);
    },
    reply: async (payload) => {
      replied = true;
      sentMessage = await message.reply(stripFlags(payload)).catch(() => null);
      return sentMessage;
    },
    editReply: async (payload) => {
      replied = true;
      const p = stripFlags(payload);
      if (sentMessage?.edit) return sentMessage.edit(p).catch(() => {});
      sentMessage = await message.reply(p).catch(() => null);
      return sentMessage;
    },
    options: {
      getSubcommand: (required = true) => { if (!sub && required) throw new Error('Thiếu subcommand'); return sub; },
      getSubcommandGroup: (required = true) => { if (!group && required) throw new Error('Thiếu subcommand group'); return group ?? null; },
      getString: (name, required = false) => get(name, required),
      getInteger: (name, required = false) => get(name, required),
      getBoolean: (name, required = false) => get(name, required),
      getChannel: (name, required = false) => get(name, required),
      getRole: (name, required = false) => get(name, required),
      getUser: (name, required = false) => get(name, required, (v) => v?.user),
      getMember: (name) => resolvedOptions[name]?.member ?? null,
    },
  };
}

// ------------------------------------------------------------ trigger: prefix hay tag/mention bot, va lenh help nhe

function helpEmbed(prefix) {
  const lines = [...REGISTRY.values()].map((e) => `\`${e.schema.name}\` — ${e.schema.description}`);
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('Các lệnh')
    .setDescription(
      `Gọi lệnh bằng 1 trong 3 cách: **slash** (\`/tên-lệnh\`), **prefix** (\`${prefix ? `${prefix}tên-lệnh ...` : '(đang tắt, xem /prefix)'}\`), hoặc **tag bot** (\`@Bot tên-lệnh ...\`).\n` +
        `Cách dùng option: theo thứ tự (\`ban @user 7d spam\`) hoặc gọi tên (\`ban user:@x reason:spam\`).\n\n${lines.join('\n')}`
    );
}

// Tra ve { rest, isMention } neu tin nhan la 1 lan goi lenh (prefix hoac tag bot), nguoc lai null.
function detectTrigger(content, prefix, botId) {
  const m = new RegExp(`^<@!?${botId}>\\s*`).exec(content);
  if (m) return { rest: content.slice(m[0].length).trim(), isMention: true };
  if (prefix && content.startsWith(prefix)) return { rest: content.slice(prefix.length).trim(), isMention: false };
  return null;
}

// ------------------------------------------------------------ entry point (goi tu moderation/index.js, TRUOC automod)

// Tra ve true neu tin nhan da duoc xu ly nhu 1 lenh (de noi goi biet ma bo qua automod cho tin do).
async function handleMessage(client, message) {
  if (!message.guild || !message.member || message.author?.bot) return false;
  const store = core.load(message.guild.id);
  const trigger = detectTrigger(message.content ?? '', store.config.prefix, client.user.id);
  if (!trigger) return false;

  const tokens = trigger.rest.length ? trigger.rest.split(/\s+/) : [];
  const cmdName = (tokens.shift() || '').toLowerCase();

  if (!cmdName) {
    if (trigger.isMention) await message.reply({ embeds: [helpEmbed(store.config.prefix)] }).catch(() => {});
    return trigger.isMention; // go mot minh "!" (khong phai mention) thi im lang, tranh spam trong chat thuong
  }
  if (['help', 'giupdo', 'trogiup'].includes(cmdName)) {
    await message.reply({ embeds: [helpEmbed(store.config.prefix)] }).catch(() => {});
    return true;
  }

  const entry = REGISTRY.get(cmdName);
  if (!entry) {
    // Prefix (vd "!") de dung 1 mo hinh rat pho bien trong chat thuong -> lenh la thay doi thi im lang,
    // khong bao "khong tim thay lenh" cho moi tin nhan tinh co bat dau bang ky tu prefix. Tag bot thi
    // khac: mention thang bot la tin hieu ro rang muon goi lenh nen dang bao huu ich.
    if (trigger.isMention) await message.reply(`Không có lệnh \`${cmdName}\`. Gõ \`@${message.client.user.username ?? 'bot'} help\` để xem danh sách.`).catch(() => {});
    return trigger.isMention;
  }

  const path = resolvePath(entry.schema, tokens);
  if (path.error) {
    await message.reply(path.error).catch(() => {});
    return true;
  }

  let resolvedOptions;
  try {
    resolvedOptions = await resolveOptions(message, path.node.options || [], tokens.slice(path.consumed).join(' '));
  } catch (err) {
    await message.reply(`Không thể xử lý lệnh: ${err.message}`).catch(() => {});
    return true;
  }

  const i = buildInteraction(message, { group: path.group, sub: path.sub, resolvedOptions });
  try {
    await entry.execute(i);
  } catch (err) {
    console.error('[text-command]', err);
    await message.reply('Đã xảy ra lỗi khi xử lý lệnh.').catch(() => {});
  }
  return true;
}

module.exports = { handleMessage, REGISTRY };
