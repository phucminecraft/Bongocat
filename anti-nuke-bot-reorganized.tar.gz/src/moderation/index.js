'use strict';
// Lap rap toan bo he thong moderation vao 1 client co san: dang ky lenh, hook
// message/member event cho automod + slowmode + mute-khi-vao-lai, chay timer
// unban/unmute het han. Viec flush du lieu khi tat bot do src/index.js dam nhiem (goi flushAllSync)
// de KHONG co 2 trinh xu ly SIGINT/SIGTERM cung goi process.exit va chen ngang nhau.
const { Events, MessageFlags } = require('discord.js');
const { commands, automodAutocomplete } = require('./commands');
const core = require('./core');
const automod = require('./automod');
const voiceProtection = require('./voiceProtection');
const floodProtection = require('./floodProtection');
const textCommands = require('../textCommands');

const byName = new Map(commands.map((c) => [c.data.name, c]));

function setupModeration(client) {
  client.on(Events.InteractionCreate, async (interaction) => {
    // rule option cua /automod punish|delete|keyword ... vuot 25 lua chon tinh (xem commands.js) nen
    // dung autocomplete - phai xu ly RIENG, khac hoan toan isChatInputCommand() ben duoi.
    if (interaction.isAutocomplete() && interaction.commandName === 'automod') {
      try {
        await automodAutocomplete(interaction);
      } catch (err) {
        console.error('[moderation] loi autocomplete:', err);
      }
      return;
    }
    if (!interaction.isChatInputCommand()) return;
    const cmd = byName.get(interaction.commandName);
    if (!cmd) return;
    try {
      await cmd.execute(interaction);
    } catch (err) {
      console.error('[moderation]', err);
      const content = 'Da xay ra loi khi xu ly lenh.';
      if (interaction.deferred || interaction.replied) interaction.editReply({ content }).catch(() => {});
      else interaction.reply({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  });

  client.on(Events.MessageCreate, async (message) => {
    try {
      // Lenh dang tin nhan (prefix "!..." hoac tag "@Bot ..."): kiem tra TRUOC automod, vi 1 lenh
      // hop le khong phai la "noi dung chat" can loc tu/spam.
      const handledAsCommand = await textCommands.handleMessage(client, message);
      if (handledAsCommand) return;
      const handled = await automod.handleMessage(client, message);
      if (!handled) await automod.handleSlowmode(client, message);
    } catch (err) {
      console.error('[automod]', err);
    }
  });

  // Nguoi dung sua tin de qua mat bo loc lan dau -> quet lai (tru spam, vi spam
  // tinh theo tan suat gui, khong lien quan noi dung sua).
  client.on(Events.MessageUpdate, async (_old, message) => {
    if (!message.partial) automod.handleMessage(client, message, { edit: true }).catch((err) => console.error('[automod]', err));
  });

  // Voice Protection: can GatewayIntentBits.GuildVoiceStates (xem src/index.js).
  client.on(Events.VoiceStateUpdate, (oldState, newState) => {
    voiceProtection.handleVoiceStateUpdate(client, oldState, newState).catch((err) => console.error('[voice-protection]', err));
  });
  // Soundboard: chi nhan duoc khi bot dang o trong kenh thoai do (gioi han cua Discord, xem voiceProtection.js).
  client.on(Events.VoiceChannelEffectSend, (effect) => {
    voiceProtection.handleVoiceChannelEffectSend(client, effect).catch((err) => console.error('[voice-protection]', err));
  });

  // Thread Spam: can Events.Guilds (da co san, xem src/index.js) - khong can intent rieng.
  client.on(Events.ThreadCreate, (thread, newlyCreated) => {
    floodProtection.handleThreadCreate(client, thread, newlyCreated).catch((err) => console.error('[flood-protection]', err));
  });

  // Reaction Spam: can GatewayIntentBits.GuildMessageReactions (xem src/index.js).
  client.on(Events.MessageReactionAdd, (reaction, user) => {
    floodProtection.handleReactionAdd(client, reaction, user).catch((err) => console.error('[flood-protection]', err));
  });

  client.on(Events.ChannelCreate, (channel) => core.protectNewChannel(channel));

  client.on(Events.GuildMemberAdd, (member) => core.applyMuteOnJoin(member).catch((err) => console.error('[moderation]', err)));

  client.once(Events.ClientReady, () => core.startTimers(client));
}

module.exports = { setupModeration, commands, flushAllSync: core.flushAllSync, voiceProtection, floodProtection };
