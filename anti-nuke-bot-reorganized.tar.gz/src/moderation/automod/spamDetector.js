'use strict';
// Moi loai duoi day dung CHUNG 1 co che cua so truot (checkSpam ben duoi): amountFor tra ve cho 1
// TIN don le, checkSpam tu cong don trong cua so va so voi limit.count. Nho vay 1 tin "qua nguong"
// ngay (vd 1 tin dinh 50 emoji) va nhieu tin nho gop lai trong 1 khoang thoi gian (vd 5 tin x 3
// emoji) deu duoc phat hien nhu nhau, khong can code rieng cho "trong 1 tin" va "trong nhieu tin
// lien tiep".
const { INVITE_RE, LINK_RE, EMOJI_RE, GIF_RE, EVERYONE_RE, HERE_RE } = require('./patterns');

const windows = new Map(); // key -> { windowMs, items: [{ ts, amount, msgId, chId, hash }] }

const isGifAttachment = (a) => a.contentType === 'image/gif' || /\.gifv?$/i.test(a.name || '');
const isImageAttachment = (a) => (a.contentType || '').startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|avif)$/i.test(a.name || '');
const isVideoAttachment = (a) => (a.contentType || '').startsWith('video/') || /\.(mp4|webm|mov|mkv|avi)$/i.test(a.name || '');

function amountFor(kind, message, text) {
  switch (kind) {
    case 'messages':
    case 'duplicates':
    case 'rapidMessages': // giong 'messages' (1 tin = 1 don vi) nhung dung nguong/cua so RIENG, thuong ngan+chat hon de bat burst kieu bot
      return 1;
    case 'mentions':
      return message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 1 : 0);
    case 'roleMentions':
      return message.mentions.roles.size;
    case 'everyoneMentions':
      return (text.match(EVERYONE_RE) || []).length;
    case 'hereMentions':
      return (text.match(HERE_RE) || []).length;
    case 'links':
      return (text.match(LINK_RE) || []).length;
    // inviteLinks: dem SO LUONG link moi (bat ke dan toi server nao) de bat hanh vi spam-link-moi lien
    // tuc - khac rule `invites` (inviteFilter.js, chan link moi dan toi server LA, kiem tra tuc thi tung tin).
    case 'inviteLinks':
      return (text.match(INVITE_RE) || []).length;
    case 'emojis':
      return (text.match(EMOJI_RE) || []).length;
    case 'attachments':
      return message.attachments.size;
    case 'images':
      return [...message.attachments.values()].filter(isImageAttachment).length;
    case 'videos':
      return [...message.attachments.values()].filter(isVideoAttachment).length;
    case 'gifs':
      return (text.match(GIF_RE) || []).length + [...message.attachments.values()].filter(isGifAttachment).length;
    case 'stickers':
      return message.stickers?.size ?? 0;
    case 'embeds':
      return message.embeds?.length ?? 0;
    case 'polls':
      return message.poll ? 1 : 0;
    default:
      return 0;
  }
}

function checkSpam(cfg, message, text) {
  if (!cfg.enabled) return null;
  const now = Date.now();
  const hash = text.trim().toLowerCase().slice(0, 200);
  for (const [kind, limit] of Object.entries(cfg.limits)) {
    if (!limit) continue;
    if (kind === 'duplicates' && !hash) continue;
    const amount = amountFor(kind, message, text);
    if (!amount) continue;
    const key = `${message.guildId}:${message.author.id}:${kind}`;
    const windowMs = limit.seconds * 1000;
    const win = windows.get(key) ?? { windowMs, items: [] };
    win.windowMs = windowMs;
    win.items = win.items.filter((i) => now - i.ts <= windowMs);
    win.items.push({ ts: now, amount, msgId: message.id, chId: message.channelId, hash });
    windows.set(key, win);
    const relevant = kind === 'duplicates' ? win.items.filter((i) => i.hash === hash) : win.items;
    const total = kind === 'duplicates' ? relevant.length : relevant.reduce((s, i) => s + i.amount, 0);
    if (total >= limit.count) {
      windows.delete(key); // reset dong bo -> tin ke tiep dem lai tu dau, khong bi phat lap
      return { detail: `${total} ${kind} trong ${limit.seconds}s`, items: relevant };
    }
  }
  return null;
}

module.exports = { amountFor, checkSpam, windows };
