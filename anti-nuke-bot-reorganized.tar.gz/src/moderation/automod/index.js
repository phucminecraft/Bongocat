'use strict';
// Automod (loc tu, link moi server, spam) + cuong che slowmode do bot quan ly: diem vao duy nhat
// duoc moderation/index.js goi tu event messageCreate/messageUpdate. Toc do: viec kiem tra tin nhan
// la dong bo (khong I/O); chi khi vi pham moi goi API, va xoa tin / phat / thong bao / ghi log chay
// song song bang Promise.allSettled (xem enforcement.js).
// Lap rap tu cac tinh nang rieng trong thu muc nay va export LAI DUNG BO MAT PHANG nhu automod.js
// truoc day, de commands/ va cac file test tiep tuc require('./automod')/require('../automod')
// khong can sua gi.
const core = require('../core');
const { normalize, buildWordRegex } = require('../textMatch');
const keywordFilters = require('../keywordFilters'); // 26 rule Keyword & Phrase Filters moi (item 2-28) - xem file do
const { checkWords } = require('./wordFilter');
const { checkInvites } = require('./inviteFilter');
const { checkCharacterSpam } = require('./characterSpam');
const { checkSpam, amountFor, windows } = require('./spamDetector');
const { setBuiltinSpamRule } = require('./builtinSpamRule');
const { enforce, recentPunish, noticeAt } = require('./enforcement');

const skipMessage = (client, m) => !m.guild || !m.author || m.author.bot || m.system || m.webhookId || m.author.id === client.user.id;

// Tra ve true neu tin nhan da bi xu ly (de cac buoc sau bo qua).
async function handleMessage(client, message, { edit = false } = {}) {
  if (skipMessage(client, message)) return false;
  const guild = message.guild;
  const cfg = core.load(guild.id).config.automod;
  if (!cfg.enabled) return false;
  const member = message.member;
  if (!member || core.isExempt(member, message.channel, cfg)) return false;

  const text = normalize(message.content || '');
  // Tin "khong chu" (chi sticker / chi poll) van phai duoc xet cho rule spam (stickers/polls) - khong
  // chi bo qua vi thieu attachments nhu truoc day (luc do chi co rule spam dua tren van ban/file).
  if (!text && !message.attachments?.size && !message.stickers?.size && !message.poll) return false;

  // Keyword Whitelist (item 28): mien tru MOI rule "tu khoa" mot luc (words + toan bo rule trong
  // keywordFilters.js + Required Phrases), kiem tra TRUOC tat ca - KHONG anh huong invites/
  // characters/spam (nhung rule do thuoc nhom khac: link moi/spam ky tu/spam tan suat, khong phai
  // "tu khoa"). Profanity/Slurs/Sexual Content KHONG can mien tru o day vi do la AutoMod rule GOC cua
  // Discord (chay o phia Discord, tin da bi chan truoc khi toi bot) - mien tru cho 3 rule do dat qua
  // exemptRoles/exemptChannels khi tao rule (xem keywordFilters.js).
  const whitelisted = keywordFilters.checkWhitelist(cfg.whitelist, text);

  let rule = null;
  let hit = whitelisted ? null : checkWords(cfg.words, text);
  if (hit) rule = 'words';
  if (!hit) {
    hit = await checkInvites(client, guild, cfg.invites, text);
    if (hit) rule = 'invites';
  }
  if (!hit && !whitelisted) {
    const kw = keywordFilters.checkKeywordRules(cfg, text);
    if (kw) {
      hit = kw.hit;
      rule = kw.rule;
    }
  }
  if (!hit && !whitelisted) {
    hit = keywordFilters.checkRequiredPhrases(cfg.requiredPhrases, message, text);
    if (hit) rule = 'requiredPhrases';
  }
  // characters: check noi dung nhu words/invites -> quet lai duoc ca khi sua tin (khac spam ben duoi).
  if (!hit) {
    hit = checkCharacterSpam(cfg.characters, text);
    if (hit) rule = 'characters';
  }
  if (!hit && !edit) {
    hit = checkSpam(cfg.spam, message, text);
    if (hit) rule = 'spam';
  }
  if (!hit) return false;

  await enforce(client, message, member, rule, cfg[rule], hit);
  return true;
}

// ------------------------------------------------------------ slowmode do bot cuong che

async function handleSlowmode(client, message) {
  if (skipMessage(client, message)) return false;
  const store = core.load(message.guild.id);
  const sm = store.config.slowmodes[message.channelId];
  if (!sm || sm.mode !== 'bot') return false;
  const member = message.member;
  if (!member || core.hasBypassPerm(member)) return false; // giong Discord: mod co ManageMessages/ManageChannels khong bi slowmode

  const now = Date.now();
  const last = (store.data.slowmodeLast[message.channelId] ??= {});
  const prev = last[message.author.id];
  const waitMs = prev ? sm.seconds * 1000 - (now - prev) : 0;
  if (waitMs > 0) {
    const jobs = [message.delete()];
    const key = `slow:${message.channelId}:${message.author.id}`;
    if (!(noticeAt.get(key) > now - 15_000)) {
      noticeAt.set(key, now);
      jobs.push(
        message.channel
          .send({ content: `${member}, kenh dang slowmode: cho them ${core.formatDuration(waitMs)}.`, allowedMentions: { users: [member.id] } })
          .then((m) => setTimeout(() => m.delete().catch(() => {}), 5000).unref?.())
      );
    }
    await Promise.allSettled(jobs);
    return true;
  }
  last[message.author.id] = now;
  const ids = Object.keys(last);
  if (ids.length > 5000) for (const id of ids) if (now - last[id] > sm.seconds * 1000) delete last[id];
  return false; // slowmodeLast chi la trang thai tam trong RAM: khong ghi ca file case/cau hinh moi tin nhan nua
}

const sweep = setInterval(() => {
  const now = Date.now();
  for (const [key, win] of windows) {
    const last = win.items[win.items.length - 1];
    if (!last || now - last.ts > win.windowMs) windows.delete(key);
  }
  for (const [key, ts] of recentPunish) if (now - ts > 30_000) recentPunish.delete(key);
  for (const [key, ts] of noticeAt) if (now - ts > 60_000) noticeAt.delete(key);
}, 60_000);
sweep.unref?.();

module.exports = {
  handleMessage, handleSlowmode, buildWordRegex, checkWords, checkSpam, checkCharacterSpam,
  setBuiltinSpamRule, amountFor, normalize, windows,
};
