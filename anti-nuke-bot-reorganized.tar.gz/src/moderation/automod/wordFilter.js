'use strict';
// Loc tu (rule "words" - Bad Words, item 1). Cac rule Keyword & Phrase Filters MOI (Profanity,
// Slurs, Scam Keywords, Regex Filters, v.v. - item 2-28) nam trong ../keywordFilters.js, duoc goi
// tu automod/index.js (handleMessage), khong dinh nghia lai o day.
// Rule nay KHONG cho nguoi dung nhap regex tuy y (ReDoS): tu khoa chi dung wildcard `*` va duoc
// escape + gioi han truoc khi bien dich (xem buildWordRegex trong ../textMatch.js).
const { truncate } = require('../core');
const { buildWordRegex } = require('../textMatch');

function checkWords(cfg, text) {
  if (!cfg.enabled || !cfg.list.length) return null;
  const re = buildWordRegex(cfg.list, cfg.wholeWord);
  const m = re?.exec(text);
  return m ? { detail: `tu khoa "${truncate(m[0], 40)}"` } : null;
}

module.exports = { checkWords };
