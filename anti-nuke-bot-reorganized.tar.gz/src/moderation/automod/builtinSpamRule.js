'use strict';
// Spam content built-in cua Discord (item 29). Doc lap voi `limits` (spamDetector.js, bot tu dem
// theo cua so truot): day la 1 AutoMod rule GOC cua Discord (trigger_type Spam) dung ML cua Discord
// de chan "noi dung spam chung chung" (link/tu lap lai kieu quang cao...) MA KHONG can bot doc noi
// dung - hoat dong ngay ca khi bot offline. Discord chi cho toi da 1 rule loai nay/server nen ham
// nay tu tim rule cu (do CHINH bot nay tao) truoc khi tao moi.
const { AutoModerationRuleTriggerType, AutoModerationRuleEventType, AutoModerationActionType } = require('discord.js');

async function setBuiltinSpamRule(guild, enabled) {
  if (typeof guild.autoModerationRules?.fetch !== 'function') return { ok: false, reason: 'Khong ho tro AutoMod tren server nay.' };
  let rules;
  try {
    rules = await guild.autoModerationRules.fetch();
  } catch (err) {
    return { ok: false, reason: `Khong doc duoc danh sach AutoMod rule: ${err.message}` };
  }
  const mine = rules?.find?.((r) => r.triggerType === AutoModerationRuleTriggerType.Spam && r.creatorId === guild.client.user.id);
  if (!enabled) {
    if (mine) {
      try {
        await mine.delete('Automod: tat Spam Content built-in');
      } catch (err) {
        return { ok: false, reason: `Khong xoa duoc AutoMod rule: ${err.message}` };
      }
    }
    return { ok: true };
  }
  if (mine) return { ok: true }; // da co san, khong tao trung (Discord chi cho 1 rule Spam/server)
  try {
    await guild.autoModerationRules.create({
      name: 'Automod - Spam Content (built-in)',
      eventType: AutoModerationRuleEventType.MessageSend,
      triggerType: AutoModerationRuleTriggerType.Spam,
      actions: [{ type: AutoModerationActionType.BlockMessage }],
      enabled: true,
      reason: 'Automod: bat Spam Content built-in',
    });
  } catch (err) {
    // Thuong gap: bot thieu quyen Manage Server, hoac server da co san 1 rule Spam do nguoi khac tao thu cong.
    return { ok: false, reason: `Khong tao duoc AutoMod rule (can quyen Manage Server, toi da 1 rule Spam/server): ${err.message}` };
  }
  return { ok: true };
}

module.exports = { setBuiltinSpamRule };
