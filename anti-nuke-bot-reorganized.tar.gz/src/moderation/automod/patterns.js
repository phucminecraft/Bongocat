'use strict';
// Regex dung chung giua nhieu tinh nang automod (vd INVITE_RE dung boi ca inviteFilter.js va
// spamDetector.js voi 2 muc dich khac nhau - xem ghi chu trong tung file do). Gom 1 noi de tranh
// dinh nghia lech nhau o nhieu file.
const INVITE_RE = /(?:discord(?:app)?\.com\/invite|discord\.gg|dsc\.gg|discord\.me)\/([a-z0-9-]{2,32})/gi;
const LINK_RE = /https?:\/\/[^\s<>]+/gi;
const EMOJI_RE = /<a?:\w+:\d+>|\p{Extended_Pictographic}/gu;
const GIF_RE = /https?:\/\/(?:[\w-]+\.)?(?:tenor\.com|giphy\.com)\/\S+/gi;
const EVERYONE_RE = /@everyone/gi;
const HERE_RE = /@here/gi;

module.exports = { INVITE_RE, LINK_RE, EMOJI_RE, GIF_RE, EVERYONE_RE, HERE_RE };
