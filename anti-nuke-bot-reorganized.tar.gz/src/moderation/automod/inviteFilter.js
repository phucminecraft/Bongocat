'use strict';
// Chan link moi server khac (rule "invites"). Khac `spam.limits.inviteLinks` (spamDetector.js) o
// cho: rule nay chan NGAY LAP TUC link moi dan toi server LA, con inviteLinks chi dem TAN SUAT gui
// link moi (bat ke dan toi server nao, ke ca invite cua chinh server).
const { INVITE_RE } = require('./patterns');

const inviteCache = new Map(); // code -> { guildId|null, exp }

async function resolveInvite(client, code) {
  const hit = inviteCache.get(code);
  if (hit && hit.exp > Date.now()) return hit.guildId;
  let guildId = null;
  try {
    guildId = (await client.fetchInvite(code)).guild?.id ?? null;
  } catch {
    /* invite het han/khong ton tai -> coi la khong ro nguon */
  }
  if (inviteCache.size > 500) inviteCache.clear();
  inviteCache.set(code, { guildId, exp: Date.now() + (guildId ? 600_000 : 60_000) });
  return guildId;
}

async function checkInvites(client, guild, cfg, text) {
  if (!cfg.enabled) return null;
  const codes = [...new Set([...text.matchAll(INVITE_RE)].map((m) => m[1].toLowerCase()))].slice(0, 5);
  if (!codes.length) return null;
  const ids = await Promise.all(codes.map((c) => resolveInvite(client, c)));
  const bad = ids.findIndex((id) => id !== guild.id && !cfg.allowGuilds.includes(id));
  return bad === -1 ? null : { detail: `invite discord.gg/${codes[bad]}` };
}

module.exports = { resolveInvite, checkInvites };
