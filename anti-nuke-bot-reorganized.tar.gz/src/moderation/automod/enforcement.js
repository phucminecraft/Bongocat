'use strict';
// Xu ly vi pham: dung CHUNG cho moi rule content (words/invites/characters/spam/keywordFilters) sau
// khi mot rule da "hit". (hasBypassPerm/isExempt nam o ../core - dung chung voi Voice Protection).
const core = require('../core');
const keywordFilters = require('../keywordFilters'); // 26 rule Keyword & Phrase Filters moi (item 2-28) - xem file do

// REASONS: cau thong bao CONG KHAI trong kenh cho 4 rule GOC (words/invites/characters/spam). Cac
// rule moi (keywordFilters.js, item 2-28) khong lap lai o day - reasonText() duoi day tu dong lay
// nhan/cau mo ta tu keywordFilters.reasonFor() cho bat ky rule nao khong co trong REASONS.
const REASONS = {
  words: 'tin nhan chua tu ngu bi cam.',
  invites: 'khong duoc gui link moi server khac.',
  characters: 'vui long khong go spam ky tu.',
  spam: 'vui long khong spam.',
};
const reasonText = (rule) => REASONS[rule] ?? keywordFilters.reasonFor(rule);

const recentPunish = new Map(); // "guild:user:rule" -> ts (chong phat lap khi nhieu tin den cung luc)
const noticeAt = new Map(); // dung chung voi handleSlowmode (../index.js) cho thong bao "cho them Ns"

async function deleteTracked(message, items) {
  const byChannel = new Map([[message.channelId, new Set([message.id])]]);
  for (const i of items ?? []) {
    if (!byChannel.has(i.chId)) byChannel.set(i.chId, new Set());
    byChannel.get(i.chId).add(i.msgId);
  }
  const jobs = [];
  for (const [chId, ids] of byChannel) {
    const arr = [...ids];
    if (chId === message.channelId && arr.length === 1) {
      jobs.push(message.delete());
      continue;
    }
    const ch = message.guild.channels.cache.get(chId);
    if (!ch) continue;
    for (let i = 0; i < arr.length; i += 100) {
      const chunk = arr.slice(i, i + 100);
      jobs.push(chunk.length === 1 ? ch.messages.delete(chunk[0]) : ch.bulkDelete(chunk, true));
    }
  }
  await Promise.allSettled(jobs);
}

// Duong rieng cho cac rule danh dau notifyStaff (mac dinh chi Self-Harm Keywords, item 12): KHONG
// goi cong khai trong kenh chat (tranh cong khai hoa/goi ten mot nguoi co the dang gap kho khan), KHONG
// tu dong xu phat (bo qua ruleCfg.punish du admin co dat gi di nua - "thong bao rieng THAY VI xu phat"),
// chi xoa tin neu ruleCfg.delete=true (mac dinh false: giu lai tin de staff doc duoc toan bo ngu canh)
// va gui 1 embed RIENG vao kenh log (khong ping cong khai) de staff chu dong lien he.
async function enforceNotifyStaff(client, message, member, rule, ruleCfg) {
  const guild = message.guild;
  const jobs = [];
  if (ruleCfg.delete === true) jobs.push(deleteTracked(message));
  const link = `https://discord.com/channels/${guild.id}/${message.channelId}/${message.id}`;
  jobs.push(
    Promise.resolve(
      core.sendLog(
        guild,
        core
          .caseEmbed({
            id: '-',
            type: 'warn',
            userId: member.id,
            userTag: core.tagOf(member.user),
            modId: client.user.id,
            modTag: core.tagOf(client.user),
            reason: `Automod [${rule}]: phat hien tu khoa nhay cam. Tin nhan${ruleCfg.delete === true ? ' (da xoa)' : ''}: ${link}`,
            createdAt: Date.now(),
          })
          .setTitle(`Automod | ${rule} — CANH BAO RIENG cho staff (khong cong khai)`)
      )
    )
  );
  const results = await Promise.allSettled(jobs);
  const failed = results.filter((r) => r.status === 'rejected');
  if (failed.length) console.warn(`[automod] ${failed.length} hanh dong that bai (notifyStaff/${rule}): ${failed[0].reason?.message}`);
}

async function enforce(client, message, member, rule, ruleCfg, hit) {
  const guild = message.guild;
  if (ruleCfg.notifyStaff) return enforceNotifyStaff(client, message, member, rule, ruleCfg);
  const reason = `Automod [${rule}]: ${hit.detail}`;
  const jobs = [];
  if (ruleCfg.delete !== false) jobs.push(deleteTracked(message, hit.items));

  const noticeKey = `${guild.id}:${member.id}:${rule}`;
  if (!(noticeAt.get(noticeKey) > Date.now() - 15_000)) {
    noticeAt.set(noticeKey, Date.now());
    jobs.push(
      message.channel
        .send({ content: `${member}, ${reasonText(rule)}`, allowedMentions: { users: [member.id] } })
        .then((m) => setTimeout(() => m.delete().catch(() => {}), 6000).unref?.())
    );
  }

  const punish = ruleCfg.punish;
  const pKey = `${guild.id}:${member.id}:${rule}`;
  const canPunish = punish && punish.type !== 'none' && member.id !== guild.ownerId && !(recentPunish.get(pKey) > Date.now() - 8000);
  if (canPunish) {
    recentPunish.set(pKey, Date.now());
    jobs.push(core.applyPunish(client, guild, member, punish, reason));
  }

  const results = await Promise.allSettled(jobs);
  const failed = results.filter((r) => r.status === 'rejected');
  if (failed.length) console.warn(`[automod] ${failed.length} hanh dong that bai (${reason}): ${failed[0].reason?.message}`);

  // Neu co phat thi case da tu log; chi log rieng khi chi xoa tin.
  if (!canPunish) {
    core.sendLog(
      guild,
      core.caseEmbed({ id: '-', type: 'warn', userId: member.id, userTag: core.tagOf(member.user), modId: client.user.id, modTag: core.tagOf(client.user), reason, createdAt: Date.now() })
        .setTitle(`Automod | ${rule}`)
    );
  }
}

module.exports = { deleteTracked, enforceNotifyStaff, enforce, recentPunish, noticeAt };
