'use strict';
// Character Spam: check TUC THI tren 1 tin (giong words/invites): tin nhan gan nhu chi gom 1 ky tu
// lap lai, vd "aaaaaaaaaa" hoac "!!!!!!!!!!!!". Dung Array.from (khong dung .length) de dem dung ky
// tu ke ca emoji/surrogate-pair thay vi dem sai theo code unit UTF-16.

function checkCharacterSpam(cfg, text) {
  if (!cfg.enabled) return null;
  const compact = text.replace(/\s+/g, '');
  if (compact.length < cfg.minLength) return null;
  const chars = Array.from(compact);
  if (chars.length < cfg.minLength) return null;
  const freq = new Map();
  let run = 1;
  let maxRun = 1;
  let runChar = chars[0];
  freq.set(chars[0], 1);
  for (let idx = 1; idx < chars.length; idx++) {
    const c = chars[idx];
    freq.set(c, (freq.get(c) || 0) + 1);
    if (c === chars[idx - 1]) {
      run++;
      if (run > maxRun) {
        maxRun = run;
        runChar = c;
      }
    } else {
      run = 1;
    }
  }
  if (maxRun >= cfg.minRun) return { detail: `ky tu "${runChar}" lap ${maxRun} lan lien tiep` };
  let topChar = chars[0];
  let topCount = 0;
  for (const [c, n] of freq) {
    if (n > topCount) {
      topCount = n;
      topChar = c;
    }
  }
  if (topCount / chars.length >= cfg.minRatio) {
    return { detail: `ky tu "${topChar}" chiem ${Math.round((topCount / chars.length) * 100)}% tin nhan` };
  }
  return null;
}

module.exports = { checkCharacterSpam };
