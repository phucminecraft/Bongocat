'use strict';
// Lenh: /warn /note /case /cases - lop giao dien cho he thong case trong ../../core (cases.js).
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const core = require('../core');
const { allowed, resolveMember, reasonOf, userOpt, wrap, caseLabel, embed, okEmbed, fail, EPH } = require('./shared');

const warn = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Canh cao mot nguoi dung (ghi vao case)')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi bi canh cao'))
    .addStringOption((o) => o.setName('reason').setDescription('Ly do').setRequired(true)),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const user = i.options.getUser('user', true);
    const r = resolveMember(i, { required: false });
    if (r.error) return fail(i, r.error);
    const c = core.warnUser(i.guild, core.who(i.user), core.who(user), reasonOf(i));
    return i.reply({ embeds: [okEmbed(`Da canh cao **${core.tagOf(user)}**. ${caseLabel(c)}`)] });
  }),
};

const note = {
  data: new SlashCommandBuilder()
    .setName('note')
    .setDescription('Them ghi chu noi bo ve mot nguoi dung')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => userOpt(o))
    .addStringOption((o) => o.setName('text').setDescription('Noi dung ghi chu').setRequired(true).setMaxLength(500)),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const user = i.options.getUser('user', true);
    const c = core.noteUser(i.guild, core.who(i.user), core.who(user), i.options.getString('text', true));
    return i.reply({ embeds: [okEmbed(`Da ghi chu cho **${core.tagOf(user)}**. ${caseLabel(c)}`)], flags: EPH });
  }),
};

const caseView = (c) => {
  const e = core.caseEmbed(c);
  if (c.notes?.length) {
    e.addFields({
      name: `Ghi chu (${c.notes.length})`,
      value: core.truncate(c.notes.map((n) => `• ${n.text} — ${n.modTag}, <t:${Math.floor(n.at / 1000)}:R>`).join('\n'), 1000),
    });
  }
  return e;
};

const caseCmd = {
  data: new SlashCommandBuilder()
    .setName('case')
    .setDescription('Xem / sua mot case')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addSubcommand((s) =>
      s.setName('view').setDescription('Xem chi tiet case').addIntegerOption((o) => o.setName('id').setDescription('So case').setRequired(true).setMinValue(1))
    )
    .addSubcommand((s) =>
      s
        .setName('reason')
        .setDescription('Sua ly do cua case')
        .addIntegerOption((o) => o.setName('id').setDescription('So case').setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('text').setDescription('Ly do moi').setRequired(true).setMaxLength(1000))
    )
    .addSubcommand((s) =>
      s
        .setName('note')
        .setDescription('Them ghi chu vao case')
        .addIntegerOption((o) => o.setName('id').setDescription('So case').setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('text').setDescription('Ghi chu').setRequired(true).setMaxLength(500))
    ),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const id = i.options.getInteger('id', true);
    const sub = i.options.getSubcommand();
    const mod = core.who(i.user);
    let c = null;
    if (sub === 'view') c = core.findCase(i.guild.id, id);
    else if (sub === 'reason') c = core.setCaseReason(i.guild.id, id, i.options.getString('text', true));
    else c = core.addCaseNote(i.guild.id, id, mod, i.options.getString('text', true));
    if (!c) return fail(i, `Khong tim thay case #${id}.`);
    return i.reply({ embeds: [caseView(c)], ...(sub !== 'view' ? { flags: EPH } : {}) });
  }),
};

const cases = {
  data: new SlashCommandBuilder()
    .setName('cases')
    .setDescription('Liet ke cac case (moi nhat truoc)')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Loc theo nguoi dung'))
    .addIntegerOption((o) => o.setName('page').setDescription('Trang').setMinValue(1)),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const user = i.options.getUser('user');
    const { items, total, page, pages } = core.listCases(i.guild.id, { userId: user?.id, page: i.options.getInteger('page') ?? 1 });
    if (!total) return i.reply({ embeds: [embed(0x5865f2, 'Chua co case nao.')], flags: EPH });
    const lines = items.map(
      (c) => `\`#${c.id}\` **${c.type.toUpperCase()}** <@${c.userId}> — ${core.truncate(c.reason || 'Khong co ly do', 60)} — <t:${Math.floor(c.createdAt / 1000)}:R>`
    );
    const e = embed(0x5865f2, lines.join('\n')).setTitle(user ? `Cases cua ${core.tagOf(user)}` : 'Cases gan day').setFooter({ text: `Trang ${page}/${pages} • ${total} case` });
    return i.reply({ embeds: [e], flags: EPH });
  }),
};

module.exports = { warn, note, caseCmd, cases };
