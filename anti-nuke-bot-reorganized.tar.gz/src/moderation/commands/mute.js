'use strict';
// Lenh: /mute /unmute - mute bang role rieng (khong gioi han 28 ngay nhu /timeout), logic that su
// nam trong ../../core (mute.js).
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const core = require('../core');
const { allowed, resolveMember, parseOptionalDuration, reasonOf, userOpt, reasonOpt, wrap, caseLabel, okEmbed, fail } = require('./shared');

const mute = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute bang role Muted (khong gioi han 28 ngay)')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi can mute'))
    .addStringOption((o) => o.setName('duration').setDescription('Vd 2h, 3d (bo trong = vinh vien)'))
    .addStringOption(reasonOpt),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const dur = parseOptionalDuration(i);
    if (dur.error) return fail(i, dur.error);
    const r = resolveMember(i, { required: true });
    if (r.error) return fail(i, r.error);
    // Lan dau tao role Muted phai chinh overwrite tren moi kenh -> co the > 3s.
    if (!core.mutedRoleExists(i.guild)) await i.deferReply();
    const c = await core.muteMember(i.guild, core.who(i.user), r.member, reasonOf(i), dur.ms);
    const e = okEmbed(`Da mute **${core.tagOf(r.member.user)}**${dur.ms ? ` trong ${core.formatDuration(dur.ms)}` : ''}. ${caseLabel(c)}`);
    return i.deferred ? i.editReply({ embeds: [e] }) : i.reply({ embeds: [e] });
  }),
};

const unmute = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Go mute')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi can unmute'))
    .addStringOption(reasonOpt),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const member = i.options.getMember('user');
    const store = core.load(i.guild.id);
    if (!member || !(member.roles.cache.has(store.config.mutedRoleId) || store.data.mutes[member.id])) {
      return fail(i, 'Nguoi nay hien khong bi mute.');
    }
    const c = await core.unmuteMember(i.guild, core.who(i.user), member, reasonOf(i));
    return i.reply({ embeds: [okEmbed(`Da unmute **${core.tagOf(member.user)}**. ${caseLabel(c)}`)] });
  }),
};

module.exports = { mute, unmute };
