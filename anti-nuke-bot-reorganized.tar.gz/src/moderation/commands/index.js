'use strict';
// Lap rap TOAN BO lenh moderation tu cac file rieng trong thu muc nay (1 tinh nang = 1 file) va
// export LAI DUNG BO MAT PHANG nhu commands.js truoc day: mang `commands` (dung boi moderation/
// index.js de dang ky + dinh tuyen interaction, va boi ../textCommands.js de tai su dung schema cho
// prefix/tag-command) + 3 ham tien ich. Node tu phan giai require('./commands') sang file nay vi
// commands.js gio la thu muc, nen KHONG noi nao khac trong repo can sua duong dan require.
const { ban, unban, kick, timeout, checkHierarchy } = require('./punishment');
const { mute, unmute } = require('./mute');
const { warn, note, caseCmd, cases } = require('./cases');
const { slowmode } = require('./slowmode');
const { automod, automodAutocomplete } = require('./automod');
const { prefix } = require('./prefix');
const { parseOptionalDuration } = require('./shared');

const commands = [ban, unban, kick, timeout, mute, unmute, warn, note, caseCmd, cases, slowmode, automod, prefix];

module.exports = { commands, checkHierarchy, parseOptionalDuration, automodAutocomplete };
