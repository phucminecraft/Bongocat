'use strict';
// Lenh: /ban /unban /kick /timeout - xu phat truc tiep, moi lenh goi ham tuong ung trong ../../core
// (punishment.js) roi bao ket qua bang embed.
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const core = require('../core');
const { allowed, checkHierarchy, resolveMember, parseOptionalDuration, reasonOf, userOpt, reasonOpt, wrap, caseLabel, okEmbed, fail } = require('./shared');

const ban = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Cam mot thanh vien (co the tam thoi)')
    .setDefaultMemberPermissions(P.BanMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi can ban'))
    .addStringOption((o) => o.setName('duration').setDescription('Ban tam thoi, vd 7d (bo trong = vinh vien)'))
    .addStringOption(reasonOpt)
    .addIntegerOption((o) => o.setName('delete_days').setDescription('Xoa tin nhan trong N ngay gan day (0-7)').setMinValue(0).setMaxValue(7)),
  execute: wrap(async (i) => {
    if (!allowed(i, P.BanMembers, 'Ban Members')) return;
    const user = i.options.getUser('user', true);
    const dur = parseOptionalDuration(i);
    if (dur.error) return fail(i, dur.error);
    const r = resolveMember(i, { required: false });
    if (r.error) return fail(i, r.error);
    const c = await core.banUser(i.guild, core.who(i.user), core.who(user), reasonOf(i), {
      durationMs: dur.ms,
      deleteSeconds: (i.options.getInteger('delete_days') ?? 0) * 86_400,
    });
    return i.reply({ embeds: [okEmbed(`Da ban **${core.tagOf(user)}**${dur.ms ? ` trong ${core.formatDuration(dur.ms)}` : ''}. ${caseLabel(c)}`)] });
  }),
};

const unban = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Go ban theo ID')
    .setDefaultMemberPermissions(P.BanMembers)
    .addStringOption((o) => o.setName('user_id').setDescription('ID nguoi dung').setRequired(true))
    .addStringOption(reasonOpt),
  execute: wrap(async (i) => {
    if (!allowed(i, P.BanMembers, 'Ban Members')) return;
    const id = i.options.getString('user_id', true).trim();
    if (!/^\d{5,25}$/.test(id)) return fail(i, 'ID khong hop le.');
    const ban = await i.guild.bans.fetch(id).catch(() => null);
    const c = await core.unbanUser(i.guild, core.who(i.user), { id, tag: ban ? core.tagOf(ban.user) : id }, reasonOf(i));
    return i.reply({ embeds: [okEmbed(`Da go ban \`${id}\`. ${caseLabel(c)}`)] });
  }),
};

const kick = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Duoi mot thanh vien')
    .setDefaultMemberPermissions(P.KickMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi can kick'))
    .addStringOption(reasonOpt),
  execute: wrap(async (i) => {
    if (!allowed(i, P.KickMembers, 'Kick Members')) return;
    const r = resolveMember(i, { required: true });
    if (r.error) return fail(i, r.error);
    const c = await core.kickMember(i.guild, core.who(i.user), r.member, reasonOf(i));
    return i.reply({ embeds: [okEmbed(`Da kick **${core.tagOf(r.member.user)}**. ${caseLabel(c)}`)] });
  }),
};

const timeout = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Cam noi bang timeout cua Discord (toi da 28 ngay)')
    .setDefaultMemberPermissions(P.ModerateMembers)
    .addUserOption((o) => userOpt(o, 'Nguoi can timeout'))
    .addStringOption((o) => o.setName('duration').setDescription('Vd 30m, 2h, 1d').setRequired(true))
    .addStringOption(reasonOpt),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ModerateMembers, 'Moderate Members')) return;
    const dur = parseOptionalDuration(i);
    if (dur.error || !dur.ms) return fail(i, dur.error || 'Can nhap thoi han.');
    if (dur.ms > 28 * 86_400_000) return fail(i, 'Timeout toi da 28 ngay. Dung `/mute` cho thoi han dai hon.');
    const r = resolveMember(i, { required: true });
    if (r.error) return fail(i, r.error);
    const c = await core.timeoutMember(i.guild, core.who(i.user), r.member, dur.ms, reasonOf(i));
    return i.reply({ embeds: [okEmbed(`Da timeout **${core.tagOf(r.member.user)}** ${core.formatDuration(dur.ms)}. ${caseLabel(c)}`)] });
  }),
};

// checkHierarchy khong dung truc tiep o day nhung duoc re-export qua commands/index.js (giu nguyen
// API cu cua commands.js) - xem ghi chu trong shared.js.
module.exports = { ban, unban, kick, timeout, checkHierarchy };
