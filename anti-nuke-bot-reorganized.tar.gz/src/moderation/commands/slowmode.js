'use strict';
// Lenh: /slowmode - giao dien cho ../../core (slowmode.js): <= 6h dung goc Discord, dai hon do bot
// tu cuong che (xem ghi chu chi tiet trong core/slowmode.js).
const { SlashCommandBuilder, PermissionFlagsBits: P, ChannelType } = require('discord.js');
const core = require('../core');
const { allowed, wrap, embed, okEmbed, fail, EPH } = require('./shared');

const SLOW_TYPES = [ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.PublicThread, ChannelType.PrivateThread];

const slowmode = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Slowmode: <= 6h dung goc Discord, dai hon do bot tu quan ly')
    .setDefaultMemberPermissions(P.ManageChannels)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Dat slowmode (toi da 30 ngay)')
        .addStringOption((o) => o.setName('duration').setDescription('Vd 10s, 5m, 6h, 1d').setRequired(true))
        .addChannelOption((o) => o.setName('channel').setDescription('Kenh (mac dinh: kenh hien tai)').addChannelTypes(...SLOW_TYPES))
    )
    .addSubcommand((s) =>
      s
        .setName('off')
        .setDescription('Tat slowmode')
        .addChannelOption((o) => o.setName('channel').setDescription('Kenh (mac dinh: kenh hien tai)').addChannelTypes(...SLOW_TYPES))
    )
    .addSubcommand((s) => s.setName('list').setDescription('Liet ke cac kenh dang co slowmode')),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ManageChannels, 'Manage Channels')) return;
    const sub = i.options.getSubcommand();
    if (sub === 'list') {
      const store = core.load(i.guild.id);
      const lines = [];
      for (const ch of i.guild.channels.cache.values()) {
        const bot = store.config.slowmodes[ch.id];
        if (bot) lines.push(`<#${ch.id}> — **${core.formatDuration(bot.seconds * 1000)}** (bot quan ly)`);
        else if (ch.rateLimitPerUser > 0) lines.push(`<#${ch.id}> — ${core.formatDuration(ch.rateLimitPerUser * 1000)} (goc Discord)`);
      }
      return i.reply({ embeds: [embed(0x5865f2, lines.join('\n') || 'Khong kenh nao co slowmode.')], flags: EPH });
    }
    const channel = i.options.getChannel('channel') ?? i.channel;
    let seconds = 0;
    if (sub === 'set') {
      const ms = core.parseDuration(i.options.getString('duration', true));
      if (!ms) return fail(i, 'Thoi han khong hop le. Vi du: `10s`, `5m`, `6h`, `1d`.');
      seconds = Math.ceil(ms / 1000);
      if (seconds > core.SLOWMODE_MAX) return fail(i, 'Slowmode toi da 30 ngay.');
    }
    const res = await core.setSlowmode(channel, seconds, `Slowmode boi ${core.tagOf(i.user)}`);
    const text =
      res.mode === 'off'
        ? `Da tat slowmode o <#${channel.id}>.`
        : res.mode === 'native'
          ? `Slowmode <#${channel.id}>: **${core.formatDuration(res.seconds * 1000)}** (goc Discord).`
          : `Slowmode <#${channel.id}>: **${core.formatDuration(res.seconds * 1000)}** — vuot 6h nen bot tu cuong che (Discord chi ho tro toi da 6h).`;
    return i.reply({ embeds: [okEmbed(text)] });
  }),
};

module.exports = { slowmode };
