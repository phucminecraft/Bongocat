'use strict';
// /automod voice ... - quan ly Voice Protection. Xem ../../voiceProtection.js cho phan theo doi
// thuc te cac su kien kenh thoai.
const { VOICE_KINDS, makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('voice')
      .setDescription('Voice Protection: chong spam trong kenh thoai')
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat dem nguong + xu phat').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) =>
        s.setName('log').setDescription('Bat/tat ghi log join/leave/doi kenh/camera/chia se man hinh').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true))
      )
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription('Dat nguong cho 1 loai hanh vi')
          .addStringOption((o) => o.setName('kind').setDescription('Loai').setRequired(true).addChoices(...VOICE_KINDS))
          .addIntegerOption((o) => o.setName('count').setDescription('So lan toi da').setRequired(true).setMinValue(1).setMaxValue(200))
          .addIntegerOption((o) => o.setName('seconds').setDescription('Trong bao nhieu giay').setRequired(true).setMinValue(1).setMaxValue(600))
      )
      .addSubcommand((s) => s.setName('off').setDescription('Tat theo doi 1 loai hanh vi').addStringOption((o) => o.setName('kind').setDescription('Loai').setRequired(true).addChoices(...VOICE_KINDS)))
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  const voice = cfg.voice;
  if (sub === 'toggle') {
    voice.enabled = i.options.getBoolean('enabled', true);
    return done(`Voice Protection (dem nguong + xu phat) da ${voice.enabled ? 'BAT' : 'TAT'}.`);
  }
  if (sub === 'log') {
    voice.log = i.options.getBoolean('enabled', true);
    return done(`Ghi log su kien kenh thoai da ${voice.log ? 'BAT' : 'TAT'}.`);
  }
  const kind = i.options.getString('kind', true);
  if (sub === 'off') {
    delete voice.kinds[kind];
    return done(`Da tat theo doi **${kind}**.`);
  }
  const count = i.options.getInteger('count', true);
  const seconds = i.options.getInteger('seconds', true);
  voice.kinds[kind] = { count, seconds };
  return done(`Voice **${kind}**: ${count} lan trong ${seconds}s.`);
}

module.exports = { addToBuilder, handle };
