'use strict';
// /automod threads ... - quan ly Thread Spam. Xem ../../floodProtection.js cho phan theo doi thuc
// te viec tao thread.
const { makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('threads')
      .setDescription('Thread Spam: chong tao thread lien tuc')
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription('Dat nguong')
          .addIntegerOption((o) => o.setName('count').setDescription('So thread toi da').setRequired(true).setMinValue(1).setMaxValue(200))
          .addIntegerOption((o) => o.setName('seconds').setDescription('Trong bao nhieu giay').setRequired(true).setMinValue(1).setMaxValue(600))
      )
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  if (sub === 'toggle') {
    cfg.threads.enabled = i.options.getBoolean('enabled', true);
    return done(`Thread Spam da ${cfg.threads.enabled ? 'BAT' : 'TAT'}.`);
  }
  const count = i.options.getInteger('count', true);
  const seconds = i.options.getInteger('seconds', true);
  cfg.threads.limit = { count, seconds };
  return done(`Thread Spam: ${count} thread trong ${seconds}s.`);
}

module.exports = { addToBuilder, handle };
