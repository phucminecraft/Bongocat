'use strict';
// /automod reactions ... - quan ly Reaction Spam. Xem ../../floodProtection.js cho phan theo doi
// thuc te viec tha reaction.
const { makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('reactions')
      .setDescription('Reaction Spam: chong tha reaction nhanh hon toc do bam that')
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription('Dat nguong')
          .addIntegerOption((o) => o.setName('count').setDescription('So reaction toi da').setRequired(true).setMinValue(1).setMaxValue(200))
          .addIntegerOption((o) => o.setName('seconds').setDescription('Trong bao nhieu giay').setRequired(true).setMinValue(1).setMaxValue(600))
      )
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  if (sub === 'toggle') {
    cfg.reactions.enabled = i.options.getBoolean('enabled', true);
    return done(`Reaction Spam da ${cfg.reactions.enabled ? 'BAT' : 'TAT'}.`);
  }
  const count = i.options.getInteger('count', true);
  const seconds = i.options.getInteger('seconds', true);
  cfg.reactions.limit = { count, seconds };
  return done(`Reaction Spam: ${count} reaction trong ${seconds}s.`);
}

module.exports = { addToBuilder, handle };
