'use strict';
// /automod exempt toggle - bam lan nua de bo mien tru. Ap dung cho moi rule content (words/invites/
// characters/spam/keywordFilters); Voice Protection dung rieng ManageMembers/... qua hasBypassPerm.
const { fail } = require('../shared');
const { toggleList, makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('exempt')
      .setDescription('Mien tru role/kenh (bam lan nua de bo mien tru)')
      .addSubcommand((s) => s.setName('toggle').setDescription('Doi trang thai mien tru').addRoleOption((o) => o.setName('role').setDescription('Role')).addChannelOption((o) => o.setName('channel').setDescription('Kenh')))
  );
}

function handle(i, cfg) {
  const done = makeDone(i);
  const role = i.options.getRole('role');
  const ch = i.options.getChannel('channel');
  if (!role && !ch) return fail(i, 'Chon it nhat 1 role hoac kenh.');
  const msgs = [];
  if (role) msgs.push(toggleList(cfg.exemptRoles, role.id) ? `Mien tru role <@&${role.id}>` : `Bo mien tru role <@&${role.id}>`);
  if (ch) msgs.push(toggleList(cfg.exemptChannels, ch.id) ? `Mien tru kenh <#${ch.id}>` : `Bo mien tru kenh <#${ch.id}>`);
  return done(msgs.join('\n'));
}

module.exports = { addToBuilder, handle };
