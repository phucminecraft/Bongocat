'use strict';
// /automod keyword ... - 26 rule Keyword & Phrase Filters moi (item 2-28: Profanity, Slurs, Scam
// Keywords, Regex Filters, Keyword Whitelist, Required Phrases, v.v.). Dinh nghia + logic ap dung
// nam trong ../../keywordFilters.js, file nay chi la lop giao dien lenh.
const core = require('../../core');
const keywordFilters = require('../../keywordFilters');
const { fail, embed, okEmbed, errEmbed, EPH } = require('../shared');
const { makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('keyword')
      .setDescription('26 rule Keyword & Phrase Filters moi: Profanity, Slurs, Scam Keywords, Regex Filters, Keyword Whitelist...')
      .addSubcommand((s) =>
        s
          .setName('add')
          .setDescription('Them 1 muc (tu/cum/domain/pattern/cum bat buoc) vao 1 rule')
          .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
          .addStringOption((o) => o.setName('value').setDescription('Noi dung can them').setRequired(true).setMaxLength(200))
          .addStringOption((o) =>
            o
              .setName('mode')
              .setDescription('Chi Regex Filters: native (Discord, khuyen nghi) hay js (chay tai bot)')
              .addChoices({ name: 'native (Discord AutoMod - khuyen nghi)', value: 'native' }, { name: 'js (chay tai bot)', value: 'js' })
          )
      )
      .addSubcommand((s) =>
        s
          .setName('remove')
          .setDescription('Xoa 1 muc khoi 1 rule')
          .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
          .addStringOption((o) => o.setName('value').setDescription('Noi dung can xoa').setRequired(true).setMaxLength(200))
      )
      .addSubcommand((s) =>
        s.setName('list').setDescription('Xem danh sach hien tai cua 1 rule (chi ban thay)').addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
      )
      .addSubcommand((s) =>
        s
          .setName('toggle')
          .setDescription('Bat/tat 1 rule (Profanity/Slurs/Sexual Content/Regex Filters che do native se tao/xoa AutoMod rule that cua Discord)')
          .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
          .addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true))
      )
      .addSubcommand((s) =>
        s
          .setName('mode')
          .setDescription('Khop nguyen tu hay 1 phan (chi rule dang danh sach tu)')
          .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
          .addBooleanOption((o) => o.setName('whole_word').setDescription('true = khop nguyen tu').setRequired(true))
      )
      .addSubcommand((s) =>
        s
          .setName('channel')
          .setDescription('Them/bo kenh ap dung Required Phrases')
          .addStringOption((o) => o.setName('rule').setDescription('Chi ap dung cho rule requiredPhrases').setRequired(true).setAutocomplete(true))
          .addStringOption((o) => o.setName('action').setDescription('Them hay bo').setRequired(true).addChoices({ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }))
          .addChannelOption((o) => o.setName('channel').setDescription('Kenh').setRequired(true))
      )
  );
}

async function handle(i, cfg, sub) {
  const done = makeDone(i);
  const ruleId = i.options.getString('rule', true);
  const def = keywordFilters.KEYWORD_RULE_DEFS[ruleId];
  if (!def) return fail(i, `Rule khong hop le: \`${ruleId}\`. Go 1 phan ten de xem goi y (vd "slur", "scam", "regex"...).`);
  const rc = cfg[ruleId];
  const label = def.label;

  if (sub === 'toggle') {
    const enabled = i.options.getBoolean('enabled', true);
    // Profanity/Slurs/Sexual Content va Regex Filters (che do native) can tao/xoa 1 AutoMod rule
    // THAT SU cua Discord (goi API, co the loi vi thieu quyen) -> defer + bao ket qua that.
    if (def.kind === 'preset' || ruleId === 'regexFilters') {
      await i.deferReply({ flags: EPH });
      rc.enabled = enabled;
      const res = def.kind === 'preset' ? await keywordFilters.syncPresetRule(i.guild, cfg, ruleId) : await keywordFilters.syncRegexNativeRule(i.guild, cfg);
      if (!res.ok) rc.enabled = !enabled; // dong bo that bai -> khong luu la da doi trang thai
      core.saveSoon(i.guild.id);
      return i.editReply({ embeds: [res.ok ? okEmbed(`**${label}**: da ${enabled ? 'BAT' : 'TAT'}.`) : errEmbed(res.reason)] });
    }
    rc.enabled = enabled;
    return done(`**${label}**: da ${enabled ? 'BAT' : 'TAT'}.`);
  }

  if (sub === 'mode') {
    if (def.kind !== 'list' && def.kind !== 'whitelist') return fail(i, `Rule **${ruleId}** khong co tuy chon "khop nguyen tu".`);
    rc.wholeWord = i.options.getBoolean('whole_word', true);
    return done(`**${label}**: ${rc.wholeWord ? 'khop nguyen tu' : 'khop 1 phan'}.`);
  }

  if (sub === 'list') {
    const items =
      def.kind === 'regex' ? rc.patterns.map((p) => `${p.pattern} [${p.mode}]`) : ruleId === 'urls' ? rc.allowDomains : rc.list;
    if (!items) return fail(i, `Rule **${ruleId}** khong co danh sach (chi dung "toggle" de bat/tat).`);
    return i.reply({ embeds: [embed(0x5865f2, items.length ? items.map((w) => `\`${core.truncate(w, 60)}\``).join(', ') : 'Danh sach trong.')], flags: EPH });
  }

  if (sub === 'channel') {
    if (ruleId !== 'requiredPhrases') return fail(i, 'Subcommand "channel" chi ap dung cho rule **requiredPhrases**.');
    const ch = i.options.getChannel('channel', true);
    const action = i.options.getString('action', true);
    const has = rc.channelIds.includes(ch.id);
    if (action === 'add') {
      if (has) return fail(i, 'Kenh nay da co trong danh sach.');
      if (rc.channelIds.length >= 50) return fail(i, 'Toi da 50 kenh.');
      rc.channelIds.push(ch.id);
      return done(`Da them <#${ch.id}> vao Required Phrases (${rc.channelIds.length} kenh).`);
    }
    if (!has) return fail(i, 'Kenh nay khong co trong danh sach.');
    rc.channelIds.splice(rc.channelIds.indexOf(ch.id), 1);
    return done(`Da bo <#${ch.id}> khoi Required Phrases.`);
  }

  if (!['add', 'remove'].includes(sub)) return fail(i, 'Lenh khong hop le.');
  if (def.kind === 'preset') return fail(i, `Rule **${ruleId}** dung danh sach do Discord duy tri, khong co danh sach tuy chinh. Dung "toggle" de bat/tat.`);
  const value = i.options.getString('value', true).trim();
  if (!value) return fail(i, 'Gia tri khong hop le.');

  if (def.kind === 'regex') {
    if (sub === 'remove') {
      const idx = rc.patterns.findIndex((p) => p.pattern === value);
      if (idx === -1) return fail(i, 'Khong tim thay pattern nay.');
      rc.patterns.splice(idx, 1);
      if (rc.enabled) {
        await i.deferReply({ flags: EPH });
        await keywordFilters.syncRegexNativeRule(i.guild, cfg);
        core.saveSoon(i.guild.id);
        return i.editReply({ embeds: [okEmbed(`Da xoa pattern. Con ${rc.patterns.length}/10.`)] });
      }
      return done(`Da xoa pattern. Con ${rc.patterns.length}/10.`);
    }
    const mode = i.options.getString('mode') ?? 'native';
    if (!['native', 'js'].includes(mode)) return fail(i, '`mode` phai la "native" hoac "js".');
    if (rc.patterns.length >= 10) return fail(i, 'Toi da 10 pattern (gioi han cua Discord).');
    if (rc.patterns.some((p) => p.pattern === value)) return fail(i, 'Pattern nay da co.');
    const lintErr = mode === 'native' ? keywordFilters.lintNativePattern(value) : keywordFilters.lintJsPattern(value);
    if (lintErr) return fail(i, lintErr);
    rc.patterns.push({ pattern: value, mode });
    if (rc.enabled && mode === 'native') {
      await i.deferReply({ flags: EPH });
      const res = await keywordFilters.syncRegexNativeRule(i.guild, cfg);
      if (!res.ok) rc.patterns.pop();
      core.saveSoon(i.guild.id);
      return i.editReply({ embeds: [res.ok ? okEmbed(`Da them pattern (${mode}). ${rc.patterns.length}/10.`) : errEmbed(res.reason)] });
    }
    return done(`Da them pattern (${mode}). ${rc.patterns.length}/10.${mode === 'js' ? ' (chay tai bot - nho "toggle" rule nay neu chua bat)' : ''}`);
  }

  const arr = ruleId === 'urls' ? rc.allowDomains : rc.list;
  if (!arr) return fail(i, `Rule **${ruleId}** khong co danh sach (chi dung "toggle" de bat/tat).`);
  const norm = ['urls', 'domainBlacklist'].includes(ruleId) ? value.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0] : value;
  if (sub === 'remove') {
    const idx = arr.indexOf(norm);
    if (idx === -1) return fail(i, 'Khong tim thay muc nay trong danh sach.');
    arr.splice(idx, 1);
    return done(`Da xoa khoi **${label}** (con ${arr.length}).`);
  }
  if (arr.length >= 200) return fail(i, 'Toi da 200 muc.');
  if (arr.includes(norm)) return fail(i, 'Muc nay da co.');
  if (def.kind === 'list' && def.wildcard && (norm.match(/\*/g) || []).length > 2) return fail(i, 'Toi da 2 dau `*` moi muc.');
  arr.push(norm);
  return done(`Da them vao **${label}** (${arr.length}/200).`);
}

module.exports = { addToBuilder, handle };
