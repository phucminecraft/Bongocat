'use strict';
// rule option cua punish/delete/keyword-* deu autocomplete (qua 25 lua chon, giong /antinuke config module).
// Loc theo group/sub dang go de goi y dung tap rule lien quan (nhom "keyword" chi goi y 26 rule moi;
// punish/delete goi y tu tap ho tro punish/delete tuong ung; con lai goi y gop ca 2 cho an toan).
const core = require('../../core');
const keywordFilters = require('../../keywordFilters');
const { PUNISH_RULE_IDS, DELETE_RULE_IDS, ruleLabel } = require('./shared');

async function automodAutocomplete(interaction) {
  const q = String(interaction.options.getFocused() || '').toLowerCase();
  const group = interaction.options.getSubcommandGroup(false);
  const sub = interaction.options.getSubcommand(false);
  let ids;
  if (group === 'keyword') ids = keywordFilters.RULE_IDS;
  else if (!group && sub === 'punish') ids = PUNISH_RULE_IDS;
  else if (!group && sub === 'delete') ids = DELETE_RULE_IDS;
  else ids = [...new Set([...PUNISH_RULE_IDS, ...DELETE_RULE_IDS, ...keywordFilters.RULE_IDS])];
  const choices = ids
    .filter((id) => !q || id.toLowerCase().includes(q) || ruleLabel(id).toLowerCase().includes(q))
    .slice(0, 25)
    .map((id) => ({ name: core.truncate(ruleLabel(id), 100), value: id }));
  return interaction.respond(choices);
}

module.exports = { automodAutocomplete };
