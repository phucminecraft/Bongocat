'use strict';
// Dung chung giua cac file lenh con cua /automod (base.js, words.js, spam.js, invites.js, voice.js,
// characters.js, threads.js, reactions.js, keyword.js, exempt.js, autocomplete.js).
const { EmbedBuilder } = require('discord.js');
const core = require('../../core');
const { okEmbed, EPH } = require('../shared');
const keywordFilters = require('../../keywordFilters'); // 26 rule Keyword & Phrase Filters moi (item 2-28)

// Moi lenh con /automod ket thuc bang: luu cau hinh + reply 1 embed xanh (thuong la ephemeral).
// makeDone(i) tra ve ham "done" rieng cho tung interaction, dung chung boi tat ca file group handler.
const makeDone = (i) => (text, ephemeral = true) => {
  core.saveSoon(i.guild.id);
  return i.reply({ embeds: [okEmbed(text)], ...(ephemeral ? { flags: EPH } : {}) });
};

// rule cho /automod punish + /automod delete: 7 rule GOC (words..voice) + toan bo rule moi trong
// keywordFilters.js TRU 4 rule khong co "tin nhan phia bot" de xoa/tu phat (profanity/slurs/
// sexualContent la AutoMod rule GOC cua Discord - tin bi chan truoc khi toi bot; whitelist la rule
// mien tru, khong phai rule chan). Vuot qua 25 lua chon (25 la gioi han cua Discord cho addChoices)
// tu khi co them 26 rule moi -> dung autocomplete (xem autocomplete.js) thay vi addChoices nhu
// truoc, giong cach /antinuke config lam voi > 25 module.
const OLD_RULE_LABELS = {
  words: 'words (loc tu - Bad Words)', invites: 'invites (link moi server khac)', characters: 'characters (spam ky tu lap lai)',
  spam: 'spam', threads: 'threads (spam tao thread)', reactions: 'reactions (spam reaction)', voice: 'voice (Voice Protection)',
};
const OLD_RULE_IDS = Object.keys(OLD_RULE_LABELS);
const KEYWORD_PUNISH_DELETE_IDS = keywordFilters.RULE_IDS.filter((id) => !['profanity', 'slurs', 'sexualContent', 'whitelist'].includes(id));
const PUNISH_RULE_IDS = [...OLD_RULE_IDS, ...KEYWORD_PUNISH_DELETE_IDS]; // voice CO trong punish (khong co delete)
const DELETE_RULE_IDS = [...OLD_RULE_IDS.filter((id) => id !== 'voice'), ...KEYWORD_PUNISH_DELETE_IDS];
const ruleLabel = (id) => OLD_RULE_LABELS[id] ?? keywordFilters.KEYWORD_RULE_DEFS[id]?.label ?? id;
const SPAM_KINDS = [
  ['messages', 'messages (tin nhan lien tuc - rate limit them, ngoai built-in)'],
  ['duplicates', 'duplicates (tin nhan trung lap)'],
  ['rapidMessages', 'rapidMessages (spam qua nhanh, kieu bot/script)'],
  ['emojis', 'emojis (spam emoji)'],
  ['stickers', 'stickers (spam sticker)'],
  ['gifs', 'gifs (spam link/anh GIF: Tenor, Giphy...)'],
  ['attachments', 'attachments (spam file dinh kem)'],
  ['images', 'images (spam anh)'],
  ['videos', 'videos (spam video)'],
  ['links', 'links (spam link thuong)'],
  ['inviteLinks', 'inviteLinks (spam link moi server, bat ke server nao)'],
  ['mentions', 'mentions (spam mention nguoi/role/everyone gop lai)'],
  ['roleMentions', 'roleMentions (spam mention role)'],
  ['everyoneMentions', 'everyoneMentions (spam @everyone)'],
  ['hereMentions', 'hereMentions (spam @here)'],
  ['embeds', 'embeds (spam tin nhan co embed)'],
  ['polls', 'polls (spam poll)'],
].map(([value, name]) => ({ name, value }));
const VOICE_KINDS = [
  { name: 'joinLeave (vao/ra kenh thoai lien tuc)', value: 'joinLeave' },
  { name: 'channelSwitch (nhay qua lai nhieu kenh - VC hopping)', value: 'channelSwitch' },
  { name: 'camera (bat/tat camera lien tuc)', value: 'camera' },
  { name: 'screenshare (bat/tat chia se man hinh lien tuc)', value: 'screenshare' },
  { name: 'mute (bat/tat mic lien tuc)', value: 'mute' },
  { name: 'deafen (bat/tat che do deaf lien tuc)', value: 'deafen' },
  { name: 'soundboard (spam soundboard)', value: 'soundboard' },
];
// 'disconnect' = chi ngat khoi kenh thoai hien tai (khong timeout ca chat) - hinh phat rieng cho Voice Protection,
// nhung de o day cho moi rule deu chon duoc (vo hai voi rule tin nhan: chi khong lam gi neu khong dang trong voice).
const PUNISH_CHOICES = ['none', 'warn', 'timeout', 'mute', 'kick', 'ban', 'disconnect'].map((k) => ({ name: k, value: k }));

const toggleList = (list, id) => {
  const idx = list.indexOf(id);
  if (idx === -1) list.push(id);
  else list.splice(idx, 1);
  return idx === -1;
};

function automodStatus(cfg, store) {
  const p = (r) => (r.punish.type === 'none' ? 'chi xoa' : `${r.punish.type}${['timeout', 'mute'].includes(r.punish.type) ? ` ${r.punish.minutes}p` : ''}`) + (r.delete === false ? ' (khong xoa)' : '');
  const limits = Object.entries(cfg.spam.limits).filter(([, v]) => v).map(([k, v]) => `${k}: ${v.count}/${v.seconds}s`).join('\n') || 'khong co';
  const voiceKinds = Object.entries(cfg.voice.kinds).filter(([, v]) => v).map(([k, v]) => `${k}: ${v.count}/${v.seconds}s`).join('\n') || 'khong co';
  const voiceP = cfg.voice.punish.type === 'none' ? 'khong phat (chi ghi log)' : `${cfg.voice.punish.type}${['timeout', 'mute'].includes(cfg.voice.punish.type) ? ` ${cfg.voice.punish.minutes}p` : ''}`;
  const reactionsP = cfg.reactions.punish.type === 'none' ? 'khong phat (chi ghi log)' : `${cfg.reactions.punish.type}${['timeout', 'mute'].includes(cfg.reactions.punish.type) ? ` ${cfg.reactions.punish.minutes}p` : ''}`;
  // 26 rule Keyword & Phrase Filters moi: gop lai thanh 3 field GON (thay vi 1 field/rule) de khong
  // vuot gioi han 25 field/embed cua Discord (9 field goc + 3 field nay = 12, con du cho). Chi tiet
  // tung rule xem qua "/automod keyword list rule:<ten>".
  const enabledOf = (ids) => {
    const on = ids.filter((id) => cfg[id]?.enabled);
    return core.truncate(on.length ? on.map((id) => `\`${id}\``).join(', ') : 'chua bat rule nao', 1000);
  };
  const KW_CONTENT = ['profanity', 'slurs', 'sexualContent', 'swearing', 'racism', 'hateSpeech', 'harassment', 'bullying', 'threats', 'nsfw', 'selfHarm', 'scam', 'phishing', 'cryptoScam', 'advertisement', 'customKeywords', 'wildcardKeywords', 'blockedPhrases'];
  const KW_STRUCT = ['urls', 'domainBlacklist', 'ipAddresses', 'emailAddresses', 'phoneNumbers'];
  return new EmbedBuilder()
    .setColor(cfg.enabled ? 0x57f287 : 0x95a5a6)
    .setTitle(`Automod: ${cfg.enabled ? 'BAT' : 'TAT'}`)
    .addFields(
      { name: 'Kenh log', value: store.config.logChannelId ? `<#${store.config.logChannelId}>` : 'chua dat', inline: true },
      { name: `Loc tu (${cfg.words.enabled ? 'bat' : 'tat'})`, value: `${cfg.words.list.length} tu, ${cfg.words.wholeWord ? 'khop nguyen tu' : 'khop 1 phan'}\nPhat: ${p(cfg.words)}`, inline: true },
      { name: `Invite (${cfg.invites.enabled ? 'bat' : 'tat'})`, value: `Cho phep ${cfg.invites.allowGuilds.length} server khac\nPhat: ${p(cfg.invites)}`, inline: true },
      { name: `Ky tu lap (${cfg.characters.enabled ? 'bat' : 'tat'})`, value: `>= ${cfg.characters.minRun} lien tiep hoac >= ${Math.round(cfg.characters.minRatio * 100)}% tin\nPhat: ${p(cfg.characters)}`, inline: true },
      { name: `Spam (${cfg.spam.enabled ? 'bat' : 'tat'}, built-in: ${cfg.spam.builtin ? 'bat' : 'tat'})`, value: `${limits}\nPhat: ${p(cfg.spam)}` },
      { name: `Thread Spam (${cfg.threads.enabled ? 'bat' : 'tat'})`, value: `${cfg.threads.limit.count} thread / ${cfg.threads.limit.seconds}s\nPhat: ${p(cfg.threads)}`, inline: true },
      { name: `Reaction Spam (${cfg.reactions.enabled ? 'bat' : 'tat'})`, value: `${cfg.reactions.limit.count} reaction / ${cfg.reactions.limit.seconds}s\nPhat: ${reactionsP}`, inline: true },
      { name: `Voice Protection (${cfg.voice.enabled ? 'bat' : 'tat'}, ghi log: ${cfg.voice.log ? 'bat' : 'tat'})`, value: `${voiceKinds}\nPhat: ${voiceP}` },
      { name: 'Keyword Filters - noi dung (item 2-16, 23-26)', value: `Da bat: ${enabledOf(KW_CONTENT)}\nChi tiet: /automod keyword list rule:<ten>`, inline: false },
      { name: 'Keyword Filters - lien ket/dinh danh (item 18-22)', value: `Da bat: ${enabledOf(KW_STRUCT)}${cfg.regexFilters.enabled ? `\nRegex Filters: bat (${cfg.regexFilters.patterns.length}/10 pattern)` : '\nRegex Filters: tat'}`, inline: true },
      { name: 'Required Phrases & Whitelist (item 27-28)', value: `Required Phrases: ${cfg.requiredPhrases.enabled ? `bat, ${cfg.requiredPhrases.channelIds.length} kenh, ${cfg.requiredPhrases.list.length} cum` : 'tat'}\nWhitelist: ${cfg.whitelist.enabled ? `bat, ${cfg.whitelist.list.length} muc` : 'tat'}`, inline: true },
      { name: 'Mien tru', value: `Role: ${cfg.exemptRoles.map((r) => `<@&${r}>`).join(' ') || 'khong'}\nKenh: ${cfg.exemptChannels.map((c) => `<#${c}>`).join(' ') || 'khong'}\n(Admin / Manage Guild / Manage Messages / Manage Channels luon duoc mien tru)` }
    );
}

module.exports = { OLD_RULE_LABELS, OLD_RULE_IDS, KEYWORD_PUNISH_DELETE_IDS, PUNISH_RULE_IDS, DELETE_RULE_IDS, ruleLabel, SPAM_KINDS, VOICE_KINDS, PUNISH_CHOICES, toggleList, automodStatus, makeDone };
