'use strict';
// /automod invites ... - quan ly rule "invites". Xem ../../automod/inviteFilter.js cho phan kiem
// tra thuc te tren tin nhan.
const { fail } = require('../shared');
const { toggleList, makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('invites')
      .setDescription('Chan link moi server khac')
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) => s.setName('allow').setDescription('Cho phep / thu hoi cho phep invite toi 1 server').addStringOption((o) => o.setName('guild_id').setDescription('ID server').setRequired(true)))
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  if (sub === 'toggle') {
    cfg.invites.enabled = i.options.getBoolean('enabled', true);
    return done(`Chan invite da ${cfg.invites.enabled ? 'BAT' : 'TAT'}.`);
  }
  const id = i.options.getString('guild_id', true).trim();
  if (!/^\d{5,25}$/.test(id)) return fail(i, 'ID server khong hop le.');
  if (cfg.invites.allowGuilds.length >= 50 && !cfg.invites.allowGuilds.includes(id)) return fail(i, 'Toi da 50 server.');
  return done(toggleList(cfg.invites.allowGuilds, id) ? `Da cho phep invite toi \`${id}\`.` : `Da thu hoi cho phep \`${id}\`.`);
}

module.exports = { addToBuilder, handle };
