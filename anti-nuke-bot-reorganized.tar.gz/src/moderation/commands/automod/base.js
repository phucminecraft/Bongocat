'use strict';
// /automod status | toggle | logchannel | punish | delete - khong thuoc group nao, gan thang vao
// command goc. punish/delete dung chung cho MOI rule (autocomplete xem autocomplete.js).
const { ChannelType } = require('discord.js');
const core = require('../../core');
const { fail, EPH } = require('../shared');
const { PUNISH_CHOICES, PUNISH_RULE_IDS, DELETE_RULE_IDS, automodStatus, makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd
    .addSubcommand((s) => s.setName('status').setDescription('Xem cau hinh automod'))
    .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat automod').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
    .addSubcommand((s) =>
      s.setName('logchannel').setDescription('Dat kenh log (case + automod); bo trong de xoa').addChannelOption((o) => o.setName('channel').setDescription('Kenh log').addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((s) =>
      s
        .setName('punish')
        .setDescription('Dat hinh phat cho 1 rule')
        .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim - qua 25 rule nen dung autocomplete)').setRequired(true).setAutocomplete(true))
        .addStringOption((o) => o.setName('type').setDescription('Hinh phat').setRequired(true).addChoices(...PUNISH_CHOICES))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Thoi han (timeout/mute), phut').setMinValue(1).setMaxValue(40320))
    )
    .addSubcommand((s) =>
      s
        .setName('delete')
        .setDescription('Co xoa tin vi pham khong')
        .addStringOption((o) => o.setName('rule').setDescription('Rule (go de tim)').setRequired(true).setAutocomplete(true))
        .addBooleanOption((o) => o.setName('enabled').setDescription('Xoa?').setRequired(true))
    );
}

function handle(i, sub) {
  const store = core.load(i.guild.id);
  const cfg = store.config.automod;
  const done = makeDone(i);
  if (sub === 'status') return i.reply({ embeds: [automodStatus(cfg, store)], flags: EPH });
  if (sub === 'toggle') {
    cfg.enabled = i.options.getBoolean('enabled', true);
    return done(`Automod da ${cfg.enabled ? 'BAT' : 'TAT'}.`);
  }
  if (sub === 'logchannel') {
    const ch = i.options.getChannel('channel');
    store.config.logChannelId = ch?.id ?? null;
    return done(ch ? `Kenh log: <#${ch.id}>.` : 'Da xoa kenh log.');
  }
  if (sub === 'punish') {
    const rule = i.options.getString('rule', true);
    // Truoc day Discord tu gioi han gia tri hop le qua addChoices; nay dung autocomplete (vuot 25
    // lua chon) nen KHONG con dam bao do nua (ca slash lan prefix/tag-command) -> phai tu kiem tra.
    if (!PUNISH_RULE_IDS.includes(rule)) return fail(i, `Rule khong hop le hoac khong ho tro xu phat rieng: \`${rule}\`.`);
    const type = i.options.getString('type', true);
    const minutes = i.options.getInteger('minutes');
    if (['timeout', 'mute'].includes(type) && !minutes && !cfg[rule].punish.minutes) return fail(i, 'Can nhap `minutes` cho timeout/mute.');
    cfg[rule].punish = { type, minutes: minutes ?? cfg[rule].punish.minutes ?? 10 };
    return done(`Rule **${rule}**: phat = ${type}${['timeout', 'mute'].includes(type) ? ` ${cfg[rule].punish.minutes} phut` : ''}.`);
  }
  if (sub === 'delete') {
    const rule = i.options.getString('rule', true);
    if (!DELETE_RULE_IDS.includes(rule)) return fail(i, `Rule khong hop le hoac khong ho tro xoa tin: \`${rule}\`.`);
    cfg[rule].delete = i.options.getBoolean('enabled', true);
    return done(`Rule **${rule}**: ${cfg[rule].delete ? 'xoa tin vi pham' : 'khong xoa tin'}.`);
  }
  return fail(i, 'Lenh khong hop le.');
}

module.exports = { addToBuilder, handle };
