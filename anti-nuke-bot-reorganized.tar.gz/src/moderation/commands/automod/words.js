'use strict';
// /automod words ... - quan ly rule "words" (Bad Words, item 1). Xem ../../automod/wordFilter.js
// cho phan kiem tra thuc te tren tin nhan.
const { fail, embed, EPH } = require('../shared');
const { makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('words')
      .setDescription('Bo loc tu ngu')
      .addSubcommand((s) => s.setName('add').setDescription('Them tu (dung * lam wildcard, vd: fuck*)').addStringOption((o) => o.setName('word').setDescription('Tu can cam').setRequired(true).setMaxLength(50)))
      .addSubcommand((s) => s.setName('remove').setDescription('Xoa tu').addStringOption((o) => o.setName('word').setDescription('Tu can xoa').setRequired(true).setMaxLength(50)))
      .addSubcommand((s) => s.setName('list').setDescription('Xem danh sach tu (chi ban thay)'))
      .addSubcommand((s) => s.setName('mode').setDescription('Khop nguyen tu hay 1 phan').addBooleanOption((o) => o.setName('whole_word').setDescription('true = khop nguyen tu').setRequired(true)))
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat bo loc tu').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  const words = cfg.words;
  if (sub === 'list') return i.reply({ embeds: [embed(0x5865f2, words.list.length ? words.list.map((w) => `\`${w}\``).join(', ') : 'Danh sach trong.')], flags: EPH });
  if (sub === 'toggle') {
    words.enabled = i.options.getBoolean('enabled', true);
    return done(`Loc tu da ${words.enabled ? 'BAT' : 'TAT'}.`);
  }
  if (sub === 'mode') {
    words.wholeWord = i.options.getBoolean('whole_word', true);
    return done(words.wholeWord ? 'Khop nguyen tu.' : 'Khop 1 phan (de gay cam nham, vd "class" chua "ass").');
  }
  const word = i.options.getString('word', true).trim().toLowerCase();
  if (sub === 'add') {
    if (!word) return fail(i, 'Tu khong hop le.');
    if ((word.match(/\*/g) || []).length > 2) return fail(i, 'Toi da 2 dau `*` moi tu.');
    if (words.list.length >= 300) return fail(i, 'Toi da 300 tu.');
    if (words.list.includes(word)) return fail(i, 'Tu nay da co.');
    words.list.push(word);
    return done(`Da them ${words.list.length}/300 tu.`);
  }
  const idx = words.list.indexOf(word);
  if (idx === -1) return fail(i, 'Khong co tu nay trong danh sach.');
  words.list.splice(idx, 1);
  return done('Da xoa tu.');
}

module.exports = { addToBuilder, handle };
