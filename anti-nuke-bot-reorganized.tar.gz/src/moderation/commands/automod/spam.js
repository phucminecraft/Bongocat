'use strict';
// /automod spam ... - nguong dua tren cua so truot (xem ../../automod/spamDetector.js) + "builtin"
// bat/tat AutoMod rule Spam GOC cua Discord (xem ../../automod/builtinSpamRule.js).
const automodEngine = require('../../automod');
const core = require('../../core');
const { okEmbed, errEmbed, EPH } = require('../shared');
const { SPAM_KINDS, makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('spam')
      .setDescription('Chong spam')
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription('Dat nguong cho 1 loai spam')
          .addStringOption((o) => o.setName('kind').setDescription('Loai').setRequired(true).addChoices(...SPAM_KINDS))
          .addIntegerOption((o) => o.setName('count').setDescription('So luong toi da').setRequired(true).setMinValue(1).setMaxValue(200))
          .addIntegerOption((o) => o.setName('seconds').setDescription('Trong bao nhieu giay').setRequired(true).setMinValue(1).setMaxValue(600))
      )
      .addSubcommand((s) => s.setName('off').setDescription('Tat 1 loai spam').addStringOption((o) => o.setName('kind').setDescription('Loai').setRequired(true).addChoices(...SPAM_KINDS)))
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat chong spam').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) =>
        s
          .setName('builtin')
          .setDescription('Bat/tat Spam Content built-in cua Discord AutoMod (doc lap voi cac nguong o tren)')
          .addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true))
      )
  );
}

async function handle(i, cfg, sub) {
  const done = makeDone(i);
  if (sub === 'toggle') {
    cfg.spam.enabled = i.options.getBoolean('enabled', true);
    return done(`Chong spam da ${cfg.spam.enabled ? 'BAT' : 'TAT'}.`);
  }
  if (sub === 'builtin') {
    const enabled = i.options.getBoolean('enabled', true);
    await i.deferReply({ flags: EPH });
    const res = await automodEngine.setBuiltinSpamRule(i.guild, enabled);
    cfg.spam.builtin = enabled && res.ok; // chi luu la BAT neu tao/xac nhan rule thanh cong that su
    core.saveSoon(i.guild.id);
    const e = res.ok ? okEmbed(`Spam Content built-in cua Discord da ${enabled ? 'BAT' : 'TAT'}.`) : errEmbed(res.reason);
    return i.editReply({ embeds: [e] });
  }
  const kind = i.options.getString('kind', true);
  if (sub === 'off') {
    delete cfg.spam.limits[kind];
    return done(`Da tat nguong spam **${kind}**.`);
  }
  const count = i.options.getInteger('count', true);
  const seconds = i.options.getInteger('seconds', true);
  cfg.spam.limits[kind] = { count, seconds };
  return done(`Spam **${kind}**: ${count} trong ${seconds}s.`);
}

module.exports = { addToBuilder, handle };
