'use strict';
// /automod characters ... - quan ly Character Spam. Xem ../../automod/characterSpam.js cho phan
// kiem tra thuc te tren tin nhan.
const { fail } = require('../shared');
const { makeDone } = require('./shared');

function addToBuilder(cmd) {
  return cmd.addSubcommandGroup((g) =>
    g
      .setName('characters')
      .setDescription('Chong spam ky tu lap lai (vd "aaaaaaaaaa")')
      .addSubcommand((s) => s.setName('toggle').setDescription('Bat/tat').addBooleanOption((o) => o.setName('enabled').setDescription('Bat?').setRequired(true)))
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription('Dat nguong nhan dien')
          .addIntegerOption((o) => o.setName('min_length').setDescription('Do dai toi thieu (bo khoang trang) de xet').setMinValue(3).setMaxValue(4000))
          .addIntegerOption((o) => o.setName('min_run').setDescription('So ky tu GIONG NHAU lien tiep de tinh la spam').setMinValue(3).setMaxValue(4000))
          .addIntegerOption((o) => o.setName('min_ratio_percent').setDescription('% 1 ky tu chiem trong tin de tinh la spam (vd 70)').setMinValue(10).setMaxValue(100))
      )
  );
}

function handle(i, cfg, sub) {
  const done = makeDone(i);
  if (sub === 'toggle') {
    cfg.characters.enabled = i.options.getBoolean('enabled', true);
    return done(`Chong spam ky tu lap lai da ${cfg.characters.enabled ? 'BAT' : 'TAT'}.`);
  }
  const minLength = i.options.getInteger('min_length');
  const minRun = i.options.getInteger('min_run');
  const minRatioPercent = i.options.getInteger('min_ratio_percent');
  if (minLength == null && minRun == null && minRatioPercent == null) return fail(i, 'Can nhap it nhat 1 tham so.');
  if (minLength != null) cfg.characters.minLength = minLength;
  if (minRun != null) cfg.characters.minRun = minRun;
  if (minRatioPercent != null) cfg.characters.minRatio = minRatioPercent / 100;
  return done(`Ky tu lap: xet tin >= ${cfg.characters.minLength} ky tu, bao dong khi >= ${cfg.characters.minRun} ky tu giong nhau lien tiep hoac 1 ky tu chiem >= ${Math.round(cfg.characters.minRatio * 100)}% tin.`);
}

module.exports = { addToBuilder, handle };
