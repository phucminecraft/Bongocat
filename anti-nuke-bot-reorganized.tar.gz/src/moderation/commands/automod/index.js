'use strict';
// Lap rap lenh /automod tu base (status/toggle/logchannel/punish/delete) + 9 group tinh nang rieng
// (words/spam/invites/keyword/exempt/voice/characters/threads/reactions), moi group 1 file trong
// thu muc nay. execute() dinh tuyen theo (group, sub) sang dung file xu ly - cau hinh (cfg/store)
// duoc doc 1 lan roi truyen xuong, tranh moi file phai tu core.load() lai.
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const core = require('../../core');
const { allowed, wrap, fail } = require('../shared');
const base = require('./base');
const words = require('./words');
const spam = require('./spam');
const invites = require('./invites');
const keyword = require('./keyword');
const exempt = require('./exempt');
const voice = require('./voice');
const characters = require('./characters');
const threads = require('./threads');
const reactions = require('./reactions');
const { automodAutocomplete } = require('./autocomplete');

let data = new SlashCommandBuilder().setName('automod').setDescription('Cau hinh automod').setDefaultMemberPermissions(P.ManageGuild);
for (const mod of [base, words, spam, invites, keyword, exempt, voice, characters, threads, reactions]) {
  data = mod.addToBuilder(data);
}

const automod = {
  data,
  execute: wrap(async (i) => {
    if (!allowed(i, P.ManageGuild, 'Manage Server')) return;
    const cfg = core.load(i.guild.id).config.automod;
    const group = i.options.getSubcommandGroup(false);
    const sub = i.options.getSubcommand();
    switch (group) {
      case null:
        return base.handle(i, sub);
      case 'words':
        return words.handle(i, cfg, sub);
      case 'spam':
        return spam.handle(i, cfg, sub);
      case 'invites':
        return invites.handle(i, cfg, sub);
      case 'keyword':
        return keyword.handle(i, cfg, sub);
      case 'exempt':
        return exempt.handle(i, cfg);
      case 'voice':
        return voice.handle(i, cfg, sub);
      case 'characters':
        return characters.handle(i, cfg, sub);
      case 'threads':
        return threads.handle(i, cfg, sub);
      case 'reactions':
        return reactions.handle(i, cfg, sub);
      default:
        return fail(i, 'Lenh khong hop le.');
    }
  }),
};
automod.autocomplete = automodAutocomplete;

module.exports = { automod, automodAutocomplete };
