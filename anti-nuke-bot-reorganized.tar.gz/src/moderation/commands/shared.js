'use strict';
// Tien ich dung chung cho MOI lenh slash trong thu muc commands/ nay: kiem tra lai quyen, kiem tra
// thu bac role, dung chung format reply (embed mau xanh/do), va wrap() bat loi khong ro rang tu
// Discord API. Phan quyen: setDefaultMemberPermissions (Discord tu an lenh voi nguoi khong du
// quyen, khong ton round-trip) + re-check trong code (allowed) + kiem tra thu bac role
// (checkHierarchy). Lenh nao cung goi thang API roi reply, khong co buoc tra audit log hay delay nao.
const { EmbedBuilder, MessageFlags } = require('discord.js');
const core = require('../core');

const EPH = MessageFlags.Ephemeral; // "ephemeral: true" da bi Discord.js coi la deprecated
const embed = (color, text) => new EmbedBuilder().setColor(color).setDescription(text);
const okEmbed = (t) => embed(0x57f287, `✅ ${t}`);
const errEmbed = (t) => embed(0xed4245, `❌ ${t}`);
const fail = (i, t) => i.reply({ embeds: [errEmbed(t)], flags: EPH });

// Re-check quyen trong code; tra ve true neu du quyen, nguoc lai da reply loi.
function allowed(i, perm, label) {
  if (i.memberPermissions?.has(perm)) return true;
  fail(i, `Ban khong co quyen ${label}.`);
  return false;
}

function checkHierarchy(i, target) {
  const g = i.guild;
  if (target.id === g.ownerId) return 'Khong the thao tac len chu server.';
  if (target.id === i.user.id) return 'Khong the tu thao tac len chinh minh.';
  if (target.id === i.client.user.id) return 'Khong the thao tac len chinh bot.';
  if (!i.member?.roles?.highest) return 'Khong xac dinh duoc thu bac role cua ban.';
  const me = g.members.me;
  if (me && g.ownerId !== me.id && me.roles.highest.position <= target.roles.highest.position) {
    return 'Bot khong du thu bac (role muc tieu >= role cao nhat cua bot).';
  }
  if (g.ownerId !== i.member.id && i.member.roles.highest.position <= target.roles.highest.position) {
    return 'Ban khong the thao tac len nguoi co role cao hon hoac bang ban.';
  }
  return null;
}

// Lay member muc tieu (co san trong payload lenh, khong can fetch) + kiem tra thu bac.
// Tra ve { member } hoac { error }.
function resolveMember(i, { required }) {
  const member = i.options.getMember('user');
  if (!member) return required ? { error: 'Nguoi nay khong con trong server.' } : { member: null };
  const error = checkHierarchy(i, member);
  return error ? { error } : { member };
}

const parseOptionalDuration = (i, name = 'duration') => {
  const raw = i.options.getString(name);
  if (raw == null) return { ms: 0 };
  const ms = core.parseDuration(raw);
  return ms ? { ms } : { error: 'Thoi han khong hop le. Vi du: `30m`, `2h`, `1d`, `1h30m`.' };
};

const reasonOf = (i) => i.options.getString('reason') || null;
const userOpt = (o, desc = 'Nguoi dung') => o.setName('user').setDescription(desc).setRequired(true);
const reasonOpt = (o) => o.setName('reason').setDescription('Ly do');
const wrap = (fn) => async (i) => {
  try {
    return await fn(i);
  } catch (err) {
    const embeds = [errEmbed(`Khong the thuc hien: ${err.message}`)];
    return i.deferred || i.replied ? i.editReply({ embeds }) : i.reply({ embeds, flags: EPH });
  }
};

const caseLabel = (c) => `Case #${c.id}`;

module.exports = {
  EPH, embed, okEmbed, errEmbed, fail,
  allowed, checkHierarchy, resolveMember, parseOptionalDuration,
  reasonOf, userOpt, reasonOpt, wrap, caseLabel,
};
