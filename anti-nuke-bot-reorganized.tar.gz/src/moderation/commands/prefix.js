'use strict';
// Lenh: /prefix - cho lenh dang tin nhan (vd "!ban ..."); tag-bot command (@Bot ban ...) luon hoat
// dong rieng, khong bi anh huong boi gia tri nay (xem ../../../textCommands.js).
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const core = require('../core');
const { allowed, wrap, embed, okEmbed, fail, EPH } = require('./shared');

const prefix = {
  data: new SlashCommandBuilder()
    .setName('prefix')
    .setDescription('Prefix cho lenh dang tin nhan (vd "!ban ..."); tag bot (@Bot ban ...) luon hoat dong rieng')
    .setDefaultMemberPermissions(P.ManageGuild)
    .addSubcommand((s) => s.setName('show').setDescription('Xem prefix hien tai'))
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Doi prefix (toi da 5 ky tu, khong khoang trang); go "off" de tat prefix-command')
        .addStringOption((o) => o.setName('text').setDescription('Prefix moi, vd !, ?, hoac "off" de tat').setRequired(true).setMaxLength(5))
    ),
  execute: wrap(async (i) => {
    if (!allowed(i, P.ManageGuild, 'Manage Server')) return;
    const store = core.load(i.guild.id);
    if (i.options.getSubcommand() === 'show') {
      return i.reply({ embeds: [embed(0x5865f2, store.config.prefix ? `Prefix hien tai: \`${store.config.prefix}\`` : 'Prefix dang TAT (chi dung duoc slash command / tag bot).')], flags: EPH });
    }
    const text = i.options.getString('text', true).trim();
    if (text.toLowerCase() === 'off') {
      store.config.prefix = null;
      core.saveSoon(i.guild.id);
      return i.reply({ embeds: [okEmbed('Da tat prefix-command. Slash command va tag bot van hoat dong binh thuong.')], flags: EPH });
    }
    if (/\s/.test(text)) return fail(i, 'Prefix khong duoc chua khoang trang.');
    store.config.prefix = text;
    core.saveSoon(i.guild.id);
    return i.reply({ embeds: [okEmbed(`Prefix moi: \`${text}\` (vd \`${text}ban @user spam\`).`)] });
  }),
};

module.exports = { prefix };
