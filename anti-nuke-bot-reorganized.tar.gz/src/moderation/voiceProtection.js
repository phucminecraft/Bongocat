'use strict';
// Voice Protection: phan he automod cho kenh thoai, doc lap voi automod.js (loc tin nhan) nhung
// dung chung co che va tien ich cua core.js (mien tru, cases, applyPunish...).
//
// Hai lop hoat dong DOC LAP voi nhau (bat/tat rieng qua /automod voice toggle va /automod voice log):
//   1) Ghi log day du: moi lan join/leave/doi kenh/bat camera/bat chia se man hinh deu duoc ghi
//      vao kenh log (neu bat `cfg.log`) - de admin xem lai duoc "ai lam gi, luc nao" du khong co
//      mat truc tiep. Mute/deafen KHONG ghi log tung lan (da so nguoi dung bam mic that/ptt lien
//      tuc, ghi moi lan se spam kenh log vo ich) - chi xuat hien khi vuot nguong spam ben duoi.
//   2) Dem nguong + xu phat: dung cua so truot y het co che chong-spam-tin-nhan trong automod.js
//      (Map "guild:user:kind" -> danh sach timestamp trong N giay gan nhat). Vuot nguong -> ap dung
//      hinh phat cau hinh o `cfg.punish` (mac dinh timeout - vua ngat khoi kenh thoai hien tai vua
//      ngan tham gia lai trong thoi han, dung y yeu cau "ngan khong cho ho tham gia lai kenh trong
//      mot khoang thoi gian nhat dinh"); co the doi sang `disconnect` neu chi muon ngat nhe khong
//      timeout ca chat.
//
// GIOI HAN CAN BIET (soundboard): theo tai lieu gateway cua Discord, su kien VOICE_CHANNEL_EFFECT_SEND
// (dung de phat hien phat soundboard) CHI duoc gui toi client/bot dang o TRONG kenh thoai do -
// khac voi cac su kien con lai (join/leave/doi kenh/camera/mic/deaf) von nhan duoc cho toan bo
// server chi can co intent GuildVoiceStates, khong can bot dang ket noi voice. Bot nay khong tu
// dong vao kenh thoai nao, nen theo doi soundboard chi thuc su co du lieu khi bot da duoc dua vao
// kenh thoai bang mot co che khac. Cung khong the "cat" hay do do to am thanh dang phat - viec do
// can ket noi audio that su (vd @discordjs/voice + xu ly PCM/opus), ngoai pham vi mot bot kiem
// duyet chi dua tren du lieu text/gateway nhu bot nay. Code duoi day van san sang xu ly khi co du
// lieu (dem so lan phat trong cua so thoi gian) de tuong thich neu sau nay bot duoc mo rong nghe voice.
const { EmbedBuilder } = require('discord.js');
const core = require('./core');

const LABELS = {
  joinLeave: 'vao/ra kenh thoai qua nhanh, lap lai nhieu lan (join/leave spam)',
  channelSwitch: 'nhay qua lai giua nhieu kenh thoai qua nhanh (VC hopping)',
  camera: 'bat/tat camera lien tuc',
  screenshare: 'bat/tat chia se man hinh lien tuc',
  mute: 'bat/tat mic lien tuc',
  deafen: 'bat/tat che do deafen lien tuc',
  soundboard: 'lam dung soundboard, phat am thanh lap lai qua nhieu lan',
};

// ------------------------------------------------------------ cua so truot (giong co che trong automod.js)

const windows = new Map(); // "guild:user:kind" -> { windowMs, items: [ts,...] }

// Tra ve tong so lan trong cua so neu VUA vuot nguong (va reset dem), nguoc lai tra ve 0.
function bump(cfg, guildId, userId, kind) {
  const limit = cfg.kinds[kind];
  if (!limit) return 0; // loai nay da bi tat qua /automod voice off
  const now = Date.now();
  const key = `${guildId}:${userId}:${kind}`;
  const windowMs = limit.seconds * 1000;
  const win = windows.get(key) ?? { windowMs, items: [] };
  win.windowMs = windowMs;
  win.items = win.items.filter((ts) => now - ts <= windowMs);
  win.items.push(now);
  windows.set(key, win);
  if (win.items.length >= limit.count) {
    windows.delete(key); // reset dong bo, giong automod.js: lan tiep theo dem lai tu dau
    return win.items.length;
  }
  return 0;
}

const recentPunish = new Map(); // "guild:user:kind" -> ts (chong phat lap khi nhieu su kien den gan nhau)

const sweep = setInterval(() => {
  const now = Date.now();
  for (const [key, win] of windows) {
    const last = win.items[win.items.length - 1];
    if (!last || now - last > win.windowMs) windows.delete(key);
  }
  for (const [key, ts] of recentPunish) if (now - ts > 30_000) recentPunish.delete(key);
}, 60_000);
sweep.unref?.();

// ------------------------------------------------------------ ghi log (bang chung cho admin, doc lap voi xu phat)

function logEvent(guild, cfg, title, member, detail) {
  if (!cfg.log) return;
  core.sendLog(
    guild,
    new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`Voice Protection | ${title}`)
      .setDescription(`<@${member.id}> (\`${core.tagOf(member.user)}\`) ${detail}.`)
      .setTimestamp(Date.now())
  );
}

// ------------------------------------------------------------ xu phat khi vuot nguong

async function enforce(client, guild, member, kind, cfg, countDetail) {
  const reason = `Voice Protection [${kind}]: ${LABELS[kind] ?? kind} (${countDetail}).`;
  const punish = cfg.punish;
  const pKey = `${guild.id}:${member.id}:${kind}`;
  const canPunish = punish && punish.type !== 'none' && member.id !== guild.ownerId && !(recentPunish.get(pKey) > Date.now() - 8000);
  if (canPunish) {
    recentPunish.set(pKey, Date.now());
    await core.applyPunish(client, guild, member, punish, reason); // tu tao case + ghi log (giong automod.js)
    return;
  }
  // Khong xu phat (punish=none, chu server, hoac vua phat xong) -> van ghi lai de admin biet.
  core.sendLog(
    guild,
    core.caseEmbed({
      id: '-', type: 'warn', userId: member.id, userTag: core.tagOf(member.user),
      modId: client.user.id, modTag: core.tagOf(client.user), reason, createdAt: Date.now(),
    }).setTitle(`Voice Protection | ${kind}`)
  );
}

async function track(client, guild, member, cfg, kind, title, detail, shouldLog) {
  if (shouldLog) logEvent(guild, cfg, title, member, detail);
  if (!cfg.enabled) return;
  const total = bump(cfg, guild.id, member.id, kind);
  if (!total) return;
  try {
    await enforce(client, guild, member, kind, cfg, `${total} lan trong ${cfg.kinds[kind].seconds}s (${detail})`);
  } catch (err) {
    console.warn(`[voice-protection] hanh dong that bai (${kind}): ${err.message}`);
  }
}

// ------------------------------------------------------------ entry point: voiceStateUpdate

const skipMember = (client, member) => !member || !member.user || member.user.bot || member.id === client.user.id;

// join/leave/doi kenh, bat/tat camera, chia se man hinh, mic, deafen - tat ca deu di qua 1 su kien
// nay cua discord.js; can intent GatewayIntentBits.GuildVoiceStates (xem src/index.js).
async function handleVoiceStateUpdate(client, oldState, newState) {
  const member = newState.member ?? oldState.member;
  if (skipMember(client, member)) return false;
  const guild = newState.guild ?? oldState.guild;
  const automodCfg = core.load(guild.id).config.automod;
  const cfg = automodCfg.voice;
  if (!automodCfg.enabled || (!cfg.enabled && !cfg.log)) return false;

  const channel = newState.channel ?? oldState.channel;
  if (channel && core.isExempt(member, channel, automodCfg)) return false;

  const oldCh = oldState.channelId;
  const newCh = newState.channelId;

  if (oldCh !== newCh) {
    if (!oldCh && newCh) await track(client, guild, member, cfg, 'joinLeave', 'Tham gia kenh thoai', `da vao <#${newCh}>`, true);
    else if (oldCh && !newCh) await track(client, guild, member, cfg, 'joinLeave', 'Roi kenh thoai', `da roi <#${oldCh}>`, true);
    else await track(client, guild, member, cfg, 'channelSwitch', 'Doi kenh thoai (VC hopping)', `da chuyen tu <#${oldCh}> sang <#${newCh}>`, true);
    return true; // 1 su kien voiceStateUpdate chi phan anh 1 lan doi kenh; co gan (mute/cam...) khong doi cung luc trong thuc te
  }

  if (oldState.selfVideo !== newState.selfVideo) await track(client, guild, member, cfg, 'camera', 'Camera', `da ${newState.selfVideo ? 'bat' : 'tat'} camera`, true);
  if (oldState.streaming !== newState.streaming) await track(client, guild, member, cfg, 'screenshare', 'Chia se man hinh', `da ${newState.streaming ? 'bat dau' : 'dung'} chia se man hinh`, true);
  if (oldState.selfMute !== newState.selfMute) await track(client, guild, member, cfg, 'mute', 'Mic', `da ${newState.selfMute ? 'tat' : 'bat'} mic`, false);
  if (oldState.selfDeaf !== newState.selfDeaf) await track(client, guild, member, cfg, 'deafen', 'Deafen', `da ${newState.selfDeaf ? 'bat' : 'tat'} che do deafen`, false);
  return true;
}

// ------------------------------------------------------------ entry point: voiceChannelEffectSend (soundboard)

// Xem ghi chu gioi han o dau file: su kien nay chi den khi bot dang o trong kenh thoai do.
async function handleVoiceChannelEffectSend(client, effect) {
  if (effect?.soundId == null) return false; // bo qua reaction emoji thuong, chi tinh hieu ung soundboard
  const guild = effect.guild;
  if (!guild) return false;
  const member = guild.members.cache.get(effect.userId) ?? (await guild.members.fetch(effect.userId).catch(() => null));
  if (!member || skipMember(client, member)) return false;

  const automodCfg = core.load(guild.id).config.automod;
  const cfg = automodCfg.voice;
  if (!automodCfg.enabled || !cfg.enabled) return false;

  const channel = guild.channels.cache.get(effect.channelId);
  if (channel && core.isExempt(member, channel, automodCfg)) return false;

  const total = bump(cfg, guild.id, member.id, 'soundboard');
  if (!total) return false;
  const seconds = cfg.kinds.soundboard?.seconds ?? 20;
  try {
    await enforce(client, guild, member, 'soundboard', cfg, `${total} lan trong ${seconds}s`);
  } catch (err) {
    console.warn(`[voice-protection] hanh dong that bai (soundboard): ${err.message}`);
  }
  return true;
}

module.exports = { handleVoiceStateUpdate, handleVoiceChannelEffectSend, windows };
