'use strict';
// Keyword & Phrase Filters: 26 rule MOI bo sung cho Automod (ben canh 2 rule da co san la "words" =
// Bad Words va "invites" = Discord Invite Links, van nam trong automod.js).
//
// NGUON DANH SACH TU - doc truoc khi chinh sua file nay:
//   - Profanity / Slurs / Sexual Content (3 rule "preset"): KHONG dung danh sach tu tu bien soan. Bot
//     tao 1 AutoMod rule THAT CUA DISCORD voi trigger KeywordPreset - Discord tu duy tri va cap nhat
//     danh sach nay o phia ho, bot khong bao gio doc/luu noi dung that. Day la lua chon DUNG DAN nhat:
//     danh sach do Discord duy tri tot hon bat ky danh sach nao code cung, va bot khong phai "so huu"
//     mot danh sach tu nhay cam nao ca.
//   - Racism / Hate Speech / Harassment / Bullying / Threats / Self-Harm Keywords / Swearing / NSFW
//     Content (8 rule "list" con lai ngoai preset): De TRONG mac dinh, server tu nhap qua lenh
//     `/automod keyword add`. Mot danh sach tu ngu nhay cam/thu ghet/tu hai do AI tu bien soan khong
//     phai lua chon phu hop cho bat ky truong hop nao - nhat la khop tu khoa CHO CAC RULE NAY (dac
//     biet Harassment/Bullying/Threats) von phu thuoc ngu canh rat nhieu, de bao dong gia/sot; nen ket
//     hop voi kenh #report va nguoi kiem duyet that thay vi chi dua vao danh sach tu.
//   - Scam / Phishing / Crypto Scam Keywords / Advertisement (4 rule con lai): CO seed san vai cum tu
//     lua dao/quang cao rat pho bien va cong khai (vd "free nitro", "verify your account") - day la
//     thong tin PHONG THU, khong nhay cam, giup rule hoat dong ngay ma khong can server tu nhap truoc.
//
// REGEX FILTERS (item 22) - 2 CHE DO:
//   - 'native' (mac dinh, KHUYEN NGHI): Discord tu bien dich va chay bang engine Rust cua ho (Discord
//     dung crate `regex` - CO CHU DICH khong ho tro lookaround/backreference de dam bao thoi gian chay
//     LUON tuyen tinh, khong the bi "treo" - day chinh la ly do KHONG co rui ro ReDoS o che do nay).
//     Toi da 10 pattern/rule, moi pattern <= 260 ky tu (gioi han that cua Discord).
//   - 'js': chay tai bot bang engine regex cua JS (co backtracking, VE LY THUYET co the bi ReDoS neu
//     pattern viet kem). lintJsPattern() chan cac dang gay "catastrophic backtracking" pho bien nhat
//     (nhom lap long nhau, backreference, lookaround) TRUOC KHI luu; checkJsRegexFilters() con gioi
//     han do dai van ban dua vao khi chay that de gioi han chi phi toi da. Day khong phai chung minh
//     toan hoc "an toan tuyet doi" - chi dung khi that su can thu (Discord native khong lam duoc, vd
//     vuot 10 pattern hoac can lookaround) va tu chiu trach nhiem kiem tra pattern minh viet.
//
// File nay CHI dinh nghia du lieu/logic kiem tra + dong bo AutoMod rule goc; duoc goi tu
// automod.js (handleMessage) va commands.js (lenh /automod keyword ...).
// LUU Y: file nay KHONG duoc require('./core') - core.js require('./keywordFilters') de lay
// defaultKeywordRulesConfig(), neu require nguoc lai se tao vong lap (core.js dang o giua qua trinh
// khoi tao se bi keywordFilters.js "chup" lai duoi dang module.exports rong {}). Dung ham truncate()
// dung chung tu textMatch.js (ban sao nho cua core.truncate()) thay vi require ca core.js.
const { buildWordRegex, truncate } = require('./textMatch');
const {
  AutoModerationRuleTriggerType,
  AutoModerationRuleEventType,
  AutoModerationActionType,
  AutoModerationRuleKeywordPresetType,
} = require('discord.js');

// ------------------------------------------------------------ seed: chi cho 4 rule lua dao/quang cao (xem ghi chu o tren)

const SEED_SCAM = ['free nitro', 'you have won', 'you have been selected', 'claim your prize', 'limited time giveaway', 'congratulations winner'];
const SEED_PHISHING = ['verify your account', 'account will be suspended', 'confirm your password', 'click here to verify', 'unusual login attempt', 'update your payment information'];
const SEED_CRYPTO = ['free airdrop', 'connect your wallet to claim', 'double your crypto', 'guaranteed returns', 'claim your tokens now', 'exclusive nft mint'];
const SEED_ADVERTISEMENT = ['dm me for', 'check out my server', 'join my server', 'sub4sub', 'follow for follow'];

// ------------------------------------------------------------ danh muc 26 rule (item 2-28, khong gom words/invites da co san)

const KEYWORD_RULE_DEFS = {
  profanity: { kind: 'preset', preset: 'Profanity', label: 'Profanity (tuc tiu chung, danh sach Discord duy tri)' },
  slurs: { kind: 'preset', preset: 'Slurs', label: 'Slurs (tu mang mang tinh phan biet, danh sach Discord duy tri)' },
  sexualContent: { kind: 'preset', preset: 'SexualContent', label: 'Sexual Content (noi dung khieu dam, danh sach Discord duy tri)' },

  swearing: { kind: 'list', wildcard: true, label: 'Swearing (chui the nhe - lop bo sung nhe hon Profanity)' },
  racism: { kind: 'list', wildcard: true, label: 'Racism (phan biet chung toc - bo sung rieng cho rule Slurs)' },
  hateSpeech: { kind: 'list', wildcard: true, label: 'Hate Speech (ngon tu thu ghet noi chung - bo sung rieng cho rule Slurs)' },
  harassment: { kind: 'list', wildcard: true, label: 'Harassment (quay roi mot ca nhan cu the)' },
  bullying: { kind: 'list', wildcard: true, label: 'Bullying (bat nat, che bai lap lai)' },
  threats: { kind: 'list', wildcard: true, label: 'Threats (de doa gay hai)' },
  nsfw: { kind: 'list', wildcard: true, label: 'NSFW Content (tu/cum server tu them, bo sung cho rule Sexual Content)' },
  selfHarm: { kind: 'list', wildcard: true, label: 'Self-Harm Keywords (mac dinh chi bao RIENG cho staff, khong tu xu phat)', notifyStaffDefault: true },

  scam: { kind: 'list', wildcard: true, label: 'Scam Keywords (lua dao chung: trao thuong gia, giveaway gia...)', seed: SEED_SCAM },
  phishing: { kind: 'list', wildcard: true, label: 'Phishing Keywords (gia mao xac thuc tai khoan de lay thong tin)', seed: SEED_PHISHING },
  cryptoScam: { kind: 'list', wildcard: true, label: 'Crypto Scam Keywords (lua dao crypto: airdrop/vi gia...)', seed: SEED_CRYPTO },
  advertisement: { kind: 'list', wildcard: true, label: 'Advertisement (tu quang cao/keo sang server khac)', seed: SEED_ADVERTISEMENT },

  customKeywords: { kind: 'list', wildcard: false, label: 'Custom Keywords (danh sach tuy y, khop CHINH XAC, khong hieu wildcard)' },
  wildcardKeywords: { kind: 'list', wildcard: true, label: 'Wildcard Keywords (giong Custom Keywords nhung ho tro *, vd free*nitro)' },
  blockedPhrases: { kind: 'list', wildcard: false, label: 'Blocked Phrases (danh sach CUM TU nhieu chu, khop chinh xac)' },

  urls: { kind: 'struct', label: 'URLs (chan MOI link http/https, tru domain trong allow-list)' },
  domainBlacklist: { kind: 'struct', label: 'Domain Blacklist (chi chan domain co trong danh sach nay)' },
  ipAddresses: { kind: 'struct', label: 'IP Addresses (dia chi IPv4/IPv6)' },
  emailAddresses: { kind: 'struct', label: 'Email Addresses' },
  phoneNumbers: { kind: 'struct', label: 'Phone Numbers (uu tien so co dau ngan cach; co the bao dong gia/sot)' },

  regexFilters: { kind: 'regex', label: 'Regex Filters (che do native/js - xem README)' },

  requiredPhrases: { kind: 'required', label: 'Required Phrases (tin nhan trong kenh chi dinh PHAI chua 1 trong cac cum tu)' },
  whitelist: { kind: 'whitelist', label: 'Keyword Whitelist (mien tru MOI rule tu khoa mot luc)' },
};

const RULE_IDS = Object.keys(KEYWORD_RULE_DEFS);
const shortLabel = (id) => (KEYWORD_RULE_DEFS[id]?.label || id).split(' (')[0];

function reasonFor(ruleId) {
  return KEYWORD_RULE_DEFS[ruleId] ? `tin nhan vi pham bo loc "${shortLabel(ruleId)}".` : 'tin nhan vi pham automod.';
}

// ------------------------------------------------------------ cau hinh mac dinh (goi tu core.js -> defaultConfig().automod)

function defaultKeywordRulesConfig() {
  const cfg = {};
  for (const [id, def] of Object.entries(KEYWORD_RULE_DEFS)) {
    if (def.kind === 'preset') {
      cfg[id] = { enabled: false };
    } else if (def.kind === 'list') {
      cfg[id] = {
        enabled: false,
        list: def.seed ? [...def.seed] : [],
        wholeWord: true,
        // notifyStaff (selfHarm): KHONG xoa mac dinh - giu nguyen tin de staff doc duoc toan bo ngu
        // canh khi chu dong lien he (xem enforceNotifyStaff trong automod.js). Cac rule list khac xoa mac dinh.
        delete: !def.notifyStaffDefault,
        notifyStaff: !!def.notifyStaffDefault,
        punish: { type: 'none', minutes: 10 },
      };
    }
  }
  // struct / regex / required / whitelist: hinh dang rieng, khong theo khuon list/preset o tren.
  cfg.urls = { enabled: false, allowDomains: [], delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.domainBlacklist = { enabled: false, list: [], delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.ipAddresses = { enabled: false, delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.emailAddresses = { enabled: false, delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.phoneNumbers = { enabled: false, delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.regexFilters = { enabled: false, patterns: [], delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.requiredPhrases = { enabled: false, channelIds: [], list: [], delete: true, punish: { type: 'none', minutes: 10 } };
  cfg.whitelist = { enabled: false, list: [], wholeWord: false };
  return cfg;
}

// ------------------------------------------------------------ item 18-21: cac mau cau truc

const LINK_RE = /https?:\/\/[^\s<>]+/gi; // giong het LINK_RE trong automod.js - lap lai co y (tranh require vong giua 2 file)
const IPV4_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b/;
// IPv6: khop phan lon dang thuong gap, KHONG bao quat het moi kieu rut gon "::" hop le theo RFC -
// du cho muc dich loc noi dung (phat hien "co ve la 1 dia chi IP"), khong phai validator day du.
const IPV6_RE = /\b(?:[A-F0-9]{1,4}:){2,7}[A-F0-9]{1,4}\b|\b(?:[A-F0-9]{1,4}:){1,7}:(?!:)|\b(?:[A-F0-9]{1,4}:){1,6}:[A-F0-9]{1,4}\b/i;
const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
// So dien thoai: uu tien dang co dau ngan cach (PHONE_SEP_RE). PHONE_BARE_RE bat them dang go LIEN
// 9-11 so (dung lookaround JS thuong, khac Rust cua Discord) nhung de bao dong gia hon - vd ma don
// hang/ma xac nhan cung thuong dai 9-11 so; can nhac tat neu server hay trao doi cac ma nay cong khai.
const PHONE_SEP_RE = /(?:\+\d{1,3}[\s.-]?)?(?:\(\d{1,4}\)[\s.-]?)?\d{2,4}(?:[\s.-]\d{2,4}){2,5}/;
const PHONE_BARE_RE = /(?<!\d)(?:\+\d{1,3}[\s.-]?)?\d{9,11}(?!\d)/;

function extractHostname(url) {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return null;
  }
}
const domainMatches = (host, entry) => host === entry || host.endsWith(`.${entry}`);

function checkUrlAllowlist(cfg, text) {
  if (!cfg.enabled) return null;
  for (const link of text.match(LINK_RE) || []) {
    const host = extractHostname(link);
    if (host && !cfg.allowDomains.some((d) => domainMatches(host, d))) return { detail: `link toi "${host}" khong nam trong allow-list` };
  }
  return null;
}

function checkDomainBlacklist(cfg, text) {
  if (!cfg.enabled || !cfg.list.length) return null;
  for (const link of text.match(LINK_RE) || []) {
    const host = extractHostname(link);
    if (host && cfg.list.some((d) => domainMatches(host, d))) return { detail: `domain "${host}" nam trong blacklist` };
  }
  return null;
}

const checkIpAddresses = (cfg, text) => {
  if (!cfg.enabled) return null;
  const m = IPV4_RE.exec(text) ?? IPV6_RE.exec(text);
  return m ? { detail: `dia chi IP "${truncate(m[0], 40)}"` } : null;
};
const checkEmailAddresses = (cfg, text) => {
  if (!cfg.enabled) return null;
  const m = EMAIL_RE.exec(text);
  return m ? { detail: `dia chi email "${truncate(m[0], 40)}"` } : null;
};
const checkPhoneNumbers = (cfg, text) => {
  if (!cfg.enabled) return null;
  const m = PHONE_SEP_RE.exec(text) ?? PHONE_BARE_RE.exec(text);
  return m ? { detail: `so dien thoai "${truncate(m[0].trim(), 40)}"` } : null;
};

function checkStructuralRules(cfg, text) {
  let hit = checkUrlAllowlist(cfg.urls, text);
  if (hit) return { rule: 'urls', hit };
  hit = checkDomainBlacklist(cfg.domainBlacklist, text);
  if (hit) return { rule: 'domainBlacklist', hit };
  hit = checkIpAddresses(cfg.ipAddresses, text);
  if (hit) return { rule: 'ipAddresses', hit };
  hit = checkEmailAddresses(cfg.emailAddresses, text);
  if (hit) return { rule: 'emailAddresses', hit };
  hit = checkPhoneNumbers(cfg.phoneNumbers, text);
  if (hit) return { rule: 'phoneNumbers', hit };
  return null;
}

// ------------------------------------------------------------ item 1 (Self-Harm) + item 5,6,7,8,9,10(nsfw phan bo sung),13,14,15,16,23,24,25: danh sach tu

// Thu tu kiem tra: selfHarm dat DAU TIEN - neu 1 tin vua co tu nhay cam vua trung rule khac (vd
// Custom Keywords), uu tien duong xu ly RIENG (bao staff, xem enforceNotifyStaff trong automod.js)
// thay vi bi mot rule khac xoa/xu phat truoc khi ai kip thay.
const LIST_RULE_ORDER = [
  'selfHarm', 'racism', 'hateSpeech', 'harassment', 'bullying', 'threats', 'swearing', 'nsfw',
  'scam', 'phishing', 'cryptoScam', 'advertisement', 'customKeywords', 'wildcardKeywords', 'blockedPhrases',
];

function checkListRules(cfg, text) {
  for (const id of LIST_RULE_ORDER) {
    const rc = cfg[id];
    if (!rc?.enabled || !rc.list.length) continue;
    const re = buildWordRegex(rc.list, rc.wholeWord, KEYWORD_RULE_DEFS[id].wildcard);
    const m = re?.exec(text);
    if (m) return { rule: id, hit: { detail: `tu khoa "${truncate(m[0], 40)}" (${shortLabel(id)})` } };
  }
  return null;
}

// ------------------------------------------------------------ item 22: Regex Filters, che do 'js'
// (che do 'native' KHONG check o day - Discord tu chan truoc khi tin toi bot, xem syncRegexNativeRule)

function lintJsPattern(pattern) {
  if (typeof pattern !== 'string' || !pattern.trim()) return 'Pattern rong.';
  if (pattern.length > 200) return 'Pattern toi da 200 ky tu.';
  if (/\\[1-9]/.test(pattern)) return 'Khong ho tro backreference (\\1, \\2...) - giong gioi han cua che do native.';
  if (/\(\?[=!<]/.test(pattern)) return 'Khong ho tro lookahead/lookbehind - giong gioi han cua che do native.';
  // Nested-quantifier: 1 nhom co dau lap BEN TRONG, ma chinh nhom do lai bi lap tiep o NGOAI - dang
  // gay "catastrophic backtracking" (ReDoS) pho bien nhat, vd (a+)+, (.*)+, (a|ab)*.
  if (/\([^()]*[+*][^()]*\)[+*]|\([^()]*\{\d*,?\d*\}[^()]*\)[+*{]/.test(pattern)) {
    return 'Nhom lap long nhau (vd (a+)+, (.*)+) de gay treo may (ReDoS) - vui long viet lai pattern.';
  }
  if ((pattern.match(/[+*{]/g) || []).length > 8) return 'Qua nhieu dau lap (+ * {}) trong 1 pattern (toi da 8).';
  try {
    // eslint-disable-next-line no-new
    new RegExp(pattern, 'iu');
  } catch (err) {
    return `Regex khong hop le: ${err.message}`;
  }
  return null; // hop le
}

function lintNativePattern(pattern) {
  if (typeof pattern !== 'string' || !pattern.trim()) return 'Pattern rong.';
  if (pattern.length > 260) return 'Pattern toi da 260 ky tu (gioi han cua Discord).';
  // Discord se tu choi tao rule neu pattern khong hop le voi engine Rust cua ho (vd co lookaround) -
  // kiem tra so bo o day de bao loi ro rang NGAY, thay vi doi Discord tra ve loi kho hieu.
  if (/\\[1-9]/.test(pattern)) return 'Rust regex (Discord) khong ho tro backreference (\\1, \\2...).';
  if (/\(\?[=!<]/.test(pattern)) return 'Rust regex (Discord) khong ho tro lookahead/lookbehind.';
  return null;
}

const jsRegexCache = new Map();
function compiledJsPattern(pattern) {
  if (jsRegexCache.has(pattern)) return jsRegexCache.get(pattern);
  let re = null;
  try {
    re = new RegExp(pattern, 'iu');
  } catch {
    re = null;
  }
  if (jsRegexCache.size >= 200) jsRegexCache.clear();
  jsRegexCache.set(pattern, re);
  return re;
}

// Da qua lintJsPattern() luc them nen coi la an toan de bien dich + chay, nhung VAN gioi han do dai
// van ban dua vao (JS_REGEX_INPUT_CAP) de gioi han chi phi toi da cho 1 pattern "lot luoi" qua buoc lint.
const JS_REGEX_INPUT_CAP = 500;

function checkJsRegexFilters(cfg, text) {
  if (!cfg.enabled || !cfg.patterns.length) return null;
  const sample = text.slice(0, JS_REGEX_INPUT_CAP);
  for (const p of cfg.patterns) {
    if (p.mode !== 'js') continue;
    if (compiledJsPattern(p.pattern)?.test(sample)) return { detail: 'khop pattern tuy chinh (regex, che do js)' };
  }
  return null;
}

// ------------------------------------------------------------ item 27: Required Phrases

function checkRequiredPhrases(cfg, message, text) {
  if (!cfg?.enabled || !cfg.channelIds.length || !cfg.list.length) return null;
  const chId = message.channelId;
  const parentId = message.channel?.parentId;
  if (!cfg.channelIds.includes(chId) && !(parentId && cfg.channelIds.includes(parentId))) return null;
  // khong wholeWord, khong wildcard: chi can CUM TU xuat hien dung nguyen van la du, khop giong nghia
  // den ("phrase" nhieu chu, khac tu khoa don).
  const re = buildWordRegex(cfg.list, false, false);
  if (re?.exec(text)) return null; // co it nhat 1 cum bat buoc -> hop le
  return { detail: 'thieu 1 trong cac cum bat buoc cua kenh nay' };
}

// ------------------------------------------------------------ item 28: Keyword Whitelist

function checkWhitelist(cfg, text) {
  if (!cfg?.enabled || !cfg.list.length) return false;
  return !!buildWordRegex(cfg.list, cfg.wholeWord, true)?.exec(text);
}

// ------------------------------------------------------------ tong hop: goi tu automod.js -> handleMessage()

function checkKeywordRules(cfg, text) {
  const list = checkListRules(cfg, text);
  if (list) return list;
  const struct = checkStructuralRules(cfg, text);
  if (struct) return struct;
  const rx = checkJsRegexFilters(cfg.regexFilters, text);
  if (rx) return { rule: 'regexFilters', hit: rx };
  return null;
}

// ------------------------------------------------------------ dong bo AutoMod rule GOC cua Discord
// (item 2/4/10 = preset, item 22 che do native). Cung mo hinh voi setBuiltinSpamRule() trong automod.js:
// tim rule "cua minh" qua ten + creatorId roi tao/xoa; KHONG bao gio doc/luu noi dung preset that (Discord
// tu quan ly o phia ho). exemptRoles/exemptChannels duoc sao chep tu cau hinh automod goc de nguoi duoc
// mien tru boi bot cung duoc mien tru boi chinh rule native nay (Discord co co che mien tru RIENG, khong
// tu dung chung voi core.isExempt() vi native rule chay o phia Discord, tin bi chan TRUOC KHI toi bot).

const PRESET_RULE_META = {
  profanity: { name: 'Automod - Profanity (built-in)', preset: 'Profanity' },
  slurs: { name: 'Automod - Slurs (built-in)', preset: 'Slurs' },
  sexualContent: { name: 'Automod - Sexual Content (built-in)', preset: 'SexualContent' },
};

async function findMyRule(guild, name) {
  const rules = await guild.autoModerationRules.fetch();
  return rules?.find?.((r) => r.name === name && r.creatorId === guild.client.user.id) ?? null;
}

async function syncPresetRule(guild, cfg, ruleId) {
  const meta = PRESET_RULE_META[ruleId];
  if (!meta) return { ok: false, reason: 'Rule khong hop le.' };
  if (typeof guild.autoModerationRules?.fetch !== 'function') return { ok: false, reason: 'Server nay khong ho tro AutoMod.' };
  let mine;
  try {
    mine = await findMyRule(guild, meta.name);
  } catch (err) {
    return { ok: false, reason: `Khong doc duoc danh sach AutoMod rule: ${err.message}` };
  }
  if (!cfg[ruleId].enabled) {
    if (mine) {
      try {
        await mine.delete(`Automod: tat ${ruleId}`);
      } catch (err) {
        return { ok: false, reason: `Khong xoa duoc AutoMod rule: ${err.message}` };
      }
    }
    return { ok: true };
  }
  if (mine) return { ok: true }; // da co san, khong tao trung
  try {
    await guild.autoModerationRules.create({
      name: meta.name,
      eventType: AutoModerationRuleEventType.MessageSend,
      triggerType: AutoModerationRuleTriggerType.KeywordPreset,
      triggerMetadata: { presets: [AutoModerationRuleKeywordPresetType[meta.preset]] },
      actions: [{ type: AutoModerationActionType.BlockMessage }],
      exemptRoles: cfg.exemptRoles.slice(0, 20),
      exemptChannels: cfg.exemptChannels.slice(0, 20),
      enabled: true,
      reason: `Automod: bat ${ruleId}`,
    });
  } catch (err) {
    return { ok: false, reason: `Khong tao duoc AutoMod rule (can quyen Manage Server): ${err.message}` };
  }
  return { ok: true };
}

async function syncRegexNativeRule(guild, cfg) {
  if (typeof guild.autoModerationRules?.fetch !== 'function') return { ok: false, reason: 'Server nay khong ho tro AutoMod.' };
  const name = 'Automod - Regex Filters (built-in)';
  let mine;
  try {
    mine = await findMyRule(guild, name);
  } catch (err) {
    return { ok: false, reason: `Khong doc duoc danh sach AutoMod rule: ${err.message}` };
  }
  const patterns = cfg.regexFilters.patterns.filter((p) => p.mode === 'native').map((p) => p.pattern).slice(0, 10);
  if (!cfg.regexFilters.enabled || !patterns.length) {
    if (mine) {
      try {
        await mine.delete('Automod: cap nhat Regex Filters (che do native)');
      } catch (err) {
        return { ok: false, reason: `Khong xoa duoc AutoMod rule: ${err.message}` };
      }
    }
    return { ok: true };
  }
  const payload = {
    name,
    eventType: AutoModerationRuleEventType.MessageSend,
    triggerType: AutoModerationRuleTriggerType.Keyword,
    triggerMetadata: { regexPatterns: patterns },
    actions: [{ type: AutoModerationActionType.BlockMessage }],
    exemptRoles: cfg.exemptRoles.slice(0, 20),
    exemptChannels: cfg.exemptChannels.slice(0, 20),
    enabled: true,
    reason: 'Automod: cap nhat Regex Filters (che do native)',
  };
  try {
    if (mine?.edit) await mine.edit(payload);
    else {
      if (mine) await mine.delete('dong bo lai Regex Filters');
      await guild.autoModerationRules.create(payload);
    }
  } catch (err) {
    return { ok: false, reason: `Khong dong bo duoc Regex Filters (can quyen Manage Server, toi da 10 pattern, moi pattern <= 260 ky tu, khong lookaround): ${err.message}` };
  }
  return { ok: true };
}

module.exports = {
  KEYWORD_RULE_DEFS,
  RULE_IDS,
  shortLabel,
  reasonFor,
  defaultKeywordRulesConfig,
  checkKeywordRules,
  checkListRules,
  checkStructuralRules,
  checkJsRegexFilters,
  checkWhitelist,
  checkRequiredPhrases,
  lintJsPattern,
  lintNativePattern,
  extractHostname,
  syncPresetRule,
  syncRegexNativeRule,
};
