'use strict';
// Ham xu ly van ban dung CHUNG giua automod.js (rule "words" cu) va keywordFilters.js (cac rule
// keyword moi o duoi): chuan hoa unicode/zero-width, escape regex, va bien 1 danh sach tu/cum tu
// (co the chua wildcard "*") thanh 1 regex duy nhat, co cache. Tach rieng file nay (thay vi de trong
// automod.js) de keywordFilters.js dung chung duoc ma KHONG tao require-cycle (automod.js se require
// keywordFilters.js de goi cac ham check moi).
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/g;
const WORD_CHAR = '[\\p{L}\\p{N}_]';

const normalize = (s) => s.normalize('NFKC').replace(ZERO_WIDTH, '');
const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
// Ban sao nho cua core.truncate(): keywordFilters.js can ham nay nhung KHONG duoc require('./core')
// (core.js se require('./keywordFilters') de lay defaultKeywordRulesConfig() -> require nguoc lai se
// tao vong lap va core.js dang o giua chung se bi keywordFilters.js thay bang {} rong).
const truncate = (s, n) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));

const regexCache = new Map();

// wildcard=true (mac dinh): "*" trong 1 muc la ky tu dai dien, khop 0+ ky tu chu/so (vd "free*nitro").
// wildcard=false: "*" bi escape thanh ky tu thuong (khop dung nghia den) - dung cho cac rule can khop
// CHINH XAC (Custom Keywords, Blocked Phrases...), tranh nham voi Wildcard Keywords.
function buildWordRegex(list, wholeWord, wildcard = true) {
  const sig = `${wholeWord ? 'w' : 's'}\u0000${wildcard ? '1' : '0'}\u0000${list.join('\u0000')}`;
  if (regexCache.has(sig)) return regexCache.get(sig);
  const parts = list
    .map((w) => normalize(w).toLowerCase().trim())
    .filter(Boolean)
    .map((w) =>
      wildcard
        ? w
            .split('*')
            .map((piece) => escapeRegExp(piece).replace(/\s+/g, '\\s+'))
            .join(`${WORD_CHAR}*`)
        : escapeRegExp(w).replace(/\s+/g, '\\s+')
    );
  let re = null;
  if (parts.length) {
    const body = `(?:${parts.join('|')})`;
    re = new RegExp(wholeWord ? `(?<!${WORD_CHAR})${body}(?!${WORD_CHAR})` : body, 'iu');
  }
  // Cache dung chung cho MOI guild (key da gom noi dung list nen khac list = khac entry) - gioi han
  // 300 (thay vi 50 truoc day) vi tu ~7 rule dung chung 1 cache nay len ~20 rule sau khi them keyword filters.
  if (regexCache.size >= 300) regexCache.clear();
  regexCache.set(sig, re);
  return re;
}

module.exports = { ZERO_WIDTH, WORD_CHAR, normalize, escapeRegExp, buildWordRegex, truncate };
