'use strict';
// Flood Protection: 2 phan he automod DOC LAP voi automod.js (loc tin nhan) va voiceProtection.js
// (kenh thoai), vi ca 2 deu KHONG di qua su kien messageCreate:
//   - Thread Spam: tao thread lien tuc trong thoi gian ngan (vd bot rac spam thread quang cao).
//   - Reaction Spam: 1 nguoi tha reaction nhanh hon toc do bam that cua con nguoi (thuong la
//     script/macro chay qua nhieu tin/nhieu emoji lien tuc).
// Dung CHUNG co che cua so truot voi automod.js/voiceProtection.js (Map "guild:user:kind" -> danh
// sach { ts, ... } trong N giay gan nhat) nhung moi item o day con giu them THAM CHIEU toi doi tuong
// that (thread / reaction) de khi vuot nguong co the "don dep" duoc chinh xac nhung gi da tao ra
// trong cua so vi pham (xoa het thread rac, go het reaction rac) - giong deleteTracked trong automod.js.
const core = require('./core');

// ------------------------------------------------------------ cua so truot

const windows = new Map(); // "guild:user:kind" -> { windowMs, items: [{ ts, payload }] }

// Tra ve DANH SACH item trong cua so neu VUA vuot nguong (va reset dem), nguoc lai null.
function bump(limit, guildId, userId, kind, payload) {
  if (!limit) return null; // rule da bi tat (enabled=false) hoac limit khong hop le
  const now = Date.now();
  const key = `${guildId}:${userId}:${kind}`;
  const windowMs = limit.seconds * 1000;
  const win = windows.get(key) ?? { windowMs, items: [] };
  win.windowMs = windowMs;
  win.items = win.items.filter((i) => now - i.ts <= windowMs);
  win.items.push({ ts: now, payload });
  windows.set(key, win);
  if (win.items.length >= limit.count) {
    windows.delete(key); // reset dong bo - giong automod.js/voiceProtection.js: lan tiep theo dem lai tu dau
    return win.items;
  }
  return null;
}

const recentPunish = new Map(); // "guild:user:kind" -> ts (chong phat lap khi nhieu su kien den gan nhau)

const sweep = setInterval(() => {
  const now = Date.now();
  for (const [key, win] of windows) {
    const last = win.items[win.items.length - 1];
    if (!last || now - last.ts > win.windowMs) windows.delete(key);
  }
  for (const [key, ts] of recentPunish) if (now - ts > 30_000) recentPunish.delete(key);
}, 60_000);
sweep.unref?.();

// ------------------------------------------------------------ xu phat khi vuot nguong

async function enforce(client, guild, member, kind, cfg, reason, cleanupJob) {
  const jobs = [];
  if (cfg.delete !== false && cleanupJob) jobs.push(cleanupJob());

  const punish = cfg.punish;
  const pKey = `${guild.id}:${member.id}:${kind}`;
  const canPunish = punish && punish.type !== 'none' && member.id !== guild.ownerId && !(recentPunish.get(pKey) > Date.now() - 8000);
  if (canPunish) {
    recentPunish.set(pKey, Date.now());
    jobs.push(core.applyPunish(client, guild, member, punish, reason));
  }

  const results = await Promise.allSettled(jobs);
  const failed = results.filter((r) => r.status === 'rejected');
  if (failed.length) console.warn(`[flood-protection] ${failed.length} hanh dong that bai (${reason}): ${failed[0].reason?.message}`);

  if (!canPunish) {
    core.sendLog(
      guild,
      core.caseEmbed({
        id: '-', type: 'warn', userId: member.id, userTag: core.tagOf(member.user),
        modId: client.user.id, modTag: core.tagOf(client.user), reason, createdAt: Date.now(),
      }).setTitle(`Flood Protection | ${kind}`)
    );
  }
}

// ------------------------------------------------------------ entry point: threadCreate (Thread Spam)

const skipMember = (client, member) => !member || !member.user || member.user.bot || member.id === client.user.id;

// `newlyCreated` (tham so thu 2 cua su kien threadCreate) chi true khi thread MOI vua duoc tao that su
// (khac voi thread cu duoc dua vao cache luc bot khoi dong lai) - bo qua truong hop sau de khong tinh
// nham thread cu la "vua tao".
async function handleThreadCreate(client, thread, newlyCreated = true) {
  if (!newlyCreated || !thread.guild || !thread.ownerId) return false;
  const guild = thread.guild;
  const automodCfg = core.load(guild.id).config.automod;
  const cfg = automodCfg.threads;
  if (!automodCfg.enabled || !cfg.enabled) return false;
  if (thread.ownerId === client.user.id) return false; // thread do chinh bot tao (vd tu dong tao thread) khong tinh

  const member = guild.members.cache.get(thread.ownerId) ?? (await guild.members.fetch(thread.ownerId).catch(() => null));
  if (skipMember(client, member)) return false;
  if (core.isExempt(member, thread, automodCfg)) return false;

  const items = bump(cfg.limit, guild.id, member.id, 'threads', thread);
  if (!items) return false;

  const reason = `Flood Protection [threads]: tao ${items.length} thread trong ${cfg.limit.seconds}s (thread spam).`;
  await enforce(client, guild, member, 'threads', cfg, reason, async () => {
    await Promise.allSettled(items.map((i) => i.payload.delete('Flood Protection: thread spam').catch(() => {})));
  });
  return true;
}

// ------------------------------------------------------------ entry point: messageReactionAdd (Reaction Spam)

// reaction/user co the la "partial" (Discord khong gui du du lieu neu tin nhan khong nam trong cache) -
// fetch bu vao khi can; loi thi bo qua em (khong du du lieu de xu ly an toan).
async function handleReactionAdd(client, reaction, user) {
  try {
    if (reaction.partial) reaction = await reaction.fetch();
    if (user.partial) user = await user.fetch();
  } catch {
    return false;
  }
  if (!user || user.bot || user.id === client.user.id) return false;
  const message = reaction.message;
  const guild = message?.guild;
  if (!guild) return false; // reaction trong DM

  const automodCfg = core.load(guild.id).config.automod;
  const cfg = automodCfg.reactions;
  if (!automodCfg.enabled || !cfg.enabled) return false;

  const member = guild.members.cache.get(user.id) ?? (await guild.members.fetch(user.id).catch(() => null));
  if (skipMember(client, member)) return false;
  const channel = message.channel ?? guild.channels.cache.get(message.channelId);
  if (channel && core.isExempt(member, channel, automodCfg)) return false;

  const items = bump(cfg.limit, guild.id, member.id, 'reactions', { reaction, userId: user.id });
  if (!items) return false;

  const reason = `Flood Protection [reactions]: tha ${items.length} reaction trong ${cfg.limit.seconds}s (nhanh hon toc do go/bam that).`;
  await enforce(client, guild, member, 'reactions', cfg, reason, async () => {
    await Promise.allSettled(items.map((i) => i.payload.reaction.users.remove(i.payload.userId).catch(() => {})));
  });
  return true;
}

module.exports = { handleThreadCreate, handleReactionAdd, windows };
