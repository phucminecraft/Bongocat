'use strict';
const antinuke = require('../../antinuke/engine');

// Hanh dong do BOT thuc hien nhung do 1 moderator ra lenh: audit log chi ghi "bot" (luon duoc mien tru) nen phai bao
// thang cho Anti-Nuke de tinh nguong dung nguoi. Ban cu dung markTrusted -> bot bo qua hoan toan, mot mod co quyen
// Ban/Kick/Moderate Members (hoac tai khoan mod bi chiem) co the ban/kick/mute hang loat qua bot ma khong ai chan.
// Neu vuot nguong, Anti-Nuke xu phat MOD do va hoan tac (vd unban nan nhan).
function notifyAntiNuke(guild, mod, moduleKey, meta) {
  if (!mod?.id || mod.id === guild.client.user.id) return; // automod / timer cua chinh bot: khong tinh
  antinuke.handleAction(guild.client, guild, mod.id, moduleKey, meta).catch(() => {});
}

module.exports = { notifyAntiNuke };
