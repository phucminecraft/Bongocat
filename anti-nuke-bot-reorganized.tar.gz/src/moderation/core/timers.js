'use strict';
// Luu/xoa timer het han (tempban/tempmute) trong store. CHI luu tru thuan tuy - viec THUC THI khi
// het han (unban/unmute) nam o scheduler.js, KHONG o day, de tranh vong lap require: punishment.js
// va mute.js can goi addTimer/removeTimers (file nay), con scheduler.js lai can goi unbanUser/
// unmuteMember (punishment.js/mute.js) - tach lop nhu vay thi khong ben nao phai require nguoc lai ben kia.
const { load, saveSoon } = require('./store');

function addTimer(guildId, timer) {
  const store = load(guildId);
  store.data.timers.push(timer);
  saveSoon(guildId);
}

function removeTimers(guildId, type, userId) {
  const store = load(guildId);
  const before = store.data.timers.length;
  store.data.timers = store.data.timers.filter((t) => !(t.type === type && t.userId === userId));
  if (store.data.timers.length !== before) saveSoon(guildId);
}

module.exports = { addTimer, removeTimers };
