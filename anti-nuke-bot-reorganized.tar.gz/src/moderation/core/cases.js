'use strict';
// He thong case (lich su moderator): moi hanh dong (/ban /kick /mute /timeout /warn va automod tu
// dong phat) deu sinh ra 1 case danh so tang dan, luu qua store.js. warn/note o cuoi file nay chi
// ghi case, khong tac dong len Discord.
const { EmbedBuilder } = require('discord.js');
const { load, saveSoon } = require('./store');
const { truncate } = require('./helpers');
const { formatDuration } = require('../../util/duration');

const CASE_COLORS = {
  ban: 0xed4245, unban: 0x57f287, kick: 0xe67e22, mute: 0x95a5a6, unmute: 0x57f287, timeout: 0xfee75c, warn: 0xf1c40f, note: 0x3498db,
};

function caseEmbed(c) {
  const e = new EmbedBuilder()
    .setColor(CASE_COLORS[c.type] ?? 0x5865f2)
    .setTitle(`Case #${c.id} | ${c.type.toUpperCase()}`)
    .setTimestamp(c.createdAt)
    .addFields(
      { name: 'Nguoi dung', value: `<@${c.userId}> (\`${c.userTag}\`)`, inline: true },
      { name: 'Moderator', value: `<@${c.modId}> (\`${c.modTag}\`)`, inline: true },
      { name: 'Ly do', value: truncate(c.reason || 'Khong co ly do', 1000) }
    );
  if (c.durationMs) e.addFields({ name: 'Thoi han', value: formatDuration(c.durationMs), inline: true });
  return e;
}

function sendLog(guild, embed) {
  const id = load(guild.id).config.logChannelId;
  if (!id) return;
  const ch = guild.channels.cache.get(id);
  if (!ch?.isTextBased?.()) return;
  ch.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
}

function createCase(guild, { type, user, mod, reason = null, durationMs = null }) {
  const store = load(guild.id);
  const c = {
    id: store.data.nextCaseId++,
    type,
    userId: user.id,
    userTag: user.tag,
    modId: mod.id,
    modTag: mod.tag,
    reason: reason ? truncate(reason, 1000) : null,
    createdAt: Date.now(),
    durationMs: durationMs || null,
    notes: [],
  };
  store.data.cases.push(c);
  saveSoon(guild.id);
  sendLog(guild, caseEmbed(c)); // khong await: log khong duoc lam cham lenh
  return c;
}

const findCase = (guildId, id) => load(guildId).data.cases.find((c) => c.id === id) ?? null;

function listCases(guildId, { userId = null, page = 1, pageSize = 10 } = {}) {
  const all = load(guildId).data.cases;
  const filtered = userId ? all.filter((c) => c.userId === userId) : all;
  const total = filtered.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const p = Math.min(Math.max(1, page), pages);
  // Moi nhat len dau.
  const items = filtered.slice().reverse().slice((p - 1) * pageSize, p * pageSize);
  return { items, total, page: p, pages };
}

function addCaseNote(guildId, id, mod, text) {
  const c = findCase(guildId, id);
  if (!c) return null;
  c.notes.push({ modId: mod.id, modTag: mod.tag, text: truncate(text, 500), at: Date.now() });
  saveSoon(guildId);
  return c;
}

function setCaseReason(guildId, id, reason) {
  const c = findCase(guildId, id);
  if (!c) return null;
  c.reason = truncate(reason, 1000);
  saveSoon(guildId);
  return c;
}

// warn / note chi ghi case, khong tac dong len Discord.
const warnUser = (guild, mod, target, reason) => createCase(guild, { type: 'warn', user: target, mod, reason });
const noteUser = (guild, mod, target, text) => createCase(guild, { type: 'note', user: target, mod, reason: text });

module.exports = { caseEmbed, sendLog, createCase, findCase, listCases, addCaseNote, setCaseReason, warnUser, noteUser };
