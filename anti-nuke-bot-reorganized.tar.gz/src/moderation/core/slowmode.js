'use strict';
// <= 6h: dung slowmode goc cua Discord. > 6h: Discord khong ho tro -> bot tu cuong che
// (van dat native = 6h lam nen de client hien thi dem nguoc). 0 = tat.
const { load, saveSoon, NATIVE_SLOWMODE_MAX, SLOWMODE_MAX } = require('./store');

async function setSlowmode(channel, seconds, reason) {
  if (typeof channel.setRateLimitPerUser !== 'function') throw new Error('Kenh nay khong ho tro slowmode.');
  const store = load(channel.guild.id);
  const n = Math.min(Math.max(0, Math.trunc(seconds)), SLOWMODE_MAX);
  delete store.data.slowmodeLast[channel.id];
  if (n <= NATIVE_SLOWMODE_MAX) {
    await channel.setRateLimitPerUser(n, reason);
    delete store.config.slowmodes[channel.id];
    saveSoon(channel.guild.id);
    return { mode: n === 0 ? 'off' : 'native', seconds: n };
  }
  await channel.setRateLimitPerUser(NATIVE_SLOWMODE_MAX, reason);
  store.config.slowmodes[channel.id] = { seconds: n, mode: 'bot' };
  saveSoon(channel.guild.id);
  return { mode: 'bot', seconds: n };
}

function removeSlowmodeState(guildId, channelId) {
  const store = load(guildId);
  if (store.config.slowmodes[channelId] || store.data.slowmodeLast[channelId]) {
    delete store.config.slowmodes[channelId];
    delete store.data.slowmodeLast[channelId];
    saveSoon(guildId);
  }
}

module.exports = { setSlowmode, removeSlowmodeState };
