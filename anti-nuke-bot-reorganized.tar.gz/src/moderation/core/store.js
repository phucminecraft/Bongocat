'use strict';
// Luu tru: 1 file JSON / server (data/mod/<guildId>.json). Debounce 750ms + ghi atomic (file tam
// roi rename) + khong ghi chong nhau (writing/rewrite) de tranh mat/hong du lieu khi ghi don dap.
// Day la NEN TANG ma moi file khac trong core/ (cases, mute, punishment, timers, slowmode...) deu
// dung chung qua load()/saveSoon() - tach rieng file nay de KHONG file nao khac phai biet chi tiet
// dinh dang JSON/debounce/atomic-write.
const path = require('path');
const { ensureDir, readJson, writeJsonAtomic, writeJsonAtomicSync } = require('../../util/fsx');
// 26 rule Keyword & Phrase Filters moi (item 2-28). MOT CHIEU DUY NHAT: core/store.js -> keywordFilters.js.
// keywordFilters.js KHONG duoc require lai bat ky file nao trong core/ (se tao vong lap require - xem ghi chu dau file do).
const keywordFilters = require('../keywordFilters');

const DATA_DIR = path.join(__dirname, '..', '..', '..', 'data', 'mod');
ensureDir(DATA_DIR);

const NATIVE_SLOWMODE_MAX = 21_600; // 6h, gioi han cua Discord
const SLOWMODE_MAX = 30 * 86_400; // 30 ngay

function defaultConfig() {
  return {
    logChannelId: null,
    mutedRoleId: null,
    prefix: '!', // dung cho prefix-command (vd "!ban ..."); mention-command ("@Bot ban ...") luon hoat dong bat ke gia tri nay. null = tat prefix-command.
    automod: {
      enabled: false,
      exemptRoles: [],
      exemptChannels: [],
      words: { enabled: true, list: [], wholeWord: true, delete: true, punish: { type: 'none', minutes: 10 } },
      invites: { enabled: false, allowGuilds: [], delete: true, punish: { type: 'none', minutes: 10 } },
      // 26 rule Keyword & Phrase Filters moi (Profanity, Slurs, Scam Keywords, Regex Filters, Keyword
      // Whitelist, v.v. - item 2-28): dinh nghia + mac dinh nam trong keywordFilters.js, khong lap lai
      // o day. Xem file do cho danh sach day du + ly do nguon danh sach tu duoc chon nhu vay.
      ...keywordFilters.defaultKeywordRulesConfig(),
      // Character Spam: 1 tin nhan gan nhu chi gom 1 ky tu lap lai (vd "aaaaaaaaaa", "!!!!!!!!!!!").
      // La check TUC THI tren 1 tin (giong words/invites), khong phai dem theo tan suat gui.
      characters: { enabled: false, minLength: 12, minRun: 10, minRatio: 0.7, delete: true, punish: { type: 'none', minutes: 10 } },
      spam: {
        enabled: true,
        // builtin: tao/xoa 1 AutoMod rule GOC cua Discord (trigger_type Spam, toi da 1 rule loai nay/server) -
        // dung ML cua Discord de chan noi dung "spam chung chung", DOC LAP voi cac nguong ben duoi (`limits`,
        // do bot tu dem theo cua so truot). Can bot co quyen Manage Server.
        builtin: false,
        delete: true,
        punish: { type: 'timeout', minutes: 10 },
        // Cac loai co san (xem amountFor trong automod/spamDetector.js): messages, duplicates, rapidMessages,
        // emojis, stickers, gifs, attachments, images, videos, links, inviteLinks, mentions, roleMentions,
        // everyoneMentions, hereMentions, embeds, polls. Chi 3 loai duoi day BAT san; cac loai khac tu bat
        // qua `/automod spam set kind:<...> count:<...> seconds:<...>`.
        limits: {
          messages: { count: 6, seconds: 5 },
          duplicates: { count: 3, seconds: 30 },
          mentions: { count: 6, seconds: 10 },
        },
      },
      // Thread Spam: tao thread lien tuc trong thoi gian ngan.
      threads: { enabled: false, delete: true, punish: { type: 'timeout', minutes: 10 }, limit: { count: 3, seconds: 30 } },
      // Reaction Spam: 1 nguoi tha reaction nhanh hon toc do go/bam that cua con nguoi (thuong la script/macro).
      // `delete` o day nghia la GO cac reaction da tracked trong cua so vi pham (khong co "tin nhan" de xoa).
      reactions: { enabled: false, delete: true, punish: { type: 'timeout', minutes: 10 }, limit: { count: 12, seconds: 8 } },
      // Voice Protection: chong spam trong kenh thoai (join/leave, doi kenh, bat/tat cam/chia se
      // man hinh/mic/deafen, soundboard) + ghi log day du cac su kien de admin xem lai duoc du
      // khong co mat truc tiep. `enabled` bat/tat viec dem nguong + xu phat; `log` bat/tat rieng
      // viec ghi lai su kien (join/leave/doi kenh/camera/chia se man hinh) vao kenh log - doc lap
      // voi `enabled` de co the chi bat ghi log ma khong tu dong xu phat ai, hoac nguoc lai.
      voice: {
        enabled: false,
        log: false,
        punish: { type: 'timeout', minutes: 10 },
        kinds: {
          joinLeave: { count: 6, seconds: 30 },
          channelSwitch: { count: 5, seconds: 30 },
          camera: { count: 6, seconds: 30 },
          screenshare: { count: 6, seconds: 30 },
          mute: { count: 8, seconds: 20 },
          deafen: { count: 8, seconds: 20 },
          soundboard: { count: 5, seconds: 20 },
        },
      },
    },
    slowmodes: {}, // chi luu cac slowmode do bot quan ly (> 6h): { channelId: { seconds, mode: 'bot' } }
  };
}

function defaultData() {
  return { nextCaseId: 1, cases: [], timers: [], mutes: {}, slowmodeLast: {} };
}

const isPlain = (v) => v && typeof v === 'object' && !Array.isArray(v);

function merge(base, patch) {
  if (!isPlain(patch)) return base;
  const out = { ...base };
  for (const k of Object.keys(patch)) {
    if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
    out[k] = isPlain(base[k]) && isPlain(patch[k]) ? merge(base[k], patch[k]) : patch[k];
  }
  return out;
}

const stores = new Map();
const saveTimers = new Map();
const writing = new Set();
const rewrite = new Set();

const fileOf = (guildId) => path.join(DATA_DIR, `${guildId}.json`);

function load(guildId) {
  if (!/^\d{5,25}$/.test(String(guildId))) throw new Error('guildId khong hop le');
  if (stores.has(guildId)) return stores.get(guildId);
  // File hong duoc DOI TEN (.corrupt-<ts>) thay vi bi ghi de len o lan luu ke tiep -> khong mat toan bo case/cau hinh.
  const { value: raw } = readJson(fileOf(guildId));
  const config = merge(defaultConfig(), raw?.config);
  // limits la tap hop nguoi dung tu bat/tat tung loai: khong duoc tron lai voi mac dinh,
  // neu khong loai da tat bang /automod spam off se tu bat lai sau khi khoi dong.
  if (isPlain(raw?.config?.automod?.spam?.limits)) config.automod.spam.limits = raw.config.automod.spam.limits;
  // Tuong tu spam.limits: voice.kinds la tap hop nguoi dung tu bat/tat tung loai, khong duoc tron
  // lai voi mac dinh (neu khong loai da tat bang /automod voice off se tu bat lai sau khi khoi dong).
  if (isPlain(raw?.config?.automod?.voice?.kinds)) config.automod.voice.kinds = raw.config.automod.voice.kinds;
  const data = { ...defaultData(), ...(raw?.data || {}) };
  const store = { config, data };
  stores.set(guildId, store);
  return store;
}

// slowmodeLast chi la trang thai tam (moi tin nhan deu doi) -> khong ghi ra dia.
function serialize(store) {
  const { slowmodeLast, ...data } = store.data; // eslint-disable-line no-unused-vars
  return JSON.stringify({ config: store.config, data });
}

// Ghi debounce + atomic (ghi file tam roi rename) + khong ghi chong nhau.
function saveSoon(guildId) {
  if (saveTimers.has(guildId)) return;
  const t = setTimeout(() => {
    saveTimers.delete(guildId);
    flush(guildId);
  }, 750);
  t.unref?.();
  saveTimers.set(guildId, t);
}

function flush(guildId) {
  const store = stores.get(guildId);
  if (!store) return;
  if (writing.has(guildId)) {
    rewrite.add(guildId);
    return;
  }
  writing.add(guildId);
  writeJsonAtomic(fileOf(guildId), serialize(store))
    .catch((err) => console.error(`[mod] Ghi du lieu guild ${guildId} that bai: ${err.message}`))
    .finally(() => {
      writing.delete(guildId);
      if (rewrite.delete(guildId)) flush(guildId);
    });
}

// Goi khi tat bot de khong mat du lieu dang cho debounce.
function flushAllSync() {
  for (const [guildId, t] of saveTimers) {
    clearTimeout(t);
    saveTimers.delete(guildId);
  }
  for (const [guildId, store] of stores) {
    try {
      writeJsonAtomicSync(fileOf(guildId), serialize(store));
    } catch (err) {
      console.error(`[mod] Ghi dong bo guild ${guildId} that bai: ${err.message}`);
    }
  }
}

module.exports = { NATIVE_SLOWMODE_MAX, SLOWMODE_MAX, load, saveSoon, flushAllSync };
