'use strict';
// Mute bang role rieng (khac /timeout: khong gioi han 28 ngay cua Discord, va GIU NGUYEN khi thanh
// vien roi roi vao lai server - chong lach mute bang leave/rejoin qua applyMuteOnJoin, duoc goi tu
// event GuildMemberAdd trong moderation/index.js).
const { load, saveSoon } = require('./store');
const { reasonFor, who } = require('./helpers');
const { addTimer, removeTimers } = require('./timers');
const { createCase } = require('./cases');
const { notifyAntiNuke } = require('./notify');

const MUTED_DENY = {
  SendMessages: false,
  SendMessagesInThreads: false,
  AddReactions: false,
  Speak: false,
  Stream: false,
  CreatePublicThreads: false,
  CreatePrivateThreads: false,
};

const mutedRoleExists = (guild) => {
  const { config } = load(guild.id);
  return Boolean((config.mutedRoleId && guild.roles.cache.has(config.mutedRoleId)) || guild.roles.cache.some((r) => r.name === 'Muted'));
};

// Nhieu lenh /mute den cung luc khi chua co role Muted phai DUNG CHUNG 1 lan tao (truoc day moi lenh tao 1 role rieng).
const roleCreation = new Map(); // guildId -> Promise<Role>

async function createMutedRole(guild) {
  const role = await guild.roles.create({ name: 'Muted', color: 0x5c5c5c, permissions: [], reason: 'Tu dong tao role Muted' });
  // Chi chay 1 lan luc tao role; cac lan mute sau chi gan role.
  await Promise.allSettled(
    guild.channels.cache
      .filter((c) => c.permissionOverwrites?.create)
      .map((c) => c.permissionOverwrites.create(role, MUTED_DENY).catch(() => {}))
  );
  return role;
}

async function getMutedRole(guild, create = true) {
  const store = load(guild.id);
  let role = store.config.mutedRoleId ? guild.roles.cache.get(store.config.mutedRoleId) : null;
  if (!role) role = guild.roles.cache.find((r) => r.name === 'Muted') ?? null;
  if (!role && create) {
    let pending = roleCreation.get(guild.id);
    if (!pending) {
      pending = createMutedRole(guild).finally(() => roleCreation.delete(guild.id));
      roleCreation.set(guild.id, pending);
    }
    role = await pending;
  }
  if (role && store.config.mutedRoleId !== role.id) {
    store.config.mutedRoleId = role.id;
    saveSoon(guild.id);
  }
  return role;
}

// Kenh moi tao sau khi co role Muted cung phai chan role nay.
function protectNewChannel(channel) {
  const id = channel.guild && load(channel.guild.id).config.mutedRoleId;
  const role = id && channel.guild.roles.cache.get(id);
  if (role && channel.permissionOverwrites?.create) channel.permissionOverwrites.create(role, MUTED_DENY).catch(() => {});
}

// Nguoi dang bi mute vao lai server -> gan lai role (chong thoat/vao de lach mute).
async function applyMuteOnJoin(member) {
  const store = load(member.guild.id);
  const entry = store.data.mutes[member.id];
  if (!entry) return;
  if (entry.until && entry.until <= Date.now()) {
    delete store.data.mutes[member.id];
    saveSoon(member.guild.id);
    return;
  }
  const role = await getMutedRole(member.guild, false);
  if (role) member.roles.add(role, 'Mute con hieu luc (vao lai server)').catch(() => {});
}

async function muteMember(guild, mod, member, reason, durationMs = 0) {
  const role = await getMutedRole(guild, true);
  await member.roles.add(role, reasonFor(mod, reason));
  notifyAntiNuke(guild, mod, 'massTimeout', { memberId: member.id, muteRoleId: role.id });
  const store = load(guild.id);
  store.data.mutes[member.id] = { until: durationMs ? Date.now() + durationMs : 0 };
  removeTimers(guild.id, 'unmute', member.id);
  if (durationMs) addTimer(guild.id, { type: 'unmute', userId: member.id, at: Date.now() + durationMs });
  saveSoon(guild.id);
  return createCase(guild, { type: 'mute', user: who(member), mod, reason, durationMs });
}

async function unmuteMember(guild, mod, member, reason) {
  const role = await getMutedRole(guild, false);
  if (role && member.roles.cache.has(role.id)) await member.roles.remove(role, reasonFor(mod, reason));
  const store = load(guild.id);
  delete store.data.mutes[member.id];
  removeTimers(guild.id, 'unmute', member.id);
  saveSoon(guild.id);
  return createCase(guild, { type: 'unmute', user: who(member), mod, reason });
}

module.exports = { mutedRoleExists, getMutedRole, protectNewChannel, applyMuteOnJoin, muteMember, unmuteMember };
