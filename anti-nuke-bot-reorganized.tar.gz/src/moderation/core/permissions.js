'use strict';
// Mien tru automod (dung chung cho loc tin nhan va Voice Protection): tach rieng vi khong phu
// thuoc luu tru - chi can PermissionFlagsBits + du lieu member/channel/cfg truyen vao.
const { PermissionFlagsBits } = require('discord.js');

const BYPASS_PERMS = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageMessages,
  PermissionFlagsBits.ManageChannels,
];

function hasBypassPerm(member) {
  if (member.id === member.guild.ownerId) return true;
  return BYPASS_PERMS.some((p) => member.permissions.has(p));
}

// cfg can co exemptRoles/exemptChannels (automod goc, khong phai automod.words/spam/voice...).
function isExempt(member, channel, cfg) {
  if (hasBypassPerm(member)) return true;
  if (cfg.exemptRoles.some((id) => member.roles.cache.has(id))) return true;
  return cfg.exemptChannels.includes(channel.id) || (channel.parentId && cfg.exemptChannels.includes(channel.parentId));
}

module.exports = { hasBypassPerm, isExempt };
