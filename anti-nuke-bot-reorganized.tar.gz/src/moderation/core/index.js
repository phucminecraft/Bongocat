'use strict';
// Lap rap toan bo "loi" cua he thong moderation tu cac file tinh nang rieng trong thu muc nay
// (store/helpers/permissions/notify/cases/timers/mute/punishment/scheduler/slowmode) va export
// LAI DUNG BO MAT PHANG nhu core.js truoc day, de moi noi dang goi require('./core') hoac
// require('../moderation/core') (automod/, commands/, voiceProtection.js, floodProtection.js,
// textCommands.js, cac file test...) tiep tuc chay KHONG CAN SUA GI - Node tu phan giai
// require('./core') sang file nay vi core.js gio la thu muc.
const { MAX_TIMEOUT_MS } = require('../../util/constants');
const { parseDuration, formatDuration } = require('../../util/duration');
const store = require('./store');
const helpers = require('./helpers');
const permissions = require('./permissions');
const cases = require('./cases');
const mute = require('./mute');
const punishment = require('./punishment');
const timers = require('./timers');
const scheduler = require('./scheduler');
const slowmode = require('./slowmode');

module.exports = {
  NATIVE_SLOWMODE_MAX: store.NATIVE_SLOWMODE_MAX,
  SLOWMODE_MAX: store.SLOWMODE_MAX,
  MAX_TIMEOUT_MS,
  load: store.load,
  saveSoon: store.saveSoon,
  flushAllSync: store.flushAllSync,
  parseDuration,
  formatDuration,
  truncate: helpers.truncate,
  tagOf: helpers.tagOf,
  who: helpers.who,
  botWho: helpers.botWho,
  hasBypassPerm: permissions.hasBypassPerm,
  isExempt: permissions.isExempt,
  caseEmbed: cases.caseEmbed,
  sendLog: cases.sendLog,
  createCase: cases.createCase,
  findCase: cases.findCase,
  listCases: cases.listCases,
  addCaseNote: cases.addCaseNote,
  setCaseReason: cases.setCaseReason,
  mutedRoleExists: mute.mutedRoleExists,
  getMutedRole: mute.getMutedRole,
  protectNewChannel: mute.protectNewChannel,
  applyMuteOnJoin: mute.applyMuteOnJoin,
  banUser: punishment.banUser,
  unbanUser: punishment.unbanUser,
  kickMember: punishment.kickMember,
  timeoutMember: punishment.timeoutMember,
  muteMember: mute.muteMember,
  unmuteMember: mute.unmuteMember,
  warnUser: cases.warnUser,
  noteUser: cases.noteUser,
  disconnectMember: punishment.disconnectMember,
  applyPunish: punishment.applyPunish,
  startTimers: scheduler.startTimers,
  processTimers: scheduler.processTimers,
  setSlowmode: slowmode.setSlowmode,
  removeSlowmodeState: slowmode.removeSlowmodeState,
  removeTimers: timers.removeTimers,
};
