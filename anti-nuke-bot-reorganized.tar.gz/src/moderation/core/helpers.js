'use strict';
// Tien ich dinh dang nho dung chung boi cases.js/mute.js/punishment.js/scheduler.js: khong luu tru,
// khong goi Discord API - chi bien doi du lieu san co thanh chuoi/hinh dang can dung.

const truncate = (s, n) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));
const tagOf = (u) => u?.tag ?? u?.username ?? String(u?.id);
const who = (x) => ({ id: x.id, tag: tagOf(x.user ?? x) });
const botWho = (client) => ({ id: client.user.id, tag: tagOf(client.user) });
const reasonFor = (mod, reason) => truncate(`${reason || 'Khong co ly do'} (mod: ${mod.tag})`, 512);

module.exports = { truncate, tagOf, who, botWho, reasonFor };
