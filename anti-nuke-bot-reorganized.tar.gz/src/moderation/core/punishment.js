'use strict';
// Hanh dong xu phat truc tiep (moi hanh dong = 1 case, xem cases.js). applyPunish o cuoi file la
// dispatcher dung chung cho MOI noi automod tu dong xu phat (loc tin nhan lan Voice Protection):
// nhan { type, minutes } roi goi dung ham hanh dong tuong ung.
const { MAX_TIMEOUT_MS } = require('../../util/constants');
const { reasonFor, who, botWho } = require('./helpers');
const { notifyAntiNuke } = require('./notify');
const { addTimer, removeTimers } = require('./timers');
const { createCase, warnUser } = require('./cases');
const { muteMember } = require('./mute');

async function banUser(guild, mod, target, reason, { durationMs = 0, deleteSeconds = 0 } = {}) {
  await guild.members.ban(target.id, { deleteMessageSeconds: deleteSeconds, reason: reasonFor(mod, reason) });
  notifyAntiNuke(guild, mod, 'massBan', { userId: target.id });
  removeTimers(guild.id, 'unban', target.id);
  if (durationMs) addTimer(guild.id, { type: 'unban', userId: target.id, userTag: target.tag, at: Date.now() + durationMs });
  return createCase(guild, { type: 'ban', user: target, mod, reason, durationMs });
}

async function unbanUser(guild, mod, target, reason) {
  await guild.members.unban(target.id, reasonFor(mod, reason));
  removeTimers(guild.id, 'unban', target.id);
  return createCase(guild, { type: 'unban', user: target, mod, reason });
}

async function kickMember(guild, mod, member, reason) {
  await member.kick(reasonFor(mod, reason));
  notifyAntiNuke(guild, mod, 'massKick', { userId: member.id });
  return createCase(guild, { type: 'kick', user: who(member), mod, reason });
}

async function timeoutMember(guild, mod, member, durationMs, reason) {
  const ms = Math.min(durationMs, MAX_TIMEOUT_MS);
  await member.timeout(ms, reasonFor(mod, reason));
  notifyAntiNuke(guild, mod, 'massTimeout', { memberId: member.id });
  return createCase(guild, { type: 'timeout', user: who(member), mod, reason, durationMs: ms });
}

// Ngat khoi kenh thoai (khac /kick: khong duoi khoi server, chi ngat ket noi voice hien tai).
// Dung cho Voice Protection khi chi can cat ngang hanh vi (soundboard/mute-spam...) ma khong can
// timeout ca kenh chat. Neu nguoi do khong con trong kenh thoai nao thi khong co gi de ngat -> bo qua
// êm, khong tao case rac. Khong bao antinuke: day la hanh dong nhe, tan suat cao, khong phai dang
// hanh vi "mass" ma anti-nuke can theo doi.
async function disconnectMember(guild, mod, member, reason) {
  if (!member.voice?.channel) return null;
  await member.voice.disconnect(reasonFor(mod, reason));
  return createCase(guild, { type: 'disconnect', user: who(member), mod, reason });
}

// Dispatcher dung chung cho moi noi automod tu dong xu phat (loc tin nhan lan Voice Protection):
// nhan { type, minutes } roi goi dung ham hanh dong tuong ung. Tra ve case (hoac null neu 'none'/khong hop le).
async function applyPunish(client, guild, member, punish, reason) {
  const mod = botWho(client);
  const minutes = Math.max(1, Number(punish.minutes) || 10);
  switch (punish.type) {
    case 'warn':
      return warnUser(guild, mod, who(member), reason);
    case 'timeout':
      return timeoutMember(guild, mod, member, minutes * 60_000, reason);
    case 'mute':
      return muteMember(guild, mod, member, reason, minutes * 60_000);
    case 'kick':
      return kickMember(guild, mod, member, reason);
    case 'ban':
      return banUser(guild, mod, who(member), reason);
    case 'disconnect':
      return disconnectMember(guild, mod, member, reason);
    default:
      return null;
  }
}

module.exports = { banUser, unbanUser, kickMember, timeoutMember, disconnectMember, applyPunish };
