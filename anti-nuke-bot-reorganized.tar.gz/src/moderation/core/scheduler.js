'use strict';
// Vong quet timer (moi 5s): thuc thi unban/unmute khi timer het han (dat boi banUser/muteMember qua
// timers.js). Tach rieng khoi timers.js vi file nay can GOI unbanUser/unmuteMember (punishment.js/
// mute.js), trong khi timers.js chi luu/xoa timer thuan tuy - neu gop chung se tao vong lap require.
const { load, saveSoon } = require('./store');
const { botWho } = require('./helpers');
const { unbanUser } = require('./punishment');
const { unmuteMember } = require('./mute');

// Loi vinh vien (khong con gi de khoi phuc): Unknown Guild / Member / User / Ban.
const PERMANENT_ERRORS = new Set([10004, 10007, 10013, 10026]);
const MAX_TIMER_ATTEMPTS = 6;

let timersRunning = false;
async function processTimers(client) {
  if (timersRunning) return;
  timersRunning = true;
  try {
    const now = Date.now();
    for (const guild of client.guilds.cache.values()) {
      const store = load(guild.id);
      const due = store.data.timers.filter((t) => t.at <= now);
      if (!due.length) continue;
      store.data.timers = store.data.timers.filter((t) => t.at > now);
      saveSoon(guild.id);
      const mod = botWho(client);
      for (const t of due) {
        try {
          if (t.type === 'unban') {
            await unbanUser(guild, mod, { id: t.userId, tag: t.userTag ?? t.userId }, 'Het han ban tam thoi');
          } else if (t.type === 'unmute') {
            const member = await guild.members.fetch(t.userId).catch(() => null);
            if (member) await unmuteMember(guild, mod, member, 'Het han mute');
            else delete store.data.mutes[t.userId]; // da roi server, role tu mat
          }
        } catch (err) {
          // Ban cu bo timer ngay sau 1 lan loi (mang chap chon, rate limit...) -> tempban thanh vinh vien, mute khong bao gio het.
          // Nay: loi tam thoi -> xep lai voi backoff (toi da 6 lan); loi vinh vien -> bo han.
          const attempts = (t.attempts || 0) + 1;
          if (PERMANENT_ERRORS.has(err.code)) {
            if (t.type === 'unmute') delete store.data.mutes[t.userId];
            console.warn(`[mod] Timer ${t.type} cho ${t.userId} bi bo (${err.message}).`);
          } else if (attempts < MAX_TIMER_ATTEMPTS) {
            store.data.timers.push({ ...t, attempts, at: Date.now() + Math.min(60_000 * 2 ** (attempts - 1), 3_600_000) });
            saveSoon(guild.id);
            console.warn(`[mod] Timer ${t.type} cho ${t.userId} that bai (${err.message}), thu lai lan ${attempts}.`);
          } else {
            console.error(`[mod] Timer ${t.type} cho ${t.userId} that bai ${attempts} lan, tu bo: ${err.message}`);
          }
        }
      }
    }
  } finally {
    timersRunning = false;
  }
}

function startTimers(client) {
  const t = setInterval(() => processTimers(client).catch((e) => console.warn(`[mod] ${e.message}`)), 5000);
  t.unref?.();
  processTimers(client).catch(() => {});
  return t;
}

module.exports = { processTimers, startTimers };
