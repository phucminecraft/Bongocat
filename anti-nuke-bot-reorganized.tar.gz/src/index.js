// File khoi dong bot - ghep module Anti-Nuke + Moderation vao mot Discord client that.
require('dotenv').config();
const { Client, GatewayIntentBits, Events, Partials } = require('discord.js');
const { setupAntiNuke, flushStorage } = require('./antinuke');
const { setupModeration, flushAllSync } = require('./moderation');

if (!process.env.DISCORD_TOKEN) {
  console.error('Thieu DISCORD_TOKEN trong .env (xem .env.example).');
  process.exit(1);
}

const client = new Client({
  // Phat hien nuke nay dua hoan toan vao su kien guildAuditLogEntryCreate (can GuildModeration + quyen View Audit Log)
  // nen khong con can GuildWebhooks / GuildEmojisAndStickers / GuildInvites / GuildIntegrations: it su kien hon, nhe hon.
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // can bat "Server Members Intent" trong Developer Portal
    GatewayIntentBits.GuildModeration, // audit log entry + ban/unban
    GatewayIntentBits.GuildMessages, // can cho automod/slowmode doc duoc messageCreate
    GatewayIntentBits.MessageContent, // can bat "Message Content Intent" trong Developer Portal - de loc tu/spam doc noi dung tin
    GatewayIntentBits.GuildVoiceStates, // can cho Voice Protection (join/leave/doi kenh/camera/mic/deaf/soundboard)
    GatewayIntentBits.GuildMessageReactions, // can cho Reaction Spam (dem toc do tha reaction) trong Flood Protection
  ],
  // Chi khai bao Partials can cho Reaction Spam nhan dung du lieu khi tin nhan/reaction KHONG nam
  // san trong cache (bot vua khoi dong lai, hoac tin qua cu da bi sweeper don). Khong dung
  // Partials.GuildMember: oldMember thieu du lieu tung gay tinh nham "vua duoc them tat ca role".
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
  allowedMentions: { parse: [], repliedUser: false }, // mac dinh khong ping ai; noi nao can se chi dinh ro
  sweepers: { messages: { interval: 300, lifetime: 900 } }, // bot khong can giu tin nhan cu trong RAM
});

setupAntiNuke(client);
setupModeration(client);

client.once(Events.ClientReady, () => {
  console.log(`Da dang nhap voi ten ${client.user.tag}. Anti-Nuke dang hoat dong.`);
});

// Mot loi khong bat duoc trong 1 handler khong duoc lam sap ca bot dang bao ve server.
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));
process.on('uncaughtException', (err) => console.error('[uncaughtException]', err));

// Tat bot gon gang: ghi not moi du lieu dang cho debounce (mot noi duy nhat, khong con 2 handler chen nhau).
let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Nhan ${signal}, dang luu du lieu va thoat...`);
  try {
    flushStorage();
    flushAllSync();
  } catch (err) {
    console.error('Loi khi luu du lieu luc tat:', err);
  }
  client.destroy().finally(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

client.login(process.env.DISCORD_TOKEN);
