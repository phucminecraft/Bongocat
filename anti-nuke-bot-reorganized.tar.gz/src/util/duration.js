'use strict';
// Tien ich thoi han dung chung toan bot (khong phu thuoc Discord.js hay luu tru): tach rieng tu
// core.js vi day la ham thuan tuy (input/output), khong lien quan store/case/hanh dong.

const UNITS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 };

// "10m", "2h30m", "1d" -> ms. Bat buoc co don vi (tranh nham "10" la phut hay giay). Sai -> null.
function parseDuration(input) {
  if (typeof input !== 'string') return null;
  const s = input.trim().toLowerCase().replace(/\s+/g, '');
  if (!/^(\d+[smhdw])+$/.test(s)) return null;
  let total = 0;
  for (const m of s.matchAll(/(\d+)([smhdw])/g)) total += Number(m[1]) * UNITS[m[2]];
  return Number.isSafeInteger(total) && total > 0 ? total : null;
}

function formatDuration(ms) {
  if (!ms) return '0s';
  const parts = [];
  let rest = Math.round(ms / 1000);
  for (const [label, sec] of [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) {
    const n = Math.floor(rest / sec);
    if (n) parts.push(`${n}${label}`);
    rest -= n * sec;
  }
  return parts.join(' ') || '0s';
}

module.exports = { parseDuration, formatDuration };
