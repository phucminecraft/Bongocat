'use strict';
// Tien ich file dung chung: doc JSON an toan, ghi nguyen tu (tmp + rename), ghi debounce.
const fs = require('fs');
const path = require('path');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

// Doc JSON. Khong co file -> { value: null }. File hong -> DOI TEN thanh <file>.corrupt-<ts>
// (khong bao gio ghi de len file hong: nguoi van hanh con co the cuu du lieu) va bao corrupted.
function readJson(fp) {
  let text;
  try {
    text = fs.readFileSync(fp, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return { value: null, corrupted: false };
    throw err;
  }
  try {
    return { value: JSON.parse(text), corrupted: false };
  } catch (err) {
    const bak = `${fp}.corrupt-${Date.now()}`;
    try {
      fs.renameSync(fp, bak);
    } catch {
      /* khong doi ten duoc thi thoi */
    }
    console.error(`[storage] File hong ${fp} (${err.message}) -> giu lai thanh ${path.basename(bak)}`);
    return { value: null, corrupted: true };
  }
}

// Ten file tam PHAI duy nhat cho MOI lan ghi (khong chi theo pid): flushAllSync() co the chay dong bo
// ngay trong luc mot lan ghi bat dong bo khac cho cung file van con dang do (job.writing=true) luc tat
// bot - neu 2 lan ghi dung CHUNG 1 ten file tam se dam vao nhau (mot ben rename di trong luc ben kia
// dang viet). Hau to random + counter loai bo hoan toan kha nang dung ten.
let tmpSeq = 0;
const tmpNameFor = (fp) => `${fp}.${process.pid}.${Date.now()}.${(tmpSeq = (tmpSeq + 1) % 1_000_000)}.${Math.random().toString(36).slice(2, 8)}.tmp`;

async function writeJsonAtomic(fp, data) {
  const tmp = tmpNameFor(fp);
  await fs.promises.writeFile(tmp, typeof data === 'string' ? data : JSON.stringify(data));
  await fs.promises.rename(tmp, fp);
}

function writeJsonAtomicSync(fp, data) {
  const tmp = tmpNameFor(fp);
  fs.writeFileSync(tmp, typeof data === 'string' ? data : JSON.stringify(data));
  fs.renameSync(tmp, fp);
}

// Ghi debounce theo tung file, khong bao gio 2 lan ghi chong nhau tren cung 1 file.
class JsonWriter {
  constructor(delayMs = 300) {
    this.delay = delayMs;
    this.jobs = new Map(); // fp -> { getData, timer, writing, dirty }
  }

  schedule(fp, getData) {
    let job = this.jobs.get(fp);
    if (!job) {
      job = { getData, timer: null, writing: false, dirty: false };
      this.jobs.set(fp, job);
    }
    job.getData = getData;
    if (job.timer) return;
    job.timer = setTimeout(() => {
      job.timer = null;
      this._run(fp, job);
    }, this.delay);
    job.timer.unref?.();
  }

  _run(fp, job) {
    if (job.writing) {
      job.dirty = true;
      return;
    }
    let text;
    try {
      text = JSON.stringify(job.getData());
    } catch (err) {
      console.error(`[storage] Khong serialize duoc ${fp}: ${err.message}`);
      return;
    }
    job.writing = true;
    writeJsonAtomic(fp, text)
      .catch((err) => console.error(`[storage] Ghi ${fp} that bai: ${err.message}`))
      .finally(() => {
        job.writing = false;
        if (job.dirty) {
          job.dirty = false;
          this._run(fp, job);
        }
      });
  }

  // Goi khi tat bot: ghi dong bo moi thu dang cho / dang ghi do.
  flushAllSync() {
    for (const [fp, job] of this.jobs) {
      if (!job.timer && !job.dirty && !job.writing) continue;
      if (job.timer) clearTimeout(job.timer);
      job.timer = null;
      job.dirty = false;
      try {
        writeJsonAtomicSync(fp, JSON.stringify(job.getData()));
      } catch (err) {
        console.error(`[storage] Ghi dong bo ${fp} that bai: ${err.message}`);
      }
    }
  }
}

module.exports = { ensureDir, readJson, writeJsonAtomic, writeJsonAtomicSync, JsonWriter };
