'use strict';
// Discord tu choi timeout >= 28 ngay tinh tu luc SERVER nhan request. Neu dong ho may chu bot
// nhanh hon Discord vai giay thi dung dung 28 ngay se bi loi -> tru 1 phut du phong.
const MAX_TIMEOUT_MS = 28 * 86_400_000 - 60_000;

module.exports = { MAX_TIMEOUT_MS };
