'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('./_setup');
const { makeEnv, addMember, addChannel, addThread, makeMessage, makeReaction, callsOf } = require('./helpers');
const floodProtection = require('../src/moderation/floodProtection');
const core = require('../src/moderation/core');

function setup() {
  const { guild, client, botId, ownerId } = makeEnv();
  const store = core.load(guild.id);
  store.config.automod.enabled = true;
  const member = addMember(guild, {});
  return { guild, client, store, member, botId, ownerId };
}

// ------------------------------------------------------------ Thread Spam (item 45)

test('Thread Spam: tao thread vuot nguong -> xoa CA CAC thread trong cua so + phat', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.threads = { enabled: true, delete: true, punish: { type: 'timeout', minutes: 10 }, limit: { count: 3, seconds: 30 } };
  const t1 = addThread(guild, { ownerId: member.id });
  const t2 = addThread(guild, { ownerId: member.id });
  const t3 = addThread(guild, { ownerId: member.id });
  assert.equal(await floodProtection.handleThreadCreate(client, t1, true), false);
  assert.equal(await floodProtection.handleThreadCreate(client, t2, true), false);
  assert.equal(await floodProtection.handleThreadCreate(client, t3, true), true);
  assert.equal(callsOf(guild, 'thread.delete').length, 3); // xoa ca 3 thread trong cua so vi pham
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('Thread Spam: rule tat -> khong lam gi', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.threads.enabled = false;
  const t = addThread(guild, { ownerId: member.id });
  assert.equal(await floodProtection.handleThreadCreate(client, t, true), false);
  assert.equal(callsOf(guild, 'thread.delete').length, 0);
});

test('Thread Spam: newlyCreated=false (thread cu duoc dua vao cache) -> khong tinh', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.threads = { enabled: true, delete: true, punish: { type: 'none', minutes: 10 }, limit: { count: 1, seconds: 30 } };
  const t = addThread(guild, { ownerId: member.id });
  assert.equal(await floodProtection.handleThreadCreate(client, t, false), false);
  assert.equal(callsOf(guild, 'thread.delete').length, 0);
});

test('Thread Spam: bo qua thread do chinh bot tao', async () => {
  const { guild, client, store, botId } = setup();
  store.config.automod.threads = { enabled: true, delete: true, punish: { type: 'none', minutes: 10 }, limit: { count: 1, seconds: 30 } };
  const t = addThread(guild, { ownerId: client.user.id });
  assert.equal(await floodProtection.handleThreadCreate(client, t, true), false);
});

test('Thread Spam: kenh cha (parentId) nam trong exemptChannels -> mien tru', async () => {
  const { guild, client, store, member } = setup();
  const forum = addChannel(guild, { type: 15 });
  store.config.automod.exemptChannels = [forum.id];
  store.config.automod.threads = { enabled: true, delete: true, punish: { type: 'none', minutes: 10 }, limit: { count: 1, seconds: 30 } };
  const t = addThread(guild, { ownerId: member.id, parentId: forum.id });
  assert.equal(await floodProtection.handleThreadCreate(client, t, true), false);
  assert.equal(callsOf(guild, 'thread.delete').length, 0);
});

test('Thread Spam: chu server duoc mien tru hoan toan (giong cac rule tin nhan khac)', async () => {
  const { guild, client, store, ownerId } = setup();
  store.config.automod.threads = { enabled: true, delete: true, punish: { type: 'timeout', minutes: 10 }, limit: { count: 1, seconds: 30 } };
  const t = addThread(guild, { ownerId });
  assert.equal(await floodProtection.handleThreadCreate(client, t, true), false);
  assert.equal(callsOf(guild, 'thread.delete').length, 0);
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
});

// ------------------------------------------------------------ Reaction Spam (item 48)

test('Reaction Spam: tha reaction vuot nguong -> go CA CAC reaction trong cua so + phat', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.reactions = { enabled: true, delete: true, punish: { type: 'timeout', minutes: 10 }, limit: { count: 3, seconds: 8 } };
  const message = makeMessage(guild, member, {});
  const r1 = makeReaction(message, '👍');
  const r2 = makeReaction(message, '😂');
  const r3 = makeReaction(message, '🔥');
  assert.equal(await floodProtection.handleReactionAdd(client, r1, member.user), false);
  assert.equal(await floodProtection.handleReactionAdd(client, r2, member.user), false);
  assert.equal(await floodProtection.handleReactionAdd(client, r3, member.user), true);
  assert.equal(callsOf(guild, 'reaction.users.remove').length, 3);
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('Reaction Spam: rule tat -> khong lam gi', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.reactions.enabled = false;
  const message = makeMessage(guild, member, {});
  const r = makeReaction(message);
  assert.equal(await floodProtection.handleReactionAdd(client, r, member.user), false);
});

test('Reaction Spam: bo qua reaction cua bot', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.reactions = { enabled: true, delete: true, punish: { type: 'none', minutes: 10 }, limit: { count: 1, seconds: 8 } };
  const botMember = addMember(guild, { bot: true });
  const message = makeMessage(guild, member, {});
  const r = makeReaction(message);
  assert.equal(await floodProtection.handleReactionAdd(client, r, botMember.user), false);
});

test('Reaction Spam: mien tru theo kenh (exemptChannels)', async () => {
  const { guild, client, store, member } = setup();
  const ch = addChannel(guild, { name: 'mod-only' });
  store.config.automod.exemptChannels = [ch.id];
  store.config.automod.reactions = { enabled: true, delete: true, punish: { type: 'none', minutes: 10 }, limit: { count: 1, seconds: 8 } };
  const message = makeMessage(guild, member, { channel: ch });
  const r = makeReaction(message);
  assert.equal(await floodProtection.handleReactionAdd(client, r, member.user), false);
  assert.equal(callsOf(guild, 'reaction.users.remove').length, 0);
});

test('Reaction Spam: reaction.delete=false -> KHONG go reaction nhung van phat', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.reactions = { enabled: true, delete: false, punish: { type: 'timeout', minutes: 10 }, limit: { count: 1, seconds: 8 } };
  const message = makeMessage(guild, member, {});
  const r = makeReaction(message);
  assert.equal(await floodProtection.handleReactionAdd(client, r, member.user), true);
  assert.equal(callsOf(guild, 'reaction.users.remove').length, 0);
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});
