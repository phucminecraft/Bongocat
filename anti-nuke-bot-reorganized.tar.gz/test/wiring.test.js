'use strict';
// Kiem tra "day dien": gan module vao 1 client gia (EventEmitter) roi ban su kien gateway that (guildAuditLogEntryCreate,
// interactionCreate, ready...) xem chay xuyen suot tu audit log -> engine -> xu phat -> hoan tac.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('events');
const { makeEnv, addRole, addMember, sleep, callsOf, P } = require('./helpers');
const { AuditLogEvent: A, Events } = require('discord.js');
const { setupAntiNuke } = require('../src/antinuke');
const { setupModeration } = require('../src/moderation');

function boot() {
  const env = makeEnv();
  const client = Object.assign(new EventEmitter(), env.client);
  env.guild.client = client;
  setupAntiNuke(client);
  setupModeration(client);
  const attacker = addMember(env.guild, { roles: [addRole(env.guild, { name: 'A', perms: P.Administrator, position: 5 }).id] });
  let n = 0;
  const entry = (action, extra = {}) => ({ id: `e${Date.now()}${++n}${Math.random()}`, action, executorId: attacker.id, targetId: `t${n}`, changes: [], ...extra });
  return { ...env, client, attacker, entry };
}

test('xuyen suot: 3 audit log ban tu 1 nguoi qua gateway -> nguoi do bi ban, nan nhan duoc unban', async () => {
  const { client, guild, attacker, entry } = boot();
  for (let i = 0; i < 3; i++) client.emit(Events.GuildAuditLogEntryCreate, entry(A.MemberBanAdd, { targetId: `44${i}` }), guild);
  await sleep(40);
  assert.ok(callsOf(guild, 'ban').some((c) => c[1] === attacker.id));
  assert.deepEqual(callsOf(guild, 'unban').map((c) => c[1]).sort(), ['440', '441', '442']);
});

test('chong dem trung: cung 1 audit log entry ban 3 lan chi tinh 1 hanh dong', async () => {
  const { client, guild, entry } = boot();
  const e = entry(A.MemberBanAdd);
  for (let i = 0; i < 3; i++) client.emit(Events.GuildAuditLogEntryCreate, e, guild);
  await sleep(30);
  assert.equal(callsOf(guild, 'ban').length, 0);
});

test('hanh dong cua he thong Discord (khong co executor) va cua chu server bi bo qua', async () => {
  const { client, guild, entry, ownerId } = boot();
  for (let i = 0; i < 5; i++) client.emit(Events.GuildAuditLogEntryCreate, entry(A.MemberBanAdd, { executorId: null }), guild);
  for (let i = 0; i < 5; i++) client.emit(Events.GuildAuditLogEntryCreate, entry(A.MemberBanAdd, { executorId: ownerId }), guild);
  await sleep(30);
  assert.equal(callsOf(guild, 'ban').length + callsOf(guild, 'unban').length, 0);
});

test('interactionCreate: autocomplete duoc dinh tuyen; lenh la cua module khac khong bi anh huong', async () => {
  const { client, guild } = boot();
  let choices = null;
  client.emit(Events.InteractionCreate, {
    isAutocomplete: () => true, isChatInputCommand: () => false, commandName: 'antinuke',
    options: { getFocused: () => 'bot' }, respond: async (c) => { choices = c; }, guild,
  });
  await sleep(10);
  assert.ok(choices.some((c) => c.value === 'massBotAdd'));
  client.emit(Events.InteractionCreate, { isAutocomplete: () => false, isChatInputCommand: () => true, commandName: 'khong-ton-tai', reply: async () => assert.fail('khong duoc tra loi') });
  await sleep(5);
});

test('loi bat ngo trong xu ly lenh khong lam sap bot: tra loi thong bao loi cho nguoi dung', async () => {
  const { client } = boot();
  const replies = [];
  client.emit(Events.InteractionCreate, {
    isAutocomplete: () => false, isChatInputCommand: () => true, commandName: 'antinuke', inGuild: () => true,
    get guild() { throw new Error('boom'); }, deferred: false, replied: false, reply: async (p) => { replies.push(p); },
  });
  await sleep(10);
  assert.equal(replies.length, 1);
  assert.match(replies[0].content, /loi/i);
});

test('ready: khoi dong snapshot + kiem tra suc khoe (ghi canh bao neu bot thieu quyen) khong loi', async () => {
  const { client, guild, me } = boot();
  me.permissions = new (require('discord.js').PermissionsBitField)(0n); // gia lap bot thieu moi quyen
  const warns = [];
  const orig = console.warn;
  console.warn = (...a) => warns.push(a.join(' '));
  try {
    client.emit(Events.ClientReady);
    await sleep(10);
  } finally {
    console.warn = orig;
  }
  assert.ok(warns.some((w) => /View Audit Log/.test(w)), 'canh bao thieu quyen View Audit Log');
});
