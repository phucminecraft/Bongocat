'use strict';
// Test cho phan MOI bo sung vao Automod: Spam & Flood Detection (item 29-48).
//   - checkCharacterSpam (item 32): check tuc thi tren 1 tin.
//   - amountFor() mo rong (checkSpam): rapidMessages/stickers/gifs/images/videos/inviteLinks/
//     roleMentions/everyoneMentions/hereMentions/embeds/polls.
//   - setBuiltinSpamRule (item 29): tao/xoa AutoMod rule GOC cua Discord.
//   - handleMessage(): tich hop dau-cuoi cho rule characters + vai loai spam moi (xoa tin + phat).
const test = require('node:test');
const assert = require('node:assert/strict');
require('./_setup');
const { makeEnv, addMember, addChannel, makeMessage, callsOf } = require('./helpers');
const automod = require('../src/moderation/automod');
const core = require('../src/moderation/core');

function setup() {
  const { guild, client, ownerId } = makeEnv();
  const store = core.load(guild.id);
  const member = addMember(guild, {});
  return { guild, client, ownerId, store, member };
}

// ------------------------------------------------------------ checkCharacterSpam (item 32)

test('checkCharacterSpam: ky tu lap lien tiep vuot nguong -> bao vi pham', () => {
  const cfg = { enabled: true, minLength: 8, minRun: 8, minRatio: 0.9 };
  const hit = automod.checkCharacterSpam(cfg, 'aaaaaaaaaa');
  assert.ok(hit);
  assert.match(hit.detail, /lap 10 lan lien tiep/);
});

test('checkCharacterSpam: 1 ky tu chiem ty le cao (khong can lien tiep) -> bao vi pham', () => {
  const cfg = { enabled: true, minLength: 8, minRun: 20, minRatio: 0.6 };
  // "a" chiem 10/14 = ~71% nhung khong co day nao lap qua 2 lan lien tiep (duoi nguong minRun=20).
  const hit = automod.checkCharacterSpam(cfg, 'aaXaaXaaXaaXaa');
  assert.ok(hit);
  assert.match(hit.detail, /chiem/);
});

test('checkCharacterSpam: tin nhan binh thuong -> khong bao', () => {
  const cfg = { enabled: true, minLength: 8, minRun: 10, minRatio: 0.7 };
  assert.equal(automod.checkCharacterSpam(cfg, 'chao moi nguoi minh moi vao server nay'), null);
});

test('checkCharacterSpam: tin qua ngan (duoi minLength) -> bo qua du co lap ky tu', () => {
  const cfg = { enabled: true, minLength: 20, minRun: 3, minRatio: 0.5 };
  assert.equal(automod.checkCharacterSpam(cfg, 'aaaa'), null);
});

test('checkCharacterSpam: rule tat -> luon null', () => {
  assert.equal(automod.checkCharacterSpam({ enabled: false, minLength: 1, minRun: 1, minRatio: 0.1 }, 'aaaaaaaaaa'), null);
});

test('checkCharacterSpam: dem dung ky tu emoji (khong vo tinh cat doi surrogate pair)', () => {
  const cfg = { enabled: true, minLength: 4, minRun: 4, minRatio: 0.9 };
  // "😂" la 1 ky tu that (2 code unit UTF-16); lap 5 lan phai bao dung la 5, khong phai 10.
  const hit = automod.checkCharacterSpam(cfg, '😂😂😂😂😂');
  assert.ok(hit);
  assert.match(hit.detail, /lap 5 lan/);
});

// ------------------------------------------------------------ amountFor / checkSpam: cac loai moi

test('checkSpam kind=rapidMessages: giong messages (1 tin = 1 don vi), nguong rieng', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { rapidMessages: { count: 3, seconds: 2 } } };
  const m1 = makeMessage(guild, member, { content: 'a' });
  const m2 = makeMessage(guild, member, { content: 'b' });
  const m3 = makeMessage(guild, member, { content: 'c' });
  assert.equal(automod.checkSpam(cfg, m1, 'a'), null);
  assert.equal(automod.checkSpam(cfg, m2, 'b'), null);
  assert.ok(automod.checkSpam(cfg, m3, 'c'));
});

test('checkSpam kind=images: dem attachment co contentType image/* hoac duoi anh (video khong tinh)', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { images: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { attachments: [{ contentType: 'image/png' }, { name: 'photo.JPG' }, { contentType: 'video/mp4' }] });
  const hit = automod.checkSpam(cfg, m, '');
  assert.ok(hit); // 2 anh (contentType image/png + duoi .JPG) trong 1 tin, video khong tinh -> du nguong 2
});

test('checkSpam kind=images: video khong bi tinh la anh', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { images: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { attachments: [{ contentType: 'video/mp4' }, { contentType: 'video/webm' }] });
  assert.equal(automod.checkSpam(cfg, m, ''), null);
});

test('checkSpam kind=videos: dem attachment video', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { videos: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { attachments: [{ contentType: 'video/mp4' }, { name: 'clip.mov' }] });
  assert.ok(automod.checkSpam(cfg, m, ''));
});

test('checkSpam kind=gifs: nhan link Tenor/Giphy va attachment .gif', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { gifs: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { content: 'xem cai nay https://tenor.com/view/abc-123', attachments: [{ contentType: 'image/gif' }] });
  const hit = automod.checkSpam(cfg, m, m.content);
  assert.ok(hit); // 1 link tenor + 1 attachment gif = 2 >= nguong 2
});

test('checkSpam kind=stickers: dem sticker', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { stickers: { count: 3, seconds: 10 } } };
  const m1 = makeMessage(guild, member, { stickers: ['a'] });
  const m2 = makeMessage(guild, member, { stickers: ['b'] });
  const m3 = makeMessage(guild, member, { stickers: ['c'] });
  assert.equal(automod.checkSpam(cfg, m1, ''), null);
  assert.equal(automod.checkSpam(cfg, m2, ''), null);
  assert.ok(automod.checkSpam(cfg, m3, ''));
});

test('checkSpam kind=embeds: dem so embed trong tin', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { embeds: { count: 4, seconds: 10 } } };
  const m = makeMessage(guild, member, { embeds: [{}, {}, {}, {}] });
  assert.ok(automod.checkSpam(cfg, m, ''));
});

test('checkSpam kind=polls: 1 tin co poll = 1 don vi', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { polls: { count: 2, seconds: 10 } } };
  const m1 = makeMessage(guild, member, { poll: { question: { text: '?' } } });
  const m2 = makeMessage(guild, member, { poll: { question: { text: '?' } } });
  assert.equal(automod.checkSpam(cfg, m1, ''), null);
  assert.ok(automod.checkSpam(cfg, m2, ''));
});

test('checkSpam kind=roleMentions: chi dem role, khong dem user', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { roleMentions: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { mentionUsers: ['1', '2', '3'], mentionRoles: ['r1', 'r2'] });
  assert.ok(automod.checkSpam(cfg, m, ''));
});

test('checkSpam kind=everyoneMentions / hereMentions: dem theo van ban, tach rieng 2 loai', () => {
  const { guild, member } = setup();
  const cfgEveryone = { enabled: true, limits: { everyoneMentions: { count: 2, seconds: 10 } } };
  const cfgHere = { enabled: true, limits: { hereMentions: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { content: '@everyone @everyone xem thong bao, @here khong tinh o day' });
  assert.ok(automod.checkSpam(cfgEveryone, m, m.content));
  assert.equal(automod.checkSpam(cfgHere, m, m.content), null); // chi co 1 lan "@here", nguong 2
});

test('checkSpam kind=inviteLinks: dem link moi bat ke server nao (khac rule invites chan theo allowlist)', () => {
  const { guild, member } = setup();
  const cfg = { enabled: true, limits: { inviteLinks: { count: 2, seconds: 10 } } };
  const m = makeMessage(guild, member, { content: 'discord.gg/abc123 discord.gg/xyz789' });
  assert.ok(automod.checkSpam(cfg, m, m.content));
});

// ------------------------------------------------------------ handleMessage(): tich hop dau-cuoi

test('handleMessage: rule characters vuot nguong -> xoa tin + gui canh bao, KHONG phat (punish=none)', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.enabled = true;
  store.config.automod.characters = { enabled: true, minLength: 8, minRun: 8, minRatio: 0.9, delete: true, punish: { type: 'none', minutes: 10 } };
  const message = makeMessage(guild, member, { content: 'aaaaaaaaaa' });
  const handled = await automod.handleMessage(client, message);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'message.delete').length, 1);
  assert.equal(callsOf(guild, 'channel.send').length, 1); // canh bao trong kenh
  assert.match(callsOf(guild, 'channel.send')[0][2].content, /ky tu/);
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
});

test('handleMessage: tin chi co sticker (khong chu, khong attachment) van duoc xet rule spam(stickers)', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.enabled = true;
  store.config.automod.spam.limits = { stickers: { count: 1, seconds: 10 } };
  const message = makeMessage(guild, member, { content: '', stickers: ['pepe'] });
  const handled = await automod.handleMessage(client, message);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'message.delete').length, 1);
});

test('handleMessage: rule images vuot nguong -> xoa tin + phat (timeout)', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.enabled = true;
  store.config.automod.spam.limits = { images: { count: 2, seconds: 10 } };
  store.config.automod.spam.punish = { type: 'timeout', minutes: 5 };
  const message = makeMessage(guild, member, { attachments: [{ contentType: 'image/png' }, { contentType: 'image/jpeg' }] });
  const handled = await automod.handleMessage(client, message);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'message.delete').length, 1);
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('handleMessage: automod.enabled=false -> khong xet ca characters lan spam moi', async () => {
  const { guild, client, store, member } = setup();
  store.config.automod.enabled = false;
  store.config.automod.characters = { enabled: true, minLength: 4, minRun: 4, minRatio: 0.5, delete: true, punish: { type: 'none', minutes: 10 } };
  const message = makeMessage(guild, member, { content: 'aaaaaaaaaa' });
  assert.equal(await automod.handleMessage(client, message), false);
  assert.equal(callsOf(guild, 'message.delete').length, 0);
});

// ------------------------------------------------------------ setBuiltinSpamRule (item 29)

test('setBuiltinSpamRule(true): tao 1 AutoMod rule loai Spam khi chua co', async () => {
  const { guild } = setup();
  const res = await automod.setBuiltinSpamRule(guild, true);
  assert.equal(res.ok, true);
  const created = callsOf(guild, 'automod.rule.create');
  assert.equal(created.length, 1);
  assert.equal(guild.autoModerationRules._store.size, 1);
});

test('setBuiltinSpamRule(true) goi 2 lan: khong tao trung (Discord chi cho 1 rule Spam/server)', async () => {
  const { guild } = setup();
  await automod.setBuiltinSpamRule(guild, true);
  await automod.setBuiltinSpamRule(guild, true);
  assert.equal(callsOf(guild, 'automod.rule.create').length, 1);
});

test('setBuiltinSpamRule(false): xoa rule da tao truoc do', async () => {
  const { guild } = setup();
  await automod.setBuiltinSpamRule(guild, true);
  const res = await automod.setBuiltinSpamRule(guild, false);
  assert.equal(res.ok, true);
  assert.equal(guild.autoModerationRules._store.size, 0);
  assert.equal(callsOf(guild, 'automod.rule.delete').length, 1);
});

test('setBuiltinSpamRule(false) khi chua co rule: khong loi, khong goi delete', async () => {
  const { guild } = setup();
  const res = await automod.setBuiltinSpamRule(guild, false);
  assert.equal(res.ok, true);
  assert.equal(callsOf(guild, 'automod.rule.delete').length, 0);
});

test('setBuiltinSpamRule(true): thieu quyen Manage Server (create loi) -> tra ve ok=false kem ly do', async () => {
  const { guild } = setup();
  guild.autoModerationRules.create = async () => { throw new Error('Missing Permissions'); };
  const res = await automod.setBuiltinSpamRule(guild, true);
  assert.equal(res.ok, false);
  assert.match(res.reason, /Missing Permissions/);
});
