'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv, addRole, addMember, addChannel, ALL, P } = require('./helpers');
const { AuditLogEvent: A, ChannelType } = require('discord.js');
const { ActionTracker } = require('../src/antinuke/tracker');
const storage = require('../src/antinuke/storage');
const { classify } = require('../src/antinuke/auditStream');
const { isWhitelisted } = require('../src/antinuke/whitelist');
const { MODULE_DEFS } = require('../src/antinuke/config');
const { sanitizeModuleConfig } = require('../src/antinuke/config');

test('tracker: cua so truot dem dung, reset xoa, sweep don rac', () => {
  const t = new ActionTracker();
  assert.equal(t.hit('g', 'u', 'm', 10_000, 1).length, 1);
  assert.equal(t.hit('g', 'u', 'm', 10_000, 2).length, 2);
  assert.equal(t.hit('g', 'other', 'm', 10_000).length, 1, 'moi nguoi 1 bo dem rieng');
  t.reset('g', 'u', 'm');
  assert.equal(t.hit('g', 'u', 'm', 10_000).length, 1);
  // sweep: bucket het han bi xoa (chong ro ri bo nho)
  const before = t.buckets.size;
  t.sweep(Date.now() + 60_000);
  assert.equal(t.buckets.size, 0);
  assert.ok(before > 0);
  clearInterval(t.sweeper);
});

test('tracker: hanh dong ngoai cua so khong duoc tinh', async () => {
  const t = new ActionTracker();
  t.hit('g', 'u', 'm', 30);
  await new Promise((r) => setTimeout(r, 60));
  assert.equal(t.hit('g', 'u', 'm', 30).length, 1);
  clearInterval(t.sweeper);
});

test('storage: file cau hinh hong duoc GIU LAI (khong bi ghi de) va bot dung mac dinh an toan', () => {
  const { guild } = makeEnv();
  const fp = path.join(storage.DATA_DIR, `${guild.id}.json`);
  fs.writeFileSync(fp, '{ day la json hong');
  const cfg = storage.getGuildConfig(guild.id);
  assert.equal(cfg.modules.massBan.limit, MODULE_DEFS.massBan.limit);
  const kept = fs.readdirSync(storage.DATA_DIR).filter((f) => f.startsWith(`${guild.id}.json.corrupt-`));
  assert.equal(kept.length, 1, 'file hong phai duoc doi ten de cuu du lieu');
});

test('storage: gia tri xau tren dia bi chan lai ve pham vi hop le', () => {
  const cfg = storage.mergeWithDefaults({
    whitelistedUsers: ['123456', 'khong-phai-id', 123456, '../../etc/passwd'],
    modules: { massBan: { limit: 0, windowMs: -5, punishment: 'nuke-them-all', enabled: 'yes' } },
    snapshotIntervalMs: 5,
  });
  assert.deepEqual(cfg.whitelistedUsers, ['123456']);
  const m = cfg.modules.massBan;
  assert.ok(m.limit >= 1 && m.windowMs >= 1000);
  assert.equal(m.punishment, MODULE_DEFS.massBan.punishment);
  assert.equal(m.enabled, true);
  assert.ok(cfg.snapshotIntervalMs >= 60_000);
  assert.deepEqual(sanitizeModuleConfig(null, MODULE_DEFS.massKick), { enabled: true, limit: 3, windowMs: 10_000, punishment: 'ban' });
});

test('storage: recordStripped / takeStripped', () => {
  const { guild } = makeEnv();
  storage.recordStripped(guild.id, '111111', ['222222', '333333'], 'massBan');
  storage.recordStripped(guild.id, '111111', ['333333', '444444'], 'massBan');
  const rec = storage.takeStripped(guild.id, '111111');
  assert.deepEqual(rec.roleIds.sort(), ['222222', '333333', '444444']);
  assert.equal(storage.takeStripped(guild.id, '111111'), null);
});

test('whitelist: role whitelist van hieu luc khi member KHONG nam trong cache (bug cu: phat nham nguoi tin cay)', async () => {
  const { guild, client } = makeEnv();
  const trusted = addRole(guild, { name: 'Admin-tin-cay' });
  const m = addMember(guild, { roles: [trusted.id] });
  guild.members.cache.delete(m.id); // gia lap chua duoc cache
  const fetched = [];
  const origFetch = guild.members.fetch;
  guild.members.fetch = async (id) => { fetched.push(id); return typeof id === 'string' && id === m.id ? m : origFetch(id); };
  const cfg = { whitelistedUsers: [], whitelistedBots: [], extraOwners: [], whitelistedRoles: [trusted.id] };
  assert.equal(await isWhitelisted(guild, m.id, cfg, client), true);
  assert.deepEqual(fetched, [m.id], 'phai fetch member tu API');
  // chu server / bot chinh no / extraOwners luon duoc mien tru
  assert.equal(await isWhitelisted(guild, guild.ownerId, cfg, client), true);
  assert.equal(await isWhitelisted(guild, client.user.id, cfg, client), true);
  assert.equal(await isWhitelisted(guild, '999999', { ...cfg, extraOwners: ['999999'] }, client), true);
  // nguoi la khong roi vao role -> khong mien tru; va khong fetch lap lai lien tuc
  guild.members.fetch = async () => { throw new Error('Unknown Member'); };
  assert.equal(await isWhitelisted(guild, '555555', cfg, client), false);
});

// ------------------------------------------------------------ classify (audit log entry -> module)
const E = (action, extra = {}) => ({ id: String(Math.random()), action, executorId: '1', targetId: '2', changes: [], ...extra });

test('classify: anh xa dung module cho tung loai audit log', () => {
  const { guild } = makeEnv();
  const cfg = storage.getGuildConfig(guild.id);
  const mods = (e) => classify(e, guild, cfg).map((x) => x.module);

  assert.deepEqual(mods(E(A.ChannelCreate, { changes: [{ key: 'type', new: ChannelType.GuildCategory }] })), ['massCategoryCreate']);
  assert.deepEqual(mods(E(A.ChannelCreate, { changes: [{ key: 'type', new: ChannelType.GuildText }] })), ['massChannelCreate']);
  assert.deepEqual(mods(E(A.ChannelDelete, { changes: [{ key: 'type', old: ChannelType.GuildCategory }, { key: 'name', old: 'x' }] })), ['massCategoryDelete']);
  assert.deepEqual(mods(E(A.ChannelDelete, { changes: [{ key: 'type', old: ChannelType.GuildVoice }] })), ['massChannelDelete']);
  // 3 loai overwrite deu duoc dem (ban cu chi nhin Update)
  for (const a of [A.ChannelOverwriteCreate, A.ChannelOverwriteUpdate, A.ChannelOverwriteDelete]) assert.deepEqual(mods(E(a)), ['massPermissionChange']);
  // kick / prune truoc day khong duoc theo doi
  assert.deepEqual(mods(E(A.MemberKick)), ['massKick']);
  assert.deepEqual(mods(E(A.MemberPrune, { extra: { removed: 500 } })), ['massPrune']);
  assert.deepEqual(mods(E(A.MemberBanAdd)), ['massBan']);
  assert.deepEqual(mods(E(A.BotAdd)), ['massBotAdd']);
  assert.deepEqual(mods(E(A.RoleDelete, { changes: [{ key: 'name', old: 'Mod' }] })), ['massRoleDelete']);
  assert.deepEqual(mods(E(A.WebhookCreate)), ['massWebhookCreate']);
  assert.deepEqual(mods(E(A.IntegrationUpdate)), ['massIntegrationChange']);
  assert.deepEqual(mods(E(A.GuildUpdate)), ['guildSettingChange']);
  assert.deepEqual(mods(E(9999)), [], 'loai khong quan tam thi bo qua');
});

test('classify: timeout chi tinh khi DAT timeout (khong tinh khi go timeout)', () => {
  const { guild } = makeEnv();
  const cfg = storage.getGuildConfig(guild.id);
  const set = E(A.MemberUpdate, { changes: [{ key: 'communication_disabled_until', new: new Date(Date.now() + 60_000).toISOString() }] });
  const clear = E(A.MemberUpdate, { changes: [{ key: 'communication_disabled_until', old: new Date(Date.now() + 60_000).toISOString() }] });
  assert.deepEqual(classify(set, guild, cfg).map((x) => x.module), ['massTimeout']);
  assert.deepEqual(classify(clear, guild, cfg), []);
  assert.deepEqual(classify(E(A.MemberUpdate, { changes: [{ key: 'nick', new: 'a' }] }), guild, cfg), []);
});

test('classify: nang quyen - cap role nguy hiem / role whitelist, va them quyen nguy hiem cho role', () => {
  const { guild } = makeEnv();
  const cfg = storage.getGuildConfig(guild.id);
  const admin = addRole(guild, { name: 'Admin', perms: P.Administrator });
  const plain = addRole(guild, { name: 'Vui', perms: P.SendMessages });
  const wl = addRole(guild, { name: 'WL', perms: 0n });
  cfg.whitelistedRoles = [wl.id];
  const grant = (ids) => E(A.MemberRoleUpdate, { changes: [{ key: '$add', new: ids.map((id) => ({ id })) }] });

  let out = classify(grant([plain.id]), guild, cfg).map((x) => x.module);
  assert.deepEqual(out, ['massRoleAdd']);
  out = classify(grant([admin.id]), guild, cfg).map((x) => x.module);
  assert.deepEqual(out, ['massRoleAdd', 'privilegeEscalation']);
  out = classify(grant([wl.id]), guild, cfg).map((x) => x.module);
  assert.deepEqual(out, ['massRoleAdd', 'privilegeEscalation'], 'cap role whitelist = cap quyen mien tru');

  const upd = (o, n) => E(A.RoleUpdate, { targetId: plain.id, changes: [{ key: 'permissions', old: String(o), new: String(n) }] });
  assert.deepEqual(classify(upd(0n, P.SendMessages), guild, cfg).map((x) => x.module), ['massPermissionChange']);
  const esc = classify(upd(P.SendMessages, P.SendMessages | P.BanMembers), guild, cfg);
  assert.deepEqual(esc.map((x) => x.module), ['massPermissionChange', 'privilegeEscalation']);
  assert.equal(esc[1].meta.changes[0].old, String(P.SendMessages), 'giu quyen goc de hoan tac');
  assert.deepEqual(classify(upd(P.BanMembers, P.SendMessages), guild, cfg).map((x) => x.module), ['massPermissionChange'], 'HA quyen thi khong phai nang quyen');
  assert.deepEqual(classify(E(A.RoleUpdate, { changes: [{ key: 'name', old: 'a', new: 'b' }] }), guild, cfg).map((x) => x.module), ['massRoleUpdate']);
});

test('classify: ChannelOverwrite* ghi lai overwrite TRUOC/SAU de mitigate.js hoan tac duoc (khong chi dem)', () => {
  const { guild } = makeEnv();
  const cfg = storage.getGuildConfig(guild.id);
  const ch = addChannel(guild, { name: 'general' });
  const roleId = '555000111';

  // CREATE: overwrite MOI (chua ton tai truoc do) -> old=null.
  const create = E(A.ChannelOverwriteCreate, {
    targetId: ch.id,
    extra: { id: roleId, type: 0, roleName: 'Vai tro' },
    changes: [{ key: 'allow', new: String(P.BanMembers) }, { key: 'deny', new: '0' }],
  });
  const [c1] = classify(create, guild, cfg);
  assert.equal(c1.module, 'massPermissionChange');
  assert.equal(c1.meta.overwrite.old, null);
  assert.deepEqual(c1.meta.overwrite.new, { allow: String(P.BanMembers), deny: '0' });
  assert.equal(c1.meta.overwrite.targetType, 0);
  assert.equal(c1.meta.overwrite.roleName, 'Vai tro');

  // DELETE: overwrite bi XOA HOAN TOAN -> new=null, old = gia tri truoc khi xoa.
  const del = E(A.ChannelOverwriteDelete, {
    targetId: ch.id,
    extra: { id: roleId, type: 0 },
    changes: [{ key: 'allow', old: String(P.BanMembers) }, { key: 'deny', old: '0' }],
  });
  const [c2] = classify(del, guild, cfg);
  assert.equal(c2.meta.overwrite.new, null);
  assert.deepEqual(c2.meta.overwrite.old, { allow: String(P.BanMembers), deny: '0' });

  // UPDATE: chi 1 truong (deny) doi - truong con lai (allow) phai lay tu overwrite HIEN TAI tren kenh
  // (vi Discord khong liet ke truong khong doi trong "changes").
  ch.permissionOverwrites.cache.set(roleId, { id: roleId, type: 0, allow: { bitfield: P.BanMembers }, deny: { bitfield: P.KickMembers } });
  const upd = E(A.ChannelOverwriteUpdate, {
    targetId: ch.id,
    extra: { id: roleId, type: 0 },
    changes: [{ key: 'deny', old: '0', new: String(P.KickMembers) }],
  });
  const [c3] = classify(upd, guild, cfg);
  assert.deepEqual(c3.meta.overwrite.old, { allow: String(P.BanMembers), deny: '0' });
  assert.deepEqual(c3.meta.overwrite.new, { allow: String(P.BanMembers), deny: String(P.KickMembers) });

  // extra.id vang mat (phien ban API khong nhu mong doi) -> khong loi, chi khong ghi lai duoc de hoan tac.
  const noExtra = E(A.ChannelOverwriteCreate, { targetId: ch.id, extra: {}, changes: [] });
  assert.equal(classify(noExtra, guild, cfg)[0].meta.overwrite, null);
});
