'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { makeEnv, addRole, addMember, sleep, callsOf, P } = require('./helpers');
const core = require('../src/moderation/core');
const storage = require('../src/antinuke/storage');

const modFile = (guild) => path.join(__dirname, '..', 'data', 'mod', `${guild.id}.json`);
const mod = (id) => ({ id, tag: `mod${id}` });
const victim = (id) => ({ id, tag: `v${id}` });

test('parseDuration: dinh dang hop le / khong hop le', () => {
  assert.equal(core.parseDuration('2h30m'), 9_000_000);
  assert.equal(core.parseDuration('1d'), 86_400_000);
  assert.equal(core.parseDuration('10'), null, 'bat buoc co don vi');
  assert.equal(core.parseDuration('abc'), null);
  assert.equal(core.parseDuration('0m'), null);
});

test('file du lieu moderation bi hong: giu lai de cuu, khong bi ghi de mat het case', () => {
  const { guild } = makeEnv();
  fs.writeFileSync(modFile(guild), '{ hong');
  const store = core.load(guild.id);
  assert.equal(store.data.nextCaseId, 1);
  assert.equal(fs.readdirSync(path.dirname(modFile(guild))).filter((f) => f.startsWith(`${guild.id}.json.corrupt-`)).length, 1);
});

test('luu tru: slowmodeLast (trang thai tam) khong bi ghi ra dia; ghi dong bo la nguyen tu', () => {
  const { guild } = makeEnv();
  const store = core.load(guild.id);
  store.data.slowmodeLast['c1'] = { u: Date.now() };
  store.data.nextCaseId = 42;
  core.flushAllSync();
  const onDisk = JSON.parse(fs.readFileSync(modFile(guild), 'utf8'));
  assert.equal(onDisk.data.nextCaseId, 42);
  assert.equal('slowmodeLast' in onDisk.data, false);
  assert.equal(fs.existsSync(`${modFile(guild)}.${process.pid}.tmp`), false, 'khong de lai file tam');
});

test('TIMER: loi tam thoi khong lam MAT timer (ban cu: tempban tro thanh vinh vien); loi vinh vien thi bo', async () => {
  const env = makeEnv();
  const { guild, client } = env;
  const store = core.load(guild.id);
  let fail = true;
  guild.members.unban = async (id) => { if (fail) throw new Error('fetch failed'); guild.calls.push(['unban', id]); };
  store.data.timers.push({ type: 'unban', userId: '5001', userTag: 'x', at: Date.now() - 1 });
  await core.processTimers(client);
  assert.equal(store.data.timers.length, 1, 'timer duoc xep lai');
  assert.equal(store.data.timers[0].attempts, 1);
  assert.ok(store.data.timers[0].at > Date.now(), 'co backoff');

  fail = false;
  store.data.timers[0].at = Date.now() - 1;
  await core.processTimers(client);
  assert.equal(store.data.timers.length, 0);
  assert.deepEqual(callsOf(guild, 'unban').map((c) => c[1]), ['5001']);

  // Unknown Ban (10026): khong con gi de go -> bo han, khong lap vo tan
  guild.members.unban = async () => { const e = new Error('Unknown Ban'); e.code = 10026; throw e; };
  store.data.timers.push({ type: 'unban', userId: '5002', userTag: 'y', at: Date.now() - 1 });
  await core.processTimers(client);
  assert.equal(store.data.timers.length, 0);
});

test('TICH HOP: mod ban hang loat QUA BOT van bi Anti-Nuke chan (ban cu: markTrusted cho phep bo qua)', async () => {
  const env = makeEnv();
  const { guild } = env;
  const bad = addMember(guild, { roles: [addRole(guild, { name: 'ModBan', perms: P.BanMembers | P.Administrator, position: 5 }).id] });
  for (let n = 0; n < 3; n++) await core.banUser(guild, mod(bad.id), victim(String(7000 + n)), 'spam');
  await sleep(30);
  assert.ok(callsOf(guild, 'ban').some((c) => c[1] === bad.id), 'mod vuot nguong bi xu ly');
  assert.deepEqual(callsOf(guild, 'unban').map((c) => c[1]).sort(), ['7000', '7001', '7002'], 'nan nhan duoc unban');
});

test('TICH HOP: hanh dong cua chinh bot (automod/timer) khong bi tinh vao Anti-Nuke', async () => {
  const env = makeEnv();
  const { guild, botId } = env;
  for (let n = 0; n < 8; n++) await core.banUser(guild, mod(botId), victim(String(8000 + n)), 'automod');
  await sleep(30);
  assert.equal(callsOf(guild, 'unban').length, 0);
  assert.equal(callsOf(guild, 'ban').filter((c) => c[1] === botId).length, 0);
});

test('TICH HOP: mod duoc whitelist ban thoai mai', async () => {
  const env = makeEnv();
  const { guild } = env;
  const trusted = addMember(guild);
  storage.getGuildConfig(guild.id).whitelistedUsers.push(trusted.id);
  for (let n = 0; n < 6; n++) await core.banUser(guild, mod(trusted.id), victim(String(9000 + n)), 'ok');
  await sleep(30);
  assert.equal(callsOf(guild, 'unban').length, 0);
});

test('mute dong thoi khi chua co role Muted: chi tao 1 role (ban cu tao nhieu role trung)', async () => {
  const { guild } = makeEnv();
  guild.latency = 5;
  const members = [addMember(guild), addMember(guild), addMember(guild)];
  await Promise.all(members.map((m) => core.muteMember(guild, mod('1'), m, 'test')));
  assert.equal(callsOf(guild, 'roles.create').length, 1);
  assert.equal([...guild.roles.cache.values()].filter((r) => r.name === 'Muted').length, 1);
});

test('timeout: 28 ngay bi cat xuong gioi han an toan cua Discord (khong bi tu choi vi lech dong ho)', async () => {
  const { guild } = makeEnv();
  const m = addMember(guild);
  await core.timeoutMember(guild, mod('1'), m, 28 * 86_400_000, 'x');
  const ms = callsOf(guild, 'member.timeout')[0][2];
  assert.ok(ms < 28 * 86_400_000 && ms > 27 * 86_400_000);
});
