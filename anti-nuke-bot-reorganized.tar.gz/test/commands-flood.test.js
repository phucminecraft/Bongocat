'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
require('./_setup');
const { makeEnv, addMember, makeMessage, callsOf, P } = require('./helpers');
const core = require('../src/moderation/core');
const textCommands = require('../src/textCommands');
const { commands } = require('../src/moderation/commands');

const mkMod = (guild) => addMember(guild, { perms: P.ManageGuild });

test('/automod: lenh "spam" van con toi da 25 lua chon (gioi han that cua Discord) - guard chong hoi quy khi them kind moi', () => {
  const automodCmd = commands.find((c) => c.data.toJSON().name === 'automod');
  const spamGroup = automodCmd.data.toJSON().options.find((o) => o.name === 'spam');
  const setSub = spamGroup.options.find((o) => o.name === 'set');
  const kindOpt = setSub.options.find((o) => o.name === 'kind');
  assert.ok(kindOpt.choices.length <= 25, 'Discord gioi han toi da 25 choices/option');
  assert.equal(kindOpt.choices.length, 17); // cap nhat so nay neu co them/bot loai spam
});

test('!automod characters toggle + set: cau hinh duoc luu dung', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod characters toggle enabled:true' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod characters set min_length:15 min_run:12 min_ratio_percent:80' }));
  const cfg = core.load(guild.id).config.automod.characters;
  assert.equal(cfg.enabled, true);
  assert.equal(cfg.minLength, 15);
  assert.equal(cfg.minRun, 12);
  assert.equal(cfg.minRatio, 0.8);
});

test('!automod threads toggle + set: cau hinh duoc luu dung', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod threads toggle enabled:true' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod threads set count:5 seconds:60' }));
  const cfg = core.load(guild.id).config.automod.threads;
  assert.equal(cfg.enabled, true);
  assert.deepEqual(cfg.limit, { count: 5, seconds: 60 });
});

test('!automod reactions toggle + set: cau hinh duoc luu dung', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod reactions toggle enabled:true' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod reactions set count:20 seconds:15' }));
  const cfg = core.load(guild.id).config.automod.reactions;
  assert.equal(cfg.enabled, true);
  assert.deepEqual(cfg.limit, { count: 20, seconds: 15 });
});

test('!automod spam set kind:images count:... seconds:...: 1 trong cac loai spam moi hoat dong qua prefix command', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod spam set kind:images count:4 seconds:12' });
  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.deepEqual(core.load(guild.id).config.automod.spam.limits.images, { count: 4, seconds: 12 });
});

test('/automod punish rule:threads va /automod delete rule:reactions: 2 rule moi dung chung co che generic voi words/invites/spam', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod punish rule:threads type:timeout minutes:15' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod delete rule:reactions enabled:false' }));
  const cfg = core.load(guild.id).config.automod;
  assert.deepEqual(cfg.threads.punish, { type: 'timeout', minutes: 15 });
  assert.equal(cfg.reactions.delete, false);
});

test('/automod spam builtin enabled:true: tao AutoMod rule Spam Content that su qua guild.autoModerationRules', async () => {
  const { guild, client } = makeEnv();
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod spam builtin enabled:true' });
  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(core.load(guild.id).config.automod.spam.builtin, true);
  assert.equal(callsOf(guild, 'automod.rule.create').length, 1);
});

test('/automod spam builtin enabled:true: bot thieu quyen -> khong luu la BAT, tra loi loi ro rang', async () => {
  const { guild, client } = makeEnv();
  guild.autoModerationRules.create = async () => { throw new Error('Missing Permissions'); };
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod spam builtin enabled:true' });
  await textCommands.handleMessage(client, msg);
  assert.equal(core.load(guild.id).config.automod.spam.builtin, false);
  assert.equal(msg.replies.length, 1);
  assert.match(msg.replies[0].embeds[0].data.description, /Missing Permissions|quyen/i);
});

test('/automod status: hien thi ca cac rule moi (characters/threads/reactions) khong loi', async () => {
  const { guild } = makeEnv();
  const mod = mkMod(guild);
  const statusCmd = commands.find((c) => c.data.toJSON().name === 'automod');
  let replied = null;
  const fakeI = {
    guild, member: mod, user: mod.user, memberPermissions: mod.permissions,
    options: { getSubcommandGroup: () => null, getSubcommand: () => 'status' },
    reply: async (p) => { replied = p; return p; },
  };
  await statusCmd.execute(fakeI);
  assert.ok(replied);
  const fieldNames = replied.embeds[0].data.fields.map((f) => f.name).join(' | ');
  assert.match(fieldNames, /Ky tu lap/);
  assert.match(fieldNames, /Thread Spam/);
  assert.match(fieldNames, /Reaction Spam/);
});
