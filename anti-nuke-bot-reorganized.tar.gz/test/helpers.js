'use strict';
// Doi tuong gia (guild / member / role / channel) toi thieu, ghi lai moi loi goi API vao guild.calls de test kiem tra.
require('./_setup');
const { Collection, PermissionsBitField, PermissionFlagsBits: P } = require('discord.js');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let seq = 0;
let guildSeq = 0;
const nextId = () => String(600000000000000000n + BigInt(++seq));
const toIds = (x) => (x instanceof Map ? [...x.keys()] : (Array.isArray(x) ? x : [x]).map((v) => (typeof v === 'string' ? v : v.id)));
const ALL = Object.values(P).reduce((a, b) => a | b, 0n);
// { PermName: true|false|null } (dang PermissionOverwriteManager#create/edit that dung) -> { allow, deny } bigint.
function optionsToBits(options) {
  let allow = 0n;
  let deny = 0n;
  for (const [name, val] of Object.entries(options || {})) {
    const bit = P[name];
    if (typeof bit !== 'bigint') continue;
    if (val === true) allow |= bit;
    else if (val === false) deny |= bit;
  }
  return { allow, deny };
}

function addRole(guild, { id = nextId(), name, perms = 0n, position = 1, managed = false, editable = true, color = 0 }) {
  const role = {
    id, name, position, managed, color, hoist: false, mentionable: false, editable, guild,
    permissions: new PermissionsBitField(perms),
    get members() { return guild.members.cache.filter((m) => m.roles.cache.has(id)); },
    delete: async () => { guild.calls.push(['role.delete', id]); guild.roles.cache.delete(id); },
    edit: async (patch) => {
      guild.calls.push(['role.edit', id, patch]);
      if (patch.permissions !== undefined) role.permissions = new PermissionsBitField(patch.permissions);
      if (patch.name) role.name = patch.name;
    },
  };
  guild.roles.cache.set(id, role);
  return role;
}

function addMember(guild, { id = nextId(), roles = [], bot = false, kickFails = false, kickable = true, perms = 0n, voiceChannelId = null } = {}) {
  const cache = new Collection();
  cache.set(guild.id, guild.roles.cache.get(guild.id));
  for (const r of roles) cache.set(r, guild.roles.cache.get(r));
  const voiceState = { channelId: voiceChannelId };
  const member = {
    id, guild, user: { id, bot, tag: `user${id}` }, kickable,
    permissions: new PermissionsBitField(perms), // that discord.js: GuildMember.permissions khong bao gio undefined
    // Mo phong GuildMember#permissionsIn(channel) that: Administrator bo qua moi overwrite; nguoc lai
    // ap theo dung thu tu Discord dung: overwrite @everyone -> hop cac overwrite theo role -> overwrite
    // rieng cho member (deny truoc, allow sau o moi tang, tang sau de len tang truoc).
    permissionsIn(channel) {
      if (member.permissions.has(P.Administrator)) return member.permissions;
      const ows = channel?.permissionOverwrites?.cache;
      if (!ows || !ows.size) return member.permissions;
      let bits = member.permissions.bitfield;
      const everyone = ows.get(guild.id);
      if (everyone) bits = (bits & ~everyone.deny.bitfield) | everyone.allow.bitfield;
      let roleAllow = 0n;
      let roleDeny = 0n;
      for (const rid of cache.keys()) {
        if (rid === guild.id) continue;
        const ow = ows.get(rid);
        if (ow) { roleAllow |= ow.allow.bitfield; roleDeny |= ow.deny.bitfield; }
      }
      bits = (bits & ~roleDeny) | roleAllow;
      const own = ows.get(id);
      if (own) bits = (bits & ~own.deny.bitfield) | own.allow.bitfield;
      return new PermissionsBitField(bits);
    },
    roles: {
      cache,
      get highest() { let best = null; for (const r of cache.values()) if (!best || r.position > best.position) best = r; return best; },
      remove: async (x, reason) => { const ids = toIds(x); guild.calls.push(['member.roles.remove', id, ids]); for (const i of ids) cache.delete(i); },
      add: async (x) => { const ids = toIds(x); guild.calls.push(['member.roles.add', id, ids]); for (const i of ids) cache.set(i, guild.roles.cache.get(i)); },
    },
    // trang thai thoai toi thieu, du de test Voice Protection (join/leave/doi kenh + disconnectMember).
    voice: {
      get channelId() { return voiceState.channelId; },
      get channel() { return voiceState.channelId ? (guild.channels.cache.get(voiceState.channelId) ?? null) : null; },
      disconnect: async (reason) => { guild.calls.push(['member.voice.disconnect', id, reason]); voiceState.channelId = null; },
    },
    kick: async () => { if (kickFails) throw new Error('Missing Permissions'); guild.calls.push(['member.kick', id]); guild.members.cache.delete(id); },
    timeout: async (ms) => { guild.calls.push(['member.timeout', id, ms]); },
  };
  guild.members.cache.set(id, member);
  guild.client.users.cache.set(id, member.user);
  return member;
}

// Doi tuong VoiceState gia toi thieu (giong shape discord.js: channelId/channel/member/guild + cac co selfMute/selfDeaf/selfVideo/streaming),
// dung de goi truc tiep voiceProtection.handleVoiceStateUpdate(client, oldState, newState) trong test.
function makeVoiceState(member, channel, overrides = {}) {
  return {
    member, guild: member.guild, channelId: channel?.id ?? null, channel: channel ?? null,
    selfMute: false, selfDeaf: false, selfVideo: false, streaming: false,
    ...overrides,
  };
}

function addChannel(guild, { id = nextId(), name, type = 0, parentId = null, position = 0, overwrites = [], topic, rateLimitPerUser = 0 } = {}) {
  const ch = {
    id, name, type, parentId, rawPosition: position, topic, guild, rateLimitPerUser,
    // create/edit/delete: mo phong hop dong CRUD that cua Discord (giong PermissionOverwriteManager)
    // -> create() TU CHOI neu overwrite do da ton tai, edit() TU CHOI neu CHUA ton tai - de bai test bat
    // duoc dung nhanh fallback (thu create truoc, khong duoc thi edit) trong revertChannelOverwrites().
    permissionOverwrites: {
      cache: new Collection(overwrites.map((o) => [o.id, { id: o.id, type: o.type ?? 0, allow: { bitfield: BigInt(o.allow ?? 0) }, deny: { bitfield: BigInt(o.deny ?? 0) } }])),
      create: async (targetId, options, extra) => {
        if (ch.permissionOverwrites.cache.has(targetId)) throw new Error('overwrite already exists');
        const { allow, deny } = optionsToBits(options);
        ch.permissionOverwrites.cache.set(targetId, { id: targetId, type: extra?.type ?? 0, allow: { bitfield: allow }, deny: { bitfield: deny } });
        guild.calls.push(['channel.permissionOverwrites.create', id, targetId, options, extra?.reason]);
      },
      edit: async (targetId, options, extra) => {
        if (!ch.permissionOverwrites.cache.has(targetId)) throw new Error('overwrite does not exist');
        const { allow, deny } = optionsToBits(options);
        ch.permissionOverwrites.cache.set(targetId, { id: targetId, type: extra?.type ?? ch.permissionOverwrites.cache.get(targetId).type, allow: { bitfield: allow }, deny: { bitfield: deny } });
        guild.calls.push(['channel.permissionOverwrites.edit', id, targetId, options, extra?.reason]);
      },
      delete: async (targetId, reason) => {
        ch.permissionOverwrites.cache.delete(targetId);
        guild.calls.push(['channel.permissionOverwrites.delete', id, targetId, reason]);
      },
    },
    get parent() { return ch.parentId ? guild.channels.cache.get(ch.parentId) ?? null : null; },
    isThread: () => false,
    isTextBased: () => [0, 5].includes(type), // GuildText / GuildAnnouncement - du cho core.sendLog kiem tra kenh log
    send: async (payload) => {
      guild.calls.push(['channel.send', id, payload]);
      const sentId = nextId();
      return { id: sentId, delete: async () => { guild.calls.push(['channel.send.delete', id, sentId]); } };
    },
    setRateLimitPerUser: async (n, reason) => { guild.calls.push(['channel.setRateLimitPerUser', id, n, reason]); ch.rateLimitPerUser = n; },
    delete: async () => { guild.calls.push(['channel.delete', id]); guild.channels.cache.delete(id); },
    setParent: async (pid) => { guild.calls.push(['channel.setParent', id, pid]); ch.parentId = pid; },
    edit: async (patch) => { guild.calls.push(['channel.edit', id, patch]); },
    // Du de deleteTracked() trong automod.js xoa nhieu tin cung kenh (rule spam vuot nguong voi > 1 item).
    messages: { delete: async (msgId) => { guild.calls.push(['channel.messages.delete', id, msgId]); } },
    bulkDelete: async (ids, filterOld) => { guild.calls.push(['channel.bulkDelete', id, [...ids]]); },
  };
  guild.channels.cache.set(id, ch);
  return ch;
}

// Thread toi thieu (goc guild) de test Thread Spam trong floodProtection.js: chi can id/ownerId/parentId
// (isExempt chi doc .id/.parentId) + delete() de floodProtection "don" thread khi vuot nguong.
function addThread(guild, { id = nextId(), ownerId, parentId = null, name = 'thread' } = {}) {
  const thread = {
    id, guild, ownerId, parentId, name,
    delete: async (reason) => { guild.calls.push(['thread.delete', id, reason]); },
  };
  return thread;
}

// MessageReaction toi thieu de test Reaction Spam: chi can .message + .users.remove(userId).
function makeReaction(message, emojiKey = '👍') {
  return {
    message, partial: false, emoji: { name: emojiKey },
    users: { remove: async (userId) => { message.guild.calls.push(['reaction.users.remove', message.id, emojiKey, userId]); } },
  };
}

function makeEnv({ botPosition = 50 } = {}) {
  const botId = '800000000000000001';
  const ownerId = '900000000000000001';
  const calls = [];
  const created = { channels: [], roles: [] };
  const client = {
    user: { id: botId }, guilds: { cache: new Collection() }, channels: { fetch: async () => null }, fetchWebhook: async () => null,
    users: { cache: new Collection(), fetch: async (id) => { const u = client.users.cache.get(id); if (!u) throw new Error('Unknown User'); return u; } },
  };
  const guild = {
    id: `7777${String(++guildSeq).padStart(14, '0')}`, name: 'Test', ownerId, memberCount: 0, available: true, maximumBitrate: 96000,
    calls, created, client, fetchOwner: async () => ({ send: async (m) => { calls.push(['owner.dm']); } }),
    roles: { cache: new Collection(), create: async (o) => { if (guild.latency) await sleep(guild.latency); created.roles.push(o); calls.push(['roles.create', o.name]); return addRole(guild, { name: o.name, perms: o.permissions, color: o.color }); }, setPositions: async (a) => { calls.push(['roles.setPositions', a.length]); } },
    channels: {
      cache: new Collection(),
      create: async (o) => {
        if (guild.latency) await sleep(guild.latency); // gia lap do tre mang that de cac luot chay chong nhau bo lo
        created.channels.push(o); calls.push(['channels.create', o.name]);
        return addChannel(guild, { name: o.name, type: o.type, parentId: o.parent ?? null, position: o.position ?? 0, topic: o.topic, overwrites: (o.permissionOverwrites || []).map((w) => ({ id: w.id, type: w.type, allow: w.allow, deny: w.deny })) });
      },
    },
    members: {
      cache: new Collection(), me: null,
      fetch: async (x) => { if (typeof x === 'string') { const m = guild.members.cache.get(x); if (!m) throw new Error('Unknown Member'); return m; } return guild.members.cache; },
      ban: async (id) => { calls.push(['ban', id]); guild.members.cache.delete(id); },
      unban: async (id) => { calls.push(['unban', id]); },
      kick: async (id) => { calls.push(['kick', id]); guild.members.cache.delete(id); },
    },
    invites: { delete: async (c) => { calls.push(['invite.delete', c]); } },
    emojis: { delete: async (i) => { calls.push(['emoji.delete', i]); } },
    stickers: { delete: async (i) => { calls.push(['sticker.delete', i]); } },
    // Du de test setBuiltinSpamRule() (item 29: Spam Content built-in cua Discord AutoMod).
    autoModerationRules: {
      _store: new Collection(),
      fetch: async () => guild.autoModerationRules._store,
      create: async (o) => {
        calls.push(['automod.rule.create', o.name, o.triggerType]);
        const id = nextId();
        const rule = {
          id, ...o, creatorId: guild.client.user.id,
          delete: async (reason) => { calls.push(['automod.rule.delete', id, reason]); guild.autoModerationRules._store.delete(id); },
          edit: async (patch) => { calls.push(['automod.rule.edit', id, patch.triggerMetadata]); Object.assign(rule, patch); return rule; },
        };
        guild.autoModerationRules._store.set(id, rule);
        return rule;
      },
    },
  };
  client.guilds.cache.set(guild.id, guild);
  addRole(guild, { id: guild.id, name: '@everyone', position: 0, editable: false });
  const botRole = addRole(guild, { name: 'BOT', perms: ALL, position: botPosition });
  const me = addMember(guild, { id: botId, roles: [botRole.id], bot: true });
  me.permissions = new PermissionsBitField(ALL);
  guild.members.me = me;
  addMember(guild, { id: ownerId });
  return { guild, client, botId, ownerId, botRole, me, calls };
}

const callsOf = (guild, name) => guild.calls.filter((c) => c[0] === name);

// Tin nhan gia toi thieu (goc guild) de test textCommands.js (prefix/tag command) va automod tren tin nhan.
// message.reply(...) tra ve 1 doi tuong co .edit(...) rieng (khong dung guild.calls chung, vi channel.send/reply
// khac nhau ve muc dich) va cung ghi lai vao guild.calls duoi ten 'message.reply' de test kiem tra de dang.
// mentionUsers/mentionRoles/everyone/attachments/stickers/embeds/poll: du de test cac loai spam moi trong
// automod.js (mentions/roleMentions/everyoneMentions/images/videos/gifs/stickers/embeds/polls...).
function makeMessage(guild, member, { content = '', channel, mentionUsers = [], mentionRoles = [], everyone = false, attachments = [], stickers = [], embeds = [], poll = null } = {}) {
  const ch = channel ?? addChannel(guild, { name: 'general', type: 0 });
  const replies = [];
  const toCollection = (arr) => new Collection(arr.map((x) => [typeof x === 'string' ? x : x.id, typeof x === 'string' ? { id: x } : x]));
  const message = {
    id: nextId(), guild, guildId: guild.id, member, author: member.user, content, channel: ch, channelId: ch.id, client: guild.client, partial: false,
    mentions: { users: toCollection(mentionUsers), roles: toCollection(mentionRoles), everyone },
    attachments: new Collection(attachments.map((a, idx) => [String(idx), { id: String(idx), name: a.name ?? '', contentType: a.contentType ?? null, ...a }])),
    stickers: new Collection(stickers.map((s, idx) => [String(idx), typeof s === 'string' ? { id: String(idx), name: s } : s])),
    embeds,
    poll,
    delete: async () => { guild.calls.push(['message.delete', message.id]); },
    reply: async (payload) => {
      const p = typeof payload === 'string' ? { content: payload } : payload;
      const sent = { ...p };
      sent.edit = async (patch) => {
        Object.assign(sent, typeof patch === 'string' ? { content: patch } : patch);
        guild.calls.push(['message.reply.edit', member.id, patch]);
        return sent;
      };
      replies.push(sent);
      guild.calls.push(['message.reply', member.id, p]);
      return sent;
    },
  };
  message.replies = replies;
  return message;
}

module.exports = { makeEnv, addRole, addMember, addChannel, addThread, makeReaction, nextId, sleep, callsOf, ALL, P, makeVoiceState, makeMessage };
