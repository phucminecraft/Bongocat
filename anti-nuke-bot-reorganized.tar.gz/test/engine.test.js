'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { makeEnv, addRole, addMember, addChannel, sleep, callsOf, P } = require('./helpers');
const storage = require('../src/antinuke/storage');
const engine = require('../src/antinuke/engine');
const { contain } = require('../src/antinuke/punish');

function setup(punishmentOf = {}) {
  const env = makeEnv({ botPosition: 50 });
  const { guild } = env;
  const adminRole = addRole(guild, { name: 'Admin', perms: P.Administrator, position: 10 });
  const attacker = addMember(guild, { roles: [adminRole.id] });
  const cfg = storage.getGuildConfig(guild.id);
  for (const [k, v] of Object.entries(punishmentOf)) Object.assign(cfg.modules[k], v);
  const act = (mod, meta, who = attacker.id) => engine.handleAction(env.client, guild, who, mod, meta);
  return { ...env, adminRole, attacker, cfg, act };
}

test('massBan: chua toi nguong thi khong lam gi; toi nguong thi ban ke tan cong va UNBAN nan nhan', async () => {
  const { guild, attacker, act } = setup();
  await act('massBan', { userId: '1001' });
  await act('massBan', { userId: '1002' });
  assert.equal(callsOf(guild, 'ban').length, 0);
  await act('massBan', { userId: '1003' });
  assert.deepEqual(callsOf(guild, 'ban').map((c) => c[1]), [attacker.id]);
  assert.deepEqual(callsOf(guild, 'unban').map((c) => c[1]).sort(), ['1001', '1002', '1003']);
});

test('dong thoi: 10 su kien den cung luc chi xu phat DUNG 1 LAN, cac nan nhan con lai van duoc unban', async () => {
  const { guild, attacker, act } = setup();
  await Promise.all(Array.from({ length: 10 }, (_, i) => act('massBan', { userId: String(2000 + i) })));
  assert.equal(callsOf(guild, 'ban').filter((c) => c[1] === attacker.id).length, 1, 'khong ban 2 lan (ban cu: xu phat chong nhau)');
  assert.equal(new Set(callsOf(guild, 'unban').map((c) => c[1])).size, 10);
});

test('sau khi bi xu phat, hanh dong den MUON (in-flight) bi hoan tac ngay khong can cho nguong', async () => {
  const { guild, act } = setup();
  for (let i = 0; i < 3; i++) await act('massBan', { userId: String(3000 + i) });
  guild.calls.length = 0;
  await act('massBan', { userId: '3999' }); // 1 hanh dong le, xa nguong
  assert.deepEqual(callsOf(guild, 'unban').map((c) => c[1]), ['3999']);
});

test('nguoi trong whitelist / chu server / bot chinh no khong bi dem', async () => {
  const { guild, attacker, cfg, act, ownerId, botId } = setup();
  cfg.whitelistedUsers.push(attacker.id);
  for (let i = 0; i < 10; i++) await act('massBan', { userId: String(4000 + i) });
  for (let i = 0; i < 10; i++) await act('massBan', { userId: String(4100 + i) }, ownerId);
  for (let i = 0; i < 10; i++) await act('massBan', { userId: String(4200 + i) }, botId);
  assert.equal(guild.calls.filter((c) => c[0] === 'ban' || c[0] === 'unban').length, 0);
});

test('module bi tat thi bo qua', async () => {
  const { guild, act } = setup({ massBan: { enabled: false } });
  for (let i = 0; i < 6; i++) await act('massBan', { userId: String(5000 + i) });
  assert.equal(callsOf(guild, 'ban').length, 0);
});

test('strip: go role nguy hiem, GHI NHO de unstrip, va hoan tac viec cap role hang loat', async () => {
  const { guild, attacker, adminRole, act } = setup();
  const victim = addMember(guild);
  const role = addRole(guild, { name: 'Vui' });
  for (let i = 0; i < 5; i++) await act('massRoleAdd', { memberId: victim.id, roleIds: [role.id] });
  const rm = callsOf(guild, 'member.roles.remove');
  assert.ok(rm.some((c) => c[1] === attacker.id && c[2].includes(adminRole.id)), 'go role Admin cua ke tan cong');
  assert.ok(rm.some((c) => c[1] === victim.id && c[2].includes(role.id)), 'thu hoi role da cap');
  assert.equal(callsOf(guild, 'member.kick').length, 0, 'strip thanh cong thi khong kick');
  assert.deepEqual(storage.getGuildConfig(guild.id).strippedRoles[attacker.id].roleIds, [adminRole.id]);
});

test('contain: strip khong go duoc (role cao hon bot) -> LEO THANG kick; kick cung that bai -> bao trung thuc "khong vo hieu hoa"', async () => {
  const env = makeEnv({ botPosition: 5 });
  const { guild } = env;
  const high = addRole(guild, { name: 'Cao', perms: P.Administrator, position: 40, editable: false });
  const a1 = addMember(guild, { roles: [high.id] });
  const r1 = await contain({ guild, member: a1, executorId: a1.id, punishment: 'strip', reason: 'x' });
  assert.equal(r1.neutralized, true);
  assert.ok(r1.actions.includes('kick (leo thang)'));

  const a2 = addMember(guild, { roles: [high.id], kickFails: true });
  const r2 = await contain({ guild, member: a2, executorId: a2.id, punishment: 'strip', reason: 'x' });
  assert.equal(r2.neutralized, false, 'ban cu van bao thanh cong du khong go duoc role nao');
  assert.ok(r2.errors.length >= 1);
});

test('contain: strip khong co role nguy hiem de go -> khong tu nhan la "da vo hieu hoa"', async () => {
  const { guild } = makeEnv();
  const m = addMember(guild, { roles: [addRole(guild, { name: 'Thuong', perms: P.SendMessages }).id] });
  const r = await contain({ guild, member: m, executorId: m.id, punishment: 'strip', reason: 'x' });
  assert.equal(r.neutralized, false);
  assert.equal(callsOf(guild, 'member.kick').length, 0, 'khong tu y kick nguoi thuong');
});

test('contain: bot ke tan cong (role managed khong go duoc) -> kick thay vi strip', async () => {
  const { guild } = makeEnv();
  const managed = addRole(guild, { name: 'BadBot', perms: P.Administrator, position: 3, managed: true, editable: false });
  const bot = addMember(guild, { roles: [managed.id], bot: true });
  const r = await contain({ guild, member: bot, executorId: bot.id, punishment: 'strip', reason: 'x' });
  assert.equal(r.neutralized, true);
  assert.equal(callsOf(guild, 'member.kick').length, 1);
});

test('contain: ban theo ID dung ca khi nguoi thuc hien da roi server; strip/kick khi khong con la thanh vien thi khong loi', async () => {
  const { guild } = makeEnv();
  const r = await contain({ guild, member: null, executorId: '424242', punishment: 'ban', reason: 'x' });
  assert.deepEqual(callsOf(guild, 'ban').map((c) => c[1]), ['424242']);
  assert.equal(r.neutralized, true);
  const r2 = await contain({ guild, member: null, executorId: '424243', punishment: 'strip', reason: 'x' });
  assert.equal(r2.neutralized, true);
});

test('nang quyen: cap role Admin cho tai khoan phu bi thu hoi NGAY (ca khi nguong cau hinh > 1) va nguoi cap bi xu ly khi toi nguong', async () => {
  const { guild, attacker, adminRole, act } = setup({ privilegeEscalation: { limit: 3 } });
  const alt = addMember(guild);
  await act('privilegeEscalation', { type: 'grant', memberId: alt.id, roleIds: [adminRole.id] });
  assert.ok(callsOf(guild, 'member.roles.remove').some((c) => c[1] === alt.id && c[2].includes(adminRole.id)), 'thu hoi ngay lan dau');
  assert.equal(callsOf(guild, 'member.roles.remove').filter((c) => c[1] === attacker.id).length, 0, 'chua toi nguong: chua phat');
  for (let i = 0; i < 2; i++) await act('privilegeEscalation', { type: 'grant', memberId: addMember(guild).id, roleIds: [adminRole.id] });
  assert.ok(callsOf(guild, 'member.roles.remove').some((c) => c[1] === attacker.id && c[2].includes(adminRole.id)), 'toi nguong 3 -> go role cua nguoi cap');
});

test('nang quyen: them quyen nguy hiem vao role duoc hoan tac ve quyen cu', async () => {
  const { guild, act } = setup();
  const r = addRole(guild, { name: 'Vui', perms: P.SendMessages, editable: true });
  r.permissions = new (require('discord.js').PermissionsBitField)(P.SendMessages | P.Administrator); // sau khi bi sua
  await act('privilegeEscalation', { type: 'perm', roleId: r.id, changes: [{ key: 'permissions', old: String(P.SendMessages) }] });
  const edit = callsOf(guild, 'role.edit').find((c) => c[1] === r.id);
  assert.equal(edit[2].permissions, P.SendMessages);
});

test('tao hang loat kenh: kenh spam bi xoa; hanh dong tao muon sau khi bi phat cung bi xoa ngay', async () => {
  const { guild, act } = setup();
  const chans = [1, 2, 3, 4].map((i) => addChannel(guild, { name: `spam${i}` }));
  for (const c of chans.slice(0, 3)) await act('massChannelCreate', { channelId: c.id });
  assert.deepEqual(callsOf(guild, 'channel.delete').map((c) => c[1]).sort(), chans.slice(0, 3).map((c) => c.id).sort());
  await act('massChannelCreate', { channelId: chans[3].id });
  assert.ok(callsOf(guild, 'channel.delete').some((c) => c[1] === chans[3].id));
});

test('sua role hang loat: khoi phuc gia tri GOC (old dau tien) cua tung role', async () => {
  const { guild, act } = setup({ massRoleUpdate: { limit: 3 } });
  const r = addRole(guild, { name: 'B2' });
  await act('massRoleUpdate', { roleId: r.id, changes: [{ key: 'name', old: 'goc', new: 'B1' }] });
  await act('massRoleUpdate', { roleId: r.id, changes: [{ key: 'name', old: 'B1', new: 'B2' }] });
  await act('massRoleUpdate', { roleId: r.id, changes: [{ key: 'name', old: 'B2', new: 'B3' }] });
  const edits = callsOf(guild, 'role.edit').filter((c) => c[1] === r.id);
  assert.equal(edits.length, 1);
  assert.equal(edits[0][2].name, 'goc');
});

test('sua permission overwrite hang loat (tao moi): overwrite ke tan cong tu TAO bi XOA khi hoan tac', async () => {
  const { guild, act } = setup({ massPermissionChange: { limit: 4 } });
  const role = addRole(guild, { name: 'Nan nhan' });
  const chans = [1, 2, 3, 4].map((i) => addChannel(guild, { name: `ow${i}` }));
  for (const c of chans) {
    // Mo phong dung hanh dong cua ke tan cong: overwrite MOI da duoc "tao" (dat thang vao cache, giong
    // nhu Discord da ap dung no) TRUOC khi audit-log-entry (meta) toi antinuke - neu khong thi kenh
    // khong he co gi de hoan tac va assertion ben duoi se DUNG BAT KE mitigate co chay hay khong.
    c.permissionOverwrites.cache.set(role.id, { id: role.id, type: 0, allow: { bitfield: P.Administrator }, deny: { bitfield: 0n } });
    await act('massPermissionChange', {
      channelId: c.id,
      overwrite: { targetId: role.id, targetType: 0, roleName: role.name, old: null, new: { allow: String(P.Administrator), deny: '0' } },
    });
  }
  for (const c of chans) assert.ok(!c.permissionOverwrites.cache.has(role.id), `overwrite tren kenh ${c.name} phai bi xoa`);
});

test('sua permission overwrite hang loat (xoa): overwrite bi XOA thi duoc TAO LAI dung gia tri cu', async () => {
  const { guild, act } = setup({ massPermissionChange: { limit: 4 } });
  const role = addRole(guild, { name: 'Nan nhan' });
  const chans = [1, 2, 3, 4].map((i) => addChannel(guild, { name: `ow${i}` })); // hien tai KHONG co overwrite (da bi xoa)
  for (const c of chans) {
    await act('massPermissionChange', {
      channelId: c.id,
      overwrite: { targetId: role.id, targetType: 0, roleName: role.name, old: { allow: String(P.ViewChannel), deny: '0' }, new: null },
    });
  }
  for (const c of chans) {
    const ow = c.permissionOverwrites.cache.get(role.id);
    assert.ok(ow, `overwrite tren kenh ${c.name} phai duoc tao lai`);
    assert.equal(ow.allow.bitfield, P.ViewChannel);
    assert.equal(ow.deny.bitfield, 0n);
  }
});

test('sua permission overwrite hang loat (sua): overwrite van con nhung SAI gia tri -> tra ve GOC qua fallback edit()', async () => {
  const { guild, act } = setup({ massPermissionChange: { limit: 4 } });
  const role = addRole(guild, { name: 'Nan nhan' });
  const chans = [1, 2, 3, 4].map((i) =>
    addChannel(guild, { name: `ow${i}`, overwrites: [{ id: role.id, type: 0, allow: P.SendMessages, deny: 0 }] })
  );
  for (const c of chans) {
    await act('massPermissionChange', {
      channelId: c.id,
      overwrite: { targetId: role.id, targetType: 0, roleName: role.name, old: { allow: String(P.SendMessages), deny: '0' }, new: { allow: String(P.Administrator), deny: '0' } },
    });
  }
  for (const c of chans) {
    const ow = c.permissionOverwrites.cache.get(role.id);
    assert.ok(ow, `overwrite tren kenh ${c.name} phai con ton tai`);
    assert.equal(ow.allow.bitfield, P.SendMessages, `phai tra ve dung gia tri goc (khong con la Administrator)`);
    assert.equal(ow.deny.bitfield, 0n);
  }
  assert.ok(callsOf(guild, 'channel.permissionOverwrites.edit').length >= 1, 'overwrite van con ton tai -> phai dung nhanh fallback edit()');
});

test('bot la kenh nhan canh bao: khong co kenh log thi gui DM chu server (khong bo roi im lang)', async () => {
  const { guild, act } = setup();
  for (let i = 0; i < 3; i++) await act('massBan', { userId: String(6000 + i) });
  await sleep(10);
  assert.ok(callsOf(guild, 'owner.dm').length >= 1);
});
