'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { makeEnv, addMember, addChannel, addRole, makeMessage, callsOf, P } = require('./helpers');
const core = require('../src/moderation/core');
const textCommands = require('../src/textCommands');

// mod voi role cao hon target (checkHierarchy trong commands.js yeu cau vay moi ban/kick/... duoc).
function addMod(guild, perms) {
  const role = addRole(guild, { name: 'Mod', position: 10 });
  return addMember(guild, { perms, roles: [role.id] });
}

test('prefix command: "!ban @user ..." chay dung nhu slash command that (mod du quyen)', async () => {
  const { guild, client, botId } = makeEnv();
  const mod = addMod(guild, P.BanMembers);
  const target = addMember(guild);
  const msg = makeMessage(guild, mod, { content: `!ban <@${target.id}> 7d bi report spam nhieu lan` });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'ban').length, 1, 'phai ban dung nguoi duoc mention');
  assert.equal(callsOf(guild, 'ban')[0][1], target.id);
  assert.equal(msg.replies.length, 1, 'phai co 1 tin nhan phan hoi');
  void botId;
});

test('prefix command: khong du quyen thi bi tu choi, khong thuc hien hanh dong', async () => {
  const { guild, client } = makeEnv();
  const nonMod = addMember(guild); // khong co quyen gi
  const target = addMember(guild);
  const msg = makeMessage(guild, nonMod, { content: `!ban <@${target.id}> spam` });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true, 'van coi la "da xu ly" (tra loi loi thieu quyen), chi la khong thuc hien');
  assert.equal(callsOf(guild, 'ban').length, 0);
  assert.match(msg.replies[0].embeds[0].data.description, /quyen/i);
});

test('prefix command: quyen phai tinh THEO KENH (permissionsIn), khong chi theo role cap guild', async () => {
  const { guild, client } = makeEnv();
  const mod = addMod(guild, P.BanMembers); // co Ban Members cap guild qua role Mod
  const target = addMember(guild);
  // Kenh nay overwrite CHAN han Ban Members cua role Mod -> mod nay khong con quyen ban trong kenh nay.
  const lockedChannel = addChannel(guild, {
    name: 'locked', type: 0,
    overwrites: [{ id: mod.roles.cache.find((r) => r.id !== guild.id).id, type: 0, deny: P.BanMembers }],
  });
  const msg = makeMessage(guild, mod, { content: `!ban <@${target.id}> spam`, channel: lockedChannel });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true, 'van tra loi (bao thieu quyen), chi la khong thuc hien');
  assert.equal(callsOf(guild, 'ban').length, 0, 'khong duoc ban vi kenh nay da bi overwrite thu hoi quyen');
  assert.match(msg.replies[0].embeds[0].data.description, /quyen/i);

  // Nhung o mot kenh KHAC (khong bi overwrite thu hoi), quyen Ban Members cap guild van con hieu luc.
  const openChannel = addChannel(guild, { name: 'open', type: 0 });
  const msg2 = makeMessage(guild, mod, { content: `!ban <@${target.id}> spam`, channel: openChannel });
  await textCommands.handleMessage(client, msg2);
  assert.equal(callsOf(guild, 'ban').length, 1, 'kenh khac khong bi overwrite thi van ban duoc binh thuong');
});

test('tag/mention bot: "@Bot slowmode set ..." hoat dong dung nhu prefix', async () => {
  const { guild, client, botId } = makeEnv();
  const mod = addMod(guild, P.ManageChannels);
  const ch = addChannel(guild, { name: 'chat', type: 0 });
  const msg = makeMessage(guild, mod, { content: `<@${botId}> slowmode set duration:10m channel:<#${ch.id}>`, channel: ch });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'channel.setRateLimitPerUser').length, 1, 'slowmode set (<=6h) phai dung co che goc Discord');
  assert.equal(callsOf(guild, 'channel.setRateLimitPerUser')[0][2], 600);
});

test('subcommand group qua prefix: "!automod voice set kind:... count:... seconds:..."', async () => {
  const { guild, client } = makeEnv();
  const mod = addMember(guild, { perms: P.ManageGuild });
  const msg = makeMessage(guild, mod, { content: '!automod voice set kind:mute count:5 seconds:20' });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  const store = core.load(guild.id);
  assert.deepEqual(store.config.automod.voice.kinds.mute, { count: 5, seconds: 20 });
});

test('flat subcommand (khong co group) qua tag bot: "@Bot case view id:1"', async () => {
  const { guild, client, botId } = makeEnv();
  const mod = addMember(guild, { perms: P.ModerateMembers });
  const target = addMember(guild);
  core.warnUser(guild, core.who(mod), core.who(target.user), 'test warn'); // tao case #1
  const msg = makeMessage(guild, mod, { content: `<@${botId}> case view id:1` });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(msg.replies.length, 1);
  assert.match(msg.replies[0].embeds[0].data.description ?? JSON.stringify(msg.replies[0].embeds[0].data), /test warn|WARN/i);
});

test('prefix: lenh khong ton tai -> im lang (khong tra loi), tranh spam voi tin nhan thuong bat dau bang prefix', async () => {
  const { guild, client } = makeEnv();
  const someone = addMember(guild);
  const msg = makeMessage(guild, someone, { content: '!lol thats crazy' });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, false);
  assert.equal(msg.replies.length, 0);
});

test('tag bot: lenh khong ton tai -> co tra loi huong dan (mention la tin hieu ro rang muon goi bot)', async () => {
  const { guild, client, botId } = makeEnv();
  const someone = addMember(guild);
  const msg = makeMessage(guild, someone, { content: `<@${botId}> lolwhat` });

  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(msg.replies.length, 1);
});

test('help: "!help" va tag bot khong kem gi deu tra ve danh sach lenh', async () => {
  const { guild, client, botId } = makeEnv();
  const someone = addMember(guild);
  const m1 = makeMessage(guild, someone, { content: '!help' });
  await textCommands.handleMessage(client, m1);
  assert.equal(m1.replies.length, 1);
  assert.match(m1.replies[0].embeds[0].data.description, /ban|automod/i);

  const m2 = makeMessage(guild, someone, { content: `<@${botId}>` });
  const handled2 = await textCommands.handleMessage(client, m2);
  assert.equal(handled2, true);
  assert.equal(m2.replies.length, 1);
});

test('tat prefix ("off") -> prefix khong con hoat dong nhung tag bot van hoat dong', async () => {
  const { guild, client, botId } = makeEnv();
  const store = core.load(guild.id);
  store.config.prefix = null;
  const mod = addMod(guild, P.BanMembers);
  const target = addMember(guild);

  const m1 = makeMessage(guild, mod, { content: `!ban <@${target.id}> spam` });
  assert.equal(await textCommands.handleMessage(client, m1), false, 'prefix da tat thi tin nhan "!..." la chat thuong');

  const m2 = makeMessage(guild, mod, { content: `<@${botId}> ban <@${target.id}> spam` });
  assert.equal(await textCommands.handleMessage(client, m2), true);
  assert.equal(callsOf(guild, 'ban').length, 1);
});

test('tin nhan thuong (khong prefix, khong tag bot) khong duoc coi la lenh', async () => {
  const { guild, client } = makeEnv();
  const someone = addMember(guild);
  const msg = makeMessage(guild, someone, { content: 'chao moi nguoi' });
  assert.equal(await textCommands.handleMessage(client, msg), false);
  assert.equal(msg.replies.length, 0);
});

test('tham so go tuong minh "ten:gia_tri" hoat dong bat ke thu tu (vd reason truoc, duration sau)', async () => {
  const { guild, client } = makeEnv();
  const mod = addMod(guild, P.BanMembers);
  const target = addMember(guild);
  const msg = makeMessage(guild, mod, { content: `!ban user:<@${target.id}> reason:bi report nhieu lan duration:7d` });

  await textCommands.handleMessage(client, msg);
  assert.equal(callsOf(guild, 'ban').length, 1);
});

test('gia tri INTEGER vuot min/max duoc gioi han lai giong Discord that (vd count toi da 200)', async () => {
  const { guild, client } = makeEnv();
  const mod = addMod(guild, P.ManageGuild);
  const msg = makeMessage(guild, mod, { content: '!automod voice set kind:soundboard count:99999 seconds:0' });

  await textCommands.handleMessage(client, msg);
  const store = core.load(guild.id);
  assert.deepEqual(store.config.automod.voice.kinds.soundboard, { count: 200, seconds: 1 });
});

test('/prefix set|show (slash command that): doi prefix va xem lai', async () => {
  const { commands } = require('../src/moderation/commands');
  const prefixCmd = commands.find((c) => c.data.toJSON().name === 'prefix');
  const { guild } = makeEnv();
  const mod = addMember(guild, { perms: P.ManageGuild });
  let replied = null;
  const fakeI = {
    guild, member: mod, user: mod.user, memberPermissions: mod.permissions,
    options: { getSubcommand: () => 'set', getString: () => 'sett?os' }, // se bi tu choi vi co khoang trang? -> dung gia tri khac ben duoi
    reply: async (p) => { replied = p; return p; },
  };
  // that ra go lai gia tri hop le, khong khoang trang:
  fakeI.options.getString = () => '?';
  await prefixCmd.execute(fakeI);
  assert.equal(core.load(guild.id).config.prefix, '?');
  assert.ok(replied);

  fakeI.options.getSubcommand = () => 'show';
  replied = null;
  await prefixCmd.execute(fakeI);
  assert.ok(replied.embeds[0].data.description.includes('?'));
});
