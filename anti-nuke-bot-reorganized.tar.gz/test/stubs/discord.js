'use strict';
// Ban gia lap toi thieu cua discord.js v14 de chay test khong can mang / khong can cai discord.js.
// Chi mo phong dung phan API ma bot su dung; cac hang so (AuditLogEvent, ChannelType, quyen...) trung gia tri that.
class Collection extends Map {
  filter(fn) { const o = new Collection(); for (const [k, v] of this) if (fn(v, k, this)) o.set(k, v); return o; }
  find(fn) { for (const [k, v] of this) if (fn(v, k, this)) return v; return undefined; }
  some(fn) { for (const [k, v] of this) if (fn(v, k, this)) return true; return false; }
  map(fn) { const o = []; for (const [k, v] of this) o.push(fn(v, k, this)); return o; }
  first() { return this.values().next().value; }
}

const PermissionFlagsBits = {
  CreateInstantInvite: 1n << 0n, KickMembers: 1n << 1n, BanMembers: 1n << 2n, Administrator: 1n << 3n,
  ManageChannels: 1n << 4n, ManageGuild: 1n << 5n, ViewAuditLog: 1n << 7n, ViewChannel: 1n << 10n, SendMessages: 1n << 11n,
  ManageMessages: 1n << 13n, MentionEveryone: 1n << 17n, ManageNicknames: 1n << 27n, ManageRoles: 1n << 28n,
  ManageWebhooks: 1n << 29n, ManageGuildExpressions: 1n << 30n, ModerateMembers: 1n << 40n,
};

class PermissionsBitField {
  constructor(bits = 0n) { this.bitfield = BigInt(bits); }
  has(p) { const b = BigInt(p); return (this.bitfield & PermissionFlagsBits.Administrator) !== 0n || (this.bitfield & b) === b; }
}
PermissionsBitField.Flags = PermissionFlagsBits;

const AuditLogEvent = {
  GuildUpdate: 1, ChannelCreate: 10, ChannelUpdate: 11, ChannelDelete: 12,
  ChannelOverwriteCreate: 13, ChannelOverwriteUpdate: 14, ChannelOverwriteDelete: 15,
  MemberKick: 20, MemberPrune: 21, MemberBanAdd: 22, MemberBanRemove: 23, MemberUpdate: 24, MemberRoleUpdate: 25, BotAdd: 28,
  RoleCreate: 30, RoleUpdate: 31, RoleDelete: 32, InviteCreate: 40, WebhookCreate: 50, WebhookDelete: 52,
  EmojiCreate: 60, EmojiDelete: 62, IntegrationCreate: 80, IntegrationUpdate: 81, IntegrationDelete: 82,
  StickerCreate: 90, StickerDelete: 92, ThreadCreate: 110, ThreadDelete: 112,
};
const ChannelType = { GuildText: 0, GuildVoice: 2, GuildCategory: 4, GuildAnnouncement: 5, GuildStageVoice: 13, GuildForum: 15 };
const Events = {
  ClientReady: 'ready', InteractionCreate: 'interactionCreate', MessageCreate: 'messageCreate', MessageUpdate: 'messageUpdate',
  ChannelCreate: 'channelCreate', ChannelDelete: 'channelDelete', GuildRoleDelete: 'roleDelete', GuildMemberAdd: 'guildMemberAdd',
  GuildCreate: 'guildCreate', GuildDelete: 'guildDelete', GuildAuditLogEntryCreate: 'guildAuditLogEntryCreate',
  VoiceStateUpdate: 'voiceStateUpdate', VoiceChannelEffectSend: 'voiceChannelEffectSend',
  ThreadCreate: 'threadCreate', MessageReactionAdd: 'messageReactionAdd',
};
const MessageFlags = { Ephemeral: 64 };
const Partials = { User: 0, Channel: 1, GuildMember: 2, Message: 3, Reaction: 4, GuildScheduledEvent: 5, ThreadMember: 6 };
// Gia tri trung voi API that cua Discord (AUTO_MODERATION_RULE_TRIGGER_TYPE / _EVENT_TYPE / _ACTION_TYPE).
const AutoModerationRuleTriggerType = { Keyword: 1, Spam: 3, KeywordPreset: 4, MentionSpam: 5, MemberProfile: 6 };
const AutoModerationRuleEventType = { MessageSend: 1, MemberUpdate: 2 };
const AutoModerationActionType = { BlockMessage: 1, SendAlertMessage: 2, Timeout: 3, BlockMemberInteraction: 4 };
// Dung cho Profanity/Slurs/Sexual Content (keywordFilters.js syncPresetRule) - gia tri trung API that.
const AutoModerationRuleKeywordPresetType = { Profanity: 1, SexualContent: 2, Slurs: 3 };

class EmbedBuilder {
  constructor() { this.data = { fields: [] }; }
  setTitle(t) { this.data.title = t; return this; }
  setDescription(d) { this.data.description = d; return this; }
  setColor(c) { this.data.color = c; return this; }
  setTimestamp() { return this; }
  addFields(...f) { this.data.fields.push(...f.flat()); return this; }
}

// Builder gia: nhan moi lenh goi chuoi, chay callback con, va KIEM TRA gioi han that cua Discord (toi da 25 lua chon,
// autocomplete khong di kem lua chon) de bat loi "deploy that bai" ngay trong test. toJSON() mo phong du cau truc that
// (options/type/required/choices/min-max/channel_types, de quy cho subcommand/subcommand group) de textCommands.js
// (bo doc schema lam lenh prefix/tag) co du lieu that de test, khong chi mac dinh "{name}" nhu ban cu.
const OPT_TYPE = {
  addSubcommand: 1, addSubcommandGroup: 2, addStringOption: 3, addIntegerOption: 4, addBooleanOption: 5,
  addUserOption: 6, addChannelOption: 7, addRoleOption: 8, addMentionableOption: 9, addNumberOption: 10, addAttachmentOption: 11,
};
function makeBuilder() {
  const st = { name: null, description: '', required: false, choices: [], options: [] };
  const proxy = new Proxy(st, {
    get(t, prop) {
      if (prop === 'toJSON') return () => {
        const out = { name: t.name, description: t.description };
        if (t.required) out.required = true;
        if (t.choices.length) out.choices = t.choices;
        if (t.options.length) out.options = t.options;
        if (t.min_value !== undefined) out.min_value = t.min_value;
        if (t.max_value !== undefined) out.max_value = t.max_value;
        if (t.max_length !== undefined) out.max_length = t.max_length;
        if (t.channel_types) out.channel_types = t.channel_types;
        return out;
      };
      return (...args) => {
        if (prop === 'setName') t.name = args[0];
        if (prop === 'setDescription') t.description = args[0];
        if (prop === 'setRequired') t.required = !!args[0];
        if (prop === 'setMinValue') t.min_value = args[0];
        if (prop === 'setMaxValue') t.max_value = args[0];
        if (prop === 'setMaxLength') t.max_length = args[0];
        if (prop === 'addChannelTypes') t.channel_types = args.flat();
        if (prop === 'addChoices') {
          t.choices.push(...args.flat());
          if (t.choices.length > 25) throw new RangeError('Toi da 25 lua chon (choices)');
        }
        if (prop === 'setAutocomplete' && args[0] && t.choices.length) throw new Error('autocomplete khong duoc di kem choices');
        if (prop in OPT_TYPE) {
          const child = makeBuilder();
          for (const a of args) if (typeof a === 'function') a(child);
          t.options.push({ ...child.toJSON(), type: OPT_TYPE[prop] });
        } else {
          for (const a of args) if (typeof a === 'function') a(makeBuilder());
        }
        return proxy;
      };
    },
  });
  return proxy;
}
class SlashCommandBuilder { constructor() { return makeBuilder(); } }

module.exports = {
  Collection, PermissionFlagsBits, PermissionsBitField, AuditLogEvent, ChannelType, Events, MessageFlags, EmbedBuilder, SlashCommandBuilder,
  Partials, AutoModerationRuleTriggerType, AutoModerationRuleEventType, AutoModerationActionType, AutoModerationRuleKeywordPresetType,
  GatewayIntentBits: {}, REST: class {}, Routes: {},
};
