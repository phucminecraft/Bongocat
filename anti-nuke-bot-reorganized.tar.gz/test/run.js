'use strict';
// Chay toan bo *.test.js bang trinh chay test co san cua Node (khong can cai them gi, khong can mang).
// Dung script nay thay vi "node --test test/" vi cach do khac nhau giua cac ban Node (22 coi thu muc la 1 module).
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const files = fs.readdirSync(__dirname).filter((f) => f.endsWith('.test.js')).map((f) => path.join(__dirname, f));
const res = spawnSync(process.execPath, ['--test', ...files], { stdio: 'inherit' });
process.exit(res.status ?? 1);
