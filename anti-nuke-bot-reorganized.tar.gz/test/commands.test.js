'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { makeEnv, addRole, addMember, callsOf, P } = require('./helpers');
const storage = require('../src/antinuke/storage');
const engine = require('../src/antinuke/engine');
const cmd = require('../src/antinuke/commands/antinuke');
const { MODULE_DEFS } = require('../src/antinuke/config');

function ix(env, { userId, group = null, sub, admin = true, opts = {} }) {
  const o = { replies: [], edits: [], choices: null };
  const get = (name) => opts[name];
  return Object.assign(o, {
    guild: env.guild, user: { id: userId, tag: `u${userId}` }, deferred: false, replied: false,
    inGuild: () => true,
    memberPermissions: { has: () => admin },
    options: { getSubcommandGroup: () => group, getSubcommand: () => sub, getUser: get, getRole: get, getString: get, getBoolean: get, getInteger: get, getChannel: get, getFocused: () => opts.focused ?? '' },
    reply: async (p) => { o.replies.push(p); o.replied = true; },
    editReply: async (p) => { o.edits.push(p); },
    deferReply: async () => { o.deferred = true; },
    respond: async (c) => { o.choices = c; },
  });
}
const text = (i) => JSON.stringify([...i.replies, ...i.edits]);

test('lenh khai bao hop le voi gioi han that cua Discord (<= 25 lua chon, autocomplete khong kem choices)', () => {
  assert.doesNotThrow(() => cmd.data.toJSON());
  assert.ok(Object.keys(MODULE_DEFS).length > 25, 'so module vuot 25 -> bat buoc dung autocomplete (ban cu se loi khi deploy)');
  const { commands } = require('../src/moderation/commands');
  const all = [cmd.data.toJSON(), ...commands.map((c) => c.data.toJSON())].map((c) => c.name);
  assert.equal(new Set(all).size, all.length, 'khong trung ten lenh');
});

test('PHAN QUYEN: admin thuong (khong phai chu server) KHONG duoc doi cau hinh / whitelist / khoi phuc', async () => {
  const env = makeEnv();
  const cfg = storage.getGuildConfig(env.guild.id);
  const rogue = '111000111';
  const before = JSON.stringify(cfg);
  const attempts = [
    { sub: 'add-user', group: 'whitelist', opts: { user: { id: rogue, bot: false } } },
    { sub: 'add-role', group: 'whitelist', opts: { role: { id: '5555555' } } },
    { sub: 'toggle', opts: { module: 'massBan', state: false } },
    { sub: 'config', opts: { module: 'massBan', limit: 100, amount: 1, unit: 'seconds', punishment: 'strip' } },
    { sub: 'restore', opts: { confirm: true } },
    { sub: 'setup', opts: { channel: { id: '777' } } },
    { sub: 'add', group: 'owners', opts: { user: { id: rogue, bot: false } } },
    { sub: 'now', group: 'backup' },
    { sub: 'unstrip', opts: { user: { id: rogue } } },
  ];
  for (const a of attempts) {
    const i = ix(env, { userId: rogue, admin: true, ...a });
    await cmd.execute(i);
    assert.match(text(i), /Chi chu server/, `${a.group ?? ''}.${a.sub} phai bi tu choi`);
  }
  assert.equal(JSON.stringify(storage.getGuildConfig(env.guild.id)), before, 'cau hinh khong duoc thay doi');
});

test('admin thuong van XEM duoc status / whitelist / backup (chi doc); nguoi khong phai admin thi khong', async () => {
  const env = makeEnv();
  for (const a of [{ sub: 'status' }, { sub: 'list', group: 'whitelist' }, { sub: 'list', group: 'owners' }, { sub: 'status', group: 'backup' }]) {
    const i = ix(env, { userId: '111000111', admin: true, ...a });
    await cmd.execute(i);
    assert.doesNotMatch(text(i), /Chi chu server|can quyen Administrator/);
  }
  const nobody = ix(env, { userId: '222000222', admin: false, sub: 'status' });
  await cmd.execute(nobody);
  assert.match(text(nobody), /Administrator/);
});

test('chu server cau hinh duoc; extraOwner cau hinh duoc nhung KHONG tu them owner khac', async () => {
  const env = makeEnv();
  const cfg = storage.getGuildConfig(env.guild.id);
  const helper = { id: '333000333', bot: false };

  await cmd.execute(ix(env, { userId: env.ownerId, group: 'owners', sub: 'add', opts: { user: helper } }));
  assert.deepEqual(cfg.extraOwners, [helper.id]);

  const t = ix(env, { userId: helper.id, sub: 'toggle', opts: { module: 'massKick', state: false } });
  await cmd.execute(t);
  assert.equal(cfg.modules.massKick.enabled, false, 'extraOwner duoc doi cau hinh');

  const again = ix(env, { userId: helper.id, group: 'owners', sub: 'add', opts: { user: { id: '444000444', bot: false } } });
  await cmd.execute(again);
  assert.match(text(again), /Chi chu server/);
  assert.deepEqual(cfg.extraOwners, [helper.id]);

  await cmd.execute(ix(env, { userId: env.ownerId, group: 'owners', sub: 'remove', opts: { user: helper } }));
  assert.deepEqual(cfg.extraOwners, []);
});

test('kiem tra dau vao: bot/nguoi, @everyone, module la, cua so thoi gian', async () => {
  const env = makeEnv();
  const cfg = storage.getGuildConfig(env.guild.id);
  const run = async (a) => { const i = ix(env, { userId: env.ownerId, ...a }); await cmd.execute(i); return text(i); };

  assert.match(await run({ group: 'whitelist', sub: 'add-user', opts: { user: { id: '1', bot: true } } }), /add-bot/);
  assert.match(await run({ group: 'whitelist', sub: 'add-bot', opts: { bot: { id: '1', bot: false } } }), /add-user/);
  assert.match(await run({ group: 'whitelist', sub: 'add-role', opts: { role: { id: env.guild.id } } }), /everyone/);
  assert.deepEqual(cfg.whitelistedUsers, []);
  for (const bad of ['__proto__', 'constructor', 'toString', 'khong-co']) assert.match(await run({ sub: 'toggle', opts: { module: bad, state: false } }), /Module khong hop le/);
  assert.match(await run({ sub: 'config', opts: { module: 'massBan', limit: 3, amount: 48, unit: 'hours', punishment: 'ban' } }), /1 giay den 24 gio/);
  assert.match(await run({ sub: 'config', opts: { module: 'massBan', limit: 4, amount: 20, unit: 'seconds', punishment: 'kick' } }), /nguong 4/);
  assert.deepEqual([cfg.modules.massBan.limit, cfg.modules.massBan.windowMs, cfg.modules.massBan.punishment], [4, 20_000, 'kick']);
});

test('autocomplete: toi da 25 goi y, loc theo tu khoa', async () => {
  const env = makeEnv();
  const all = ix(env, { userId: '1', sub: 'toggle' });
  await cmd.autocomplete(all);
  assert.equal(all.choices.length, 25);
  const some = ix(env, { userId: '1', sub: 'toggle', opts: { focused: 'privilege' } });
  await cmd.autocomplete(some);
  assert.deepEqual(some.choices.map((c) => c.value), ['privilegeEscalation']);
});

test('unstrip: hoan tra role bi go nham, xoa ghi nho va ngung cach ly', async () => {
  const env = makeEnv();
  const { guild } = env;
  const role = addRole(guild, { name: 'Mod', perms: P.KickMembers, position: 5 });
  const victim = addMember(guild);
  storage.recordStripped(guild.id, victim.id, [role.id, '999999'], 'massBan'); // 1 role da bi xoa that
  engine.quarantine.set(`${guild.id}:${victim.id}`, { until: Date.now() + 60_000, lastContain: Date.now() });
  const i = ix(env, { userId: env.ownerId, sub: 'unstrip', opts: { user: { id: victim.id } } });
  await cmd.execute(i);
  assert.deepEqual(callsOf(guild, 'member.roles.add').map((c) => c[2]), [[role.id]]);
  assert.equal(storage.getGuildConfig(guild.id).strippedRoles[victim.id], undefined);
  assert.equal(engine.quarantine.has(`${guild.id}:${victim.id}`), false);
  assert.match(text(i), /1\/2/);
});
