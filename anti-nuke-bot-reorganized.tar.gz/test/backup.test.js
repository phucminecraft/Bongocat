'use strict';
const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { makeEnv, addRole, addMember, addChannel, sleep, callsOf, P } = require('./helpers');
const { ChannelType: CT } = require('discord.js');
const backup = require('../src/antinuke/backup');
const { serializeChannel, serializeRole } = require('../src/antinuke/serialize');

beforeEach(() => backup._reset());

// Server mau: 1 category (chat) chua #general + #voice, 1 role Mod co 2 thanh vien, overwrite cho Mod tren #general.
function seed() {
  const env = makeEnv();
  const { guild } = env;
  const mod = addRole(guild, { name: 'Mod', perms: P.KickMembers, position: 20 });
  const m1 = addMember(guild, { roles: [mod.id] });
  const m2 = addMember(guild, { roles: [mod.id] });
  addMember(guild, {});
  guild.memberCount = guild.members.cache.size;
  const cat = addChannel(guild, { name: 'chat', type: CT.GuildCategory, position: 0 });
  const general = addChannel(guild, { name: 'general', parentId: cat.id, position: 1, overwrites: [{ id: mod.id, type: 0, allow: P.SendMessages, deny: 0n }] });
  const voice = addChannel(guild, { name: 'voice', type: CT.GuildVoice, parentId: cat.id, position: 2 });
  return { ...env, mod, m1, m2, cat, general, voice };
}
const nuke = (guild, ...items) => { for (const x of items) { (guild.channels.cache.has(x.id) ? guild.channels.cache : guild.roles.cache).delete(x.id); } };

test('snapshot: luu ID that, bo qua role managed/@everyone, trung trang thai thi khong nhan ban', async () => {
  const s = seed();
  addRole(s.guild, { name: 'IntegrationRole', managed: true });
  const r1 = await backup.takeSnapshot(s.guild, { force: true });
  assert.equal(r1.status, 'new');
  const snap = r1.snapshot;
  assert.ok(snap.channels.every((c) => c.id) && snap.roles.every((r) => r.id));
  assert.ok(!snap.roles.some((r) => r.managed || r.name === '@everyone'));
  assert.equal(snap.roleMembers[s.mod.id].length, 2, 'luu thanh vien cua role de gan lai sau nay');
  const r2 = await backup.takeSnapshot(s.guild, { force: true });
  assert.equal(r2.status, 'unchanged');
  assert.equal(backup.listSnapshots(s.guild.id).length, 1);
  addChannel(s.guild, { name: 'moi' });
  assert.equal((await backup.takeSnapshot(s.guild, { force: true })).status, 'new');
  assert.equal(backup.listSnapshots(s.guild.id).length, 2);
});

test('DAU DOC snapshot: server bi xoa sach roi den luc chup -> danh dau NGHI VAN, restore van dung ban tot', async () => {
  const s = seed();
  for (let i = 0; i < 12; i++) addChannel(s.guild, { name: `k${i}`, parentId: s.cat.id, position: 10 + i });
  await backup.takeSnapshot(s.guild, { force: true }); // ban tot (>= 8 muc)
  const good = backup.pickSnapshot(s.guild.id);
  for (const c of [...s.guild.channels.cache.values()].filter((c) => c.name.startsWith('k'))) nuke(s.guild, c);
  const bad = await backup.takeSnapshot(s.guild); // tu dong chup luc server da bi pha
  assert.equal(bad.status, 'suspect');
  assert.equal(backup.pickSnapshot(s.guild.id).hash, good.hash, 'restore mac dinh dung snapshot TOT, khong phai ban vua chup');
  // chup lai lan nua khi trang thai van y nhu vay: van nghi van (khong duoc "tay trang" bang cach cho doi)
  assert.equal((await backup.takeSnapshot(s.guild)).status, 'suspect');
  assert.equal(backup.pickSnapshot(s.guild.id).hash, good.hash);
  // chu server xac nhan trang thai hien tai la tot -> coi la tot
  assert.equal((await backup.takeSnapshot(s.guild, { force: true })).status, 'unchanged');
  assert.equal(backup.pickSnapshot(s.guild.id).suspect, false);
});

test('dong bang: dang bi tan cong thi khong chup tu dong (nhung chup tay van duoc)', async () => {
  const s = seed();
  backup.freeze(s.guild.id, 60_000);
  assert.equal((await backup.takeSnapshot(s.guild)).status, 'frozen');
  assert.equal(backup.listSnapshots(s.guild.id).length, 0);
  assert.equal((await backup.takeSnapshot(s.guild, { force: true })).status, 'new');
});

test('lich su: gioi han 6 ban va khong bao gio vut ban tot nhat', async () => {
  const s = seed();
  for (let i = 0; i < 10; i++) { addChannel(s.guild, { name: `x${i}` }); await backup.takeSnapshot(s.guild, { force: true }); }
  assert.equal(backup.listSnapshots(s.guild.id).length, 6);
});

test('RESTORE toan dien: tao lai role + category + kenh, map ID cu -> moi cho overwrite, gan lai kenh con mo coi, gan lai thanh vien cho role', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  // Nuke: xoa role Mod, category, #general (kenh con #voice con song nhung mat cha, parentId cu tro vao category da chet)
  nuke(s.guild, s.mod, s.cat, s.general);
  for (const m of [s.m1, s.m2]) m.roles.cache.delete(s.mod.id);
  s.guild.calls.length = 0;

  const r = await backup.restoreAll(s.guild, {});
  assert.equal(r.rolesCreated, 1);
  assert.equal(r.categoriesCreated, 1);
  assert.equal(r.channelsCreated, 1);
  assert.equal(r.reparented, 1, '#voice con song phai duoc dua ve category moi');

  const newCat = [...s.guild.channels.cache.values()].find((c) => c.name === 'chat');
  const newGeneral = [...s.guild.channels.cache.values()].find((c) => c.name === 'general');
  const newMod = [...s.guild.roles.cache.values()].find((x) => x.name === 'Mod');
  assert.notEqual(newCat.id, s.cat.id);
  assert.equal(newGeneral.parentId, newCat.id, 'kenh tao lai nam trong category MOI (ban cu: parentId cu tro vao category da chet)');
  const ow = s.guild.created.channels.find((c) => c.name === 'general').permissionOverwrites;
  assert.equal(ow.length, 1);
  assert.equal(ow[0].id, newMod.id, 'overwrite tro toi role MOI, khong phai ID cu da chet');
  assert.equal(callsOf(s.guild, 'channel.setParent')[0][2], newCat.id);

  await r.membersTask;
  assert.deepEqual(callsOf(s.guild, 'member.roles.add').map((c) => c[1]).sort(), [s.m1.id, s.m2.id].sort());
  assert.ok(callsOf(s.guild, 'member.roles.add').every((c) => c[2][0] === newMod.id));
});

test('RESTORE idempotent: chay lai khong tao trung bat cu thu gi', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  nuke(s.guild, s.general, s.mod);
  await backup.restoreAll(s.guild, {});
  s.guild.calls.length = 0;
  const again = await backup.restoreAll(s.guild, {});
  assert.deepEqual([again.rolesCreated, again.categoriesCreated, again.channelsCreated], [0, 0, 0]);
  assert.equal(callsOf(s.guild, 'channels.create').length + callsOf(s.guild, 'roles.create').length, 0);
});

test('2 kenh TRUNG TEN bi xoa -> tao lai du 2 (ban cu khop theo ten nen chi tao 1)', async () => {
  const s = seed();
  const a = addChannel(s.guild, { name: 'chat-chung', parentId: s.cat.id, position: 5 });
  const b = addChannel(s.guild, { name: 'chat-chung', parentId: s.cat.id, position: 6 });
  await backup.takeSnapshot(s.guild, { force: true });
  nuke(s.guild, a, b);
  const r = await backup.restoreAll(s.guild, {});
  assert.equal(r.channelsCreated, 2);
  assert.equal([...s.guild.channels.cache.values()].filter((c) => c.name === 'chat-chung').length, 2);
});

test('kenh bi DOI TEN (con song) khong bi tao them ban trung', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  s.general.name = 'da-bi-doi-ten';
  const r = await backup.restoreAll(s.guild, {});
  assert.equal(r.channelsCreated + r.categoriesCreated + r.rolesCreated, 0);
});

test('2 lan restore CHAY DONG THOI khong tao trung (khoa theo guild)', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  nuke(s.guild, s.general, s.voice);
  s.guild.latency = 5; // do tre API that: neu khong co khoa, luot 2 se thay kenh con thieu va tao trung
  await Promise.all([backup.restoreAll(s.guild, {}), backup.restoreAll(s.guild, {}), backup.requestRestore(s.guild, {})]);
  assert.equal(callsOf(s.guild, 'channels.create').length, 2, 'moi kenh chi duoc tao 1 lan');
});

test('kenh/role do nguoi TIN CAY chu dong xoa thi KHONG bi hoi sinh', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  nuke(s.guild, s.voice);
  backup.markLegitDelete(s.guild.id, 'channel', s.voice.id);
  nuke(s.guild, s.general);
  const r = await backup.restoreAll(s.guild, {});
  assert.equal(r.channelsCreated, 1);
  assert.ok(!s.guild.created.channels.some((c) => c.name === 'voice'));
});

test('kenh tao SAU snapshot roi bi xoa: khoi phuc duoc nho du lieu luc bi xoa (hint), khong can nam trong snapshot', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  const fresh = addChannel(s.guild, { name: 'moi-tao', parentId: s.cat.id, position: 9 });
  const data = serializeChannel(s.guild, fresh);
  nuke(s.guild, fresh);
  const r = await backup.restoreAll(s.guild, { hints: { channels: [data] } });
  assert.equal(r.channelsCreated, 1);
  assert.equal(s.guild.created.channels[0].name, 'moi-tao');
});

test('chua co snapshot va khong co hint -> khong lam gi, khong loi', async () => {
  const s = seed();
  const r = await backup.restoreAll(s.guild, {});
  assert.deepEqual([r.rolesCreated, r.channelsCreated, r.categoriesCreated], [0, 0, 0]);
});

test('restore mot phan khi API loi: dem loi, van tiep tuc cac muc con lai', async () => {
  const s = seed();
  await backup.takeSnapshot(s.guild, { force: true });
  nuke(s.guild, s.general, s.voice);
  const orig = s.guild.channels.create;
  let n = 0;
  s.guild.channels.create = async (o) => { if (++n === 1) throw new Error('boom'); return orig(o); };
  const r = await backup.restoreAll(s.guild, {});
  assert.equal(r.errors, 1);
  assert.equal(r.channelsCreated, 1);
});

test('nuke qua engine: xoa 3 kenh -> ban ke tan cong + tu dong khoi phuc du 3 kenh (dung du lieu luc xoa)', async () => {
  const s = seed();
  const engine = require('../src/antinuke/engine');
  const deletedCache = require('../src/antinuke/deletedCache');
  const attacker = addMember(s.guild, { roles: [addRole(s.guild, { name: 'A', perms: P.Administrator, position: 5 }).id] });
  await backup.takeSnapshot(s.guild, { force: true });
  const victims = [1, 2, 3].map((i) => addChannel(s.guild, { name: `moi${i}`, parentId: s.cat.id }));
  for (const v of victims) {
    deletedCache.remember(s.guild.id, 'channel', v.id, serializeChannel(s.guild, v)); // nhu su kien channelDelete that
    nuke(s.guild, v);
  }
  for (const v of victims) await engine.handleAction(s.client, s.guild, attacker.id, 'massChannelDelete', { kind: 'channel', targetId: v.id, audit: null });
  await sleep(20);
  assert.ok(callsOf(s.guild, 'ban').some((c) => c[1] === attacker.id));
  const names = s.guild.created.channels.map((c) => c.name).sort();
  assert.deepEqual(names, ['moi1', 'moi2', 'moi3']);
  assert.equal(backup.isFrozen(s.guild.id), true, 'snapshot bi dong bang trong luc bi tan cong');
});
