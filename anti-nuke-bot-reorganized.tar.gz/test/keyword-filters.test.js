'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
require('./_setup');
const { makeEnv, addMember, addChannel, makeMessage, callsOf, P } = require('./helpers');
const core = require('../src/moderation/core');
const automod = require('../src/moderation/automod');
const keywordFilters = require('../src/moderation/keywordFilters');
const textCommands = require('../src/textCommands');

const mkMod = (guild) => addMember(guild, { perms: P.ManageGuild });
const setup = () => {
  const env = makeEnv();
  const cfg = core.load(env.guild.id).config.automod;
  return { ...env, cfg };
};

// ============================================================ danh sach tu: customKeywords / wildcardKeywords / blockedPhrases (item 23-26)

test('checkListRules: customKeywords khop dung nghia den, "*" la ky tu thuong (khong phai wildcard nhu Wildcard Keywords)', () => {
  const { cfg } = setup();
  cfg.customKeywords.enabled = true;
  cfg.customKeywords.list = ['a*b'];
  assert.equal(keywordFilters.checkListRules(cfg, 'gia tri la acccb'), null, '"*" khong duoc noi la wildcard o rule nay');
  const hit = keywordFilters.checkListRules(cfg, 'gia tri la a*b day');
  assert.equal(hit.rule, 'customKeywords');
});

test('checkListRules: wildcardKeywords ho tro "*" nhu 1 dai dien noi TRONG 1 tu (khong vuot khoang trang - ke thua tu rule words cu)', () => {
  const { cfg } = setup();
  cfg.wildcardKeywords.enabled = true;
  cfg.wildcardKeywords.list = ['free*nitro'];
  assert.equal(keywordFilters.checkListRules(cfg, 'free stuff nitro mien phi'), null, '"*" khong vuot qua khoang trang (giong Bad Words cu)');
  const hit = keywordFilters.checkListRules(cfg, 'ma khuyen mai free123nitro dinh kem');
  assert.equal(hit.rule, 'wildcardKeywords');
});

test('checkListRules: blockedPhrases khop CUM TU nhieu chu, khong khop tung tu rieng le trong cum', () => {
  const { cfg } = setup();
  cfg.blockedPhrases.enabled = true;
  cfg.blockedPhrases.list = ['join my server'];
  assert.equal(keywordFilters.checkListRules(cfg, 'ban co the join no duoc khong, con server thi sao'), null);
  assert.equal(keywordFilters.checkListRules(cfg, 'hay join my server nhe ban oi').rule, 'blockedPhrases');
});

test('checkListRules: seed co san cho Scam/Phishing/Crypto/Advertisement (khong nhay cam - hoat dong ngay khi bat)', () => {
  const { cfg } = setup();
  assert.ok(cfg.scam.list.length > 0);
  assert.ok(cfg.phishing.list.length > 0);
  assert.ok(cfg.cryptoScam.list.length > 0);
  assert.ok(cfg.advertisement.list.length > 0);
  cfg.scam.enabled = true;
  assert.equal(keywordFilters.checkListRules(cfg, 'CONGRATULATIONS WINNER, claim your prize now!').rule, 'scam');
});

test('checkListRules: 8 rule nhay cam (racism/hateSpeech/harassment/bullying/threats/selfHarm/swearing/nsfw) de TRONG mac dinh', () => {
  const { cfg } = setup();
  for (const id of ['racism', 'hateSpeech', 'harassment', 'bullying', 'threats', 'selfHarm', 'swearing', 'nsfw']) {
    assert.deepEqual(cfg[id].list, [], `${id} phai de trong mac dinh (server tu nhap)`);
    assert.equal(cfg[id].enabled, false, `${id} phai tat mac dinh`);
  }
});

test('checkListRules: thu tu uu tien - selfHarm dung TRUOC cac rule khac neu tin nhan khop nhieu rule cung luc', () => {
  const { cfg } = setup();
  cfg.selfHarm.enabled = true;
  cfg.selfHarm.list = ['tu ket thuc'];
  cfg.customKeywords.enabled = true;
  cfg.customKeywords.list = ['tu ket thuc'];
  const hit = keywordFilters.checkListRules(cfg, 'toi muon tu ket thuc');
  assert.equal(hit.rule, 'selfHarm');
});

// ============================================================ Keyword Whitelist (item 28)

test('checkWhitelist + handleMessage: mien tru rule words VA cac rule keyword moi, KHONG mien tru invites', async () => {
  const { guild, client, cfg } = setup();
  cfg.enabled = true;
  cfg.words.list = ['xauxa'];
  cfg.customKeywords.enabled = true;
  cfg.customKeywords.list = ['xauxa'];
  cfg.whitelist.enabled = true;
  cfg.whitelist.list = ['xauxa nhung an toan'];
  const user = addMember(guild, {});

  assert.equal(keywordFilters.checkWhitelist(cfg.whitelist, 'day la tu xauxa nhung an toan ban nhe'), true);
  assert.equal(keywordFilters.checkWhitelist(cfg.whitelist, 'day la tu xauxa thoi'), false);

  const safeMsg = makeMessage(guild, user, { content: 'day la tu xauxa nhung an toan ban nhe' });
  assert.equal(await automod.handleMessage(client, safeMsg), false, 'whitelist phai chan rule words+customKeywords');

  cfg.invites.enabled = true;
  const invMsg = makeMessage(guild, user, { content: 'xauxa nhung an toan, moi vao discord.gg/abcdefg nhe' });
  const handled = await automod.handleMessage(client, invMsg);
  assert.equal(handled, true, 'whitelist KHONG duoc mien tru invites (khac ban chat "tu khoa")');
});

// ============================================================ Self-Harm Keywords (item 12): notifyStaff

test('enforce notifyStaff: khong goi cong khai trong kenh, khong tu phat, chi gui canh bao RIENG vao log channel', async () => {
  const { guild, client, cfg } = setup();
  cfg.enabled = true;
  cfg.selfHarm.enabled = true;
  cfg.selfHarm.list = ['tu ket thuc cuoc song'];
  cfg.selfHarm.punish = { type: 'timeout', minutes: 30 }; // du admin lo dat punish, notifyStaff van phai bo qua
  const logCh = addChannel(guild, { name: 'mod-log', type: 0 });
  core.load(guild.id).config.logChannelId = logCh.id;
  const user = addMember(guild, {});
  const msg = makeMessage(guild, user, { content: 'toi muon tu ket thuc cuoc song' });

  const handled = await automod.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'message.delete').length, 0, 'mac dinh KHONG xoa tin (giu ngu canh cho staff doc)');
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'KHONG tu phat du co cau hinh punish');
  const sent = callsOf(guild, 'channel.send').filter((c) => c[1] === logCh.id);
  assert.equal(sent.length, 1, 'phai gui 1 canh bao RIENG vao log channel');
  assert.equal(callsOf(guild, 'channel.send').filter((c) => c[1] === msg.channel.id).length, 0, 'khong duoc gui bat ky tin nao vao KENH CONG KHAI noi nguoi do nhan tin');
});

// ============================================================ URLs / Domain Blacklist (item 18-19)

test('checkStructuralRules: urls (allow-list) chan MOI link tru domain duoc cho phep, ho tro subdomain', () => {
  const { cfg } = setup();
  cfg.urls.enabled = true;
  cfg.urls.allowDomains = ['example.com'];
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'xem tai https://sub.example.com/path'), null, 'subdomain cua domain duoc allow phai qua');
  const hit = keywordFilters.checkStructuralRules(cfg, 'xem tai https://evil.test/abc');
  assert.equal(hit.rule, 'urls');
});

test('checkStructuralRules: domainBlacklist CHI chan domain co trong danh sach (nguoc voi urls, dung ten khac nghia)', () => {
  const { cfg } = setup();
  cfg.domainBlacklist.enabled = true;
  cfg.domainBlacklist.list = ['evil.test'];
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'link an toan: https://example.com'), null);
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'link xau: https://evil.test/x').rule, 'domainBlacklist');
});

// ============================================================ IP / Email / Phone (item 20-21)

test('checkStructuralRules: ipAddresses phat hien IPv4', () => {
  const { cfg } = setup();
  cfg.ipAddresses.enabled = true;
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'khong co gi o day ca'), null);
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'server cua toi: 192.168.1.100 nhe').rule, 'ipAddresses');
});

test('checkStructuralRules: emailAddresses phat hien dia chi email', () => {
  const { cfg } = setup();
  cfg.emailAddresses.enabled = true;
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'lien he toi qua test.user@example.com nhe').rule, 'emailAddresses');
});

test('checkStructuralRules: phoneNumbers bat so co dau ngan cach va so go lien 10 so, KHONG bao dong gia voi ID Discord 18 so', () => {
  const { cfg } = setup();
  cfg.phoneNumbers.enabled = true;
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'goi toi 090-123-4567 nhe').rule, 'phoneNumbers');
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'sdt minh la 0912345678').rule, 'phoneNumbers');
  assert.equal(keywordFilters.checkStructuralRules(cfg, 'id cua ban la 600000000000000001 do'), null, 'khong duoc bao dong gia voi ID Discord dai 18 so');
});

// ============================================================ Regex Filters (item 22): lint an toan + che do js

test('lintJsPattern: tu choi nested-quantifier (dang gay ReDoS pho bien nhat), chap nhan pattern an toan', () => {
  assert.match(keywordFilters.lintJsPattern('(a+)+$'), /ReDoS|long nhau/);
  assert.match(keywordFilters.lintJsPattern('(.*)+'), /ReDoS|long nhau/);
  assert.equal(keywordFilters.lintJsPattern('free\\s*nitro'), null);
});

test('lintJsPattern / lintNativePattern: deu tu choi backreference va lookaround (giong han che that cua Rust regex ben Discord)', () => {
  assert.ok(keywordFilters.lintJsPattern('(a)\\1'));
  assert.ok(keywordFilters.lintJsPattern('(?=abc)'));
  assert.ok(keywordFilters.lintNativePattern('(?<=abc)def'));
  assert.equal(keywordFilters.lintNativePattern('free\\s*nitro'), null);
});

test('checkJsRegexFilters: pattern che do js khop tai bot; pattern che do native KHONG duoc check o day (Discord tu chan)', () => {
  const { cfg } = setup();
  cfg.regexFilters.enabled = true;
  cfg.regexFilters.patterns = [{ pattern: 'd[i1]scount\\s*c[o0]de', mode: 'js' }, { pattern: 'khong-lien-quan', mode: 'native' }];
  assert.ok(keywordFilters.checkJsRegexFilters(cfg.regexFilters, 'nhap d1scount c0de de duoc giam gia'));
  assert.equal(keywordFilters.checkJsRegexFilters(cfg.regexFilters, 'khong-lien-quan xuat hien o day'), null, 'pattern che do native khong duoc bot tu check');
});

// ============================================================ Required Phrases (item 27)

test('checkRequiredPhrases: kenh duoc chi dinh thieu cum bat buoc -> bao vi pham; co cum -> qua; kenh khac khong bi anh huong', () => {
  const { guild, cfg } = setup();
  const appCh = addChannel(guild, { name: 'applications', type: 0 });
  const otherCh = addChannel(guild, { name: 'general', type: 0 });
  const user = addMember(guild, {});
  cfg.requiredPhrases.enabled = true;
  cfg.requiredPhrases.channelIds = [appCh.id];
  cfg.requiredPhrases.list = ['Ly do ung tuyen:'];

  const missing = makeMessage(guild, user, { channel: appCh, content: 'toi muon vao server' });
  assert.ok(keywordFilters.checkRequiredPhrases(cfg.requiredPhrases, missing, missing.content));

  const ok = makeMessage(guild, user, { channel: appCh, content: 'Ly do ung tuyen: toi thich cong dong nay' });
  assert.equal(keywordFilters.checkRequiredPhrases(cfg.requiredPhrases, ok, ok.content), null);

  const elsewhere = makeMessage(guild, user, { channel: otherCh, content: 'chat linh tinh khong lien quan' });
  assert.equal(keywordFilters.checkRequiredPhrases(cfg.requiredPhrases, elsewhere, elsewhere.content), null, 'kenh khong duoc chi dinh phai bo qua');
});

// ============================================================ Discord native AutoMod: Profanity/Slurs/Sexual Content preset + Regex Filters che do native

test('syncPresetRule: bat -> tao 1 AutoMod rule KeywordPreset that; tat -> xoa rule do; khong tao trung khi goi lai', async () => {
  const { guild, cfg } = setup();
  cfg.exemptRoles = ['111'];
  cfg.exemptChannels = ['222'];
  cfg.slurs.enabled = true;
  const res1 = await keywordFilters.syncPresetRule(guild, cfg, 'slurs');
  assert.equal(res1.ok, true);
  assert.equal(callsOf(guild, 'automod.rule.create').length, 1);
  const created = [...guild.autoModerationRules._store.values()][0];
  assert.deepEqual(created.triggerMetadata.presets, [3]); // AutoModerationRuleKeywordPresetType.Slurs = 3
  assert.deepEqual(created.exemptRoles, ['111']);

  const res2 = await keywordFilters.syncPresetRule(guild, cfg, 'slurs');
  assert.equal(res2.ok, true);
  assert.equal(callsOf(guild, 'automod.rule.create').length, 1, 'khong duoc tao trung rule khi da co san');

  cfg.slurs.enabled = false;
  const res3 = await keywordFilters.syncPresetRule(guild, cfg, 'slurs');
  assert.equal(res3.ok, true);
  assert.equal(callsOf(guild, 'automod.rule.delete').length, 1);
});

test('syncRegexNativeRule: chi dua pattern che do native vao AutoMod rule, tu xoa rule khi khong con pattern native nao', async () => {
  const { guild, cfg } = setup();
  cfg.regexFilters.enabled = true;
  cfg.regexFilters.patterns = [{ pattern: 'abc+', mode: 'native' }, { pattern: 'js-only', mode: 'js' }];
  const res = await keywordFilters.syncRegexNativeRule(guild, cfg);
  assert.equal(res.ok, true);
  const created = [...guild.autoModerationRules._store.values()][0];
  assert.deepEqual(created.triggerMetadata.regexPatterns, ['abc+'], 'chi pattern che do native, khong gom pattern js');

  cfg.regexFilters.patterns = [];
  const res2 = await keywordFilters.syncRegexNativeRule(guild, cfg);
  assert.equal(res2.ok, true);
  assert.equal(guild.autoModerationRules._store.size, 0, 'het pattern native -> tu xoa rule');
});

// ============================================================ Lenh /automod keyword ... (qua prefix command, giong quy uoc cac test command khac)

test('!automod keyword add/toggle rule:customKeywords: chan tin nhan qua duong lenh day du (khong goi engine truc tiep)', async () => {
  const { guild, client } = setup();
  const mod = mkMod(guild);
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod toggle enabled:true' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod keyword add rule:customKeywords value:cammark' }));
  await textCommands.handleMessage(client, makeMessage(guild, mod, { content: '!automod keyword toggle rule:customKeywords enabled:true' }));
  const cfg = core.load(guild.id).config.automod;
  assert.deepEqual(cfg.customKeywords.list, ['cammark']);
  assert.equal(cfg.customKeywords.enabled, true);

  const user = addMember(guild, {});
  const msg = makeMessage(guild, user, { content: 'day co chua cammark trong do' });
  assert.equal(await automod.handleMessage(client, msg), true);
});

test('!automod keyword add rule:profanity: bi tu choi (rule preset dung danh sach Discord, khong co danh sach tuy chinh)', async () => {
  const { guild, client } = setup();
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod keyword add rule:profanity value:test' });
  await textCommands.handleMessage(client, msg);
  assert.match(msg.replies[0].embeds[0].data.description, /danh sach cua Discord|khong co danh sach/i);
});

test('!automod keyword toggle rule:profanity enabled:true: tao AutoMod rule that (qua duong lenh)', async () => {
  const { guild, client } = setup();
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod keyword toggle rule:profanity enabled:true' });
  const handled = await textCommands.handleMessage(client, msg);
  assert.equal(handled, true);
  assert.equal(callsOf(guild, 'automod.rule.create').length, 1);
  assert.equal(core.load(guild.id).config.automod.profanity.enabled, true);
});

test('!automod keyword add rule:regexFilters value:(a+)+ mode:js: bi tu choi boi lintJsPattern (ReDoS)', async () => {
  const { guild, client } = setup();
  const mod = mkMod(guild);
  const msg = makeMessage(guild, mod, { content: '!automod keyword add rule:regexFilters value:(a+)+ mode:js' });
  await textCommands.handleMessage(client, msg);
  assert.match(msg.replies[0].embeds[0].data.description, /ReDoS|long nhau/);
  assert.equal(core.load(guild.id).config.automod.regexFilters.patterns.length, 0);
});

test('/automod punish + delete: rule khong hop le bi tu choi (khong con duoc Discord addChoices gioi han ho nua vi da chuyen sang autocomplete)', async () => {
  const { guild, client } = setup();
  const mod = mkMod(guild);
  const msg1 = makeMessage(guild, mod, { content: '!automod punish rule:khongtontai type:timeout minutes:5' });
  await textCommands.handleMessage(client, msg1);
  assert.match(msg1.replies[0].embeds[0].data.description, /khong hop le/i);

  const msg2 = makeMessage(guild, mod, { content: '!automod delete rule:scam enabled:false' });
  await textCommands.handleMessage(client, msg2);
  assert.equal(core.load(guild.id).config.automod.scam.delete, false, 'rule moi (scam) phai duoc /automod delete chap nhan');
});

test('/automod status: hien thi ca field tong hop cho 26 rule moi, khong vuot 25 field/embed', async () => {
  const { commands } = require('../src/moderation/commands');
  const { guild } = setup();
  const mod = mkMod(guild);
  const statusCmd = commands.find((c) => c.data.toJSON().name === 'automod');
  let replied = null;
  const fakeI = {
    guild, member: mod, user: mod.user, memberPermissions: mod.permissions,
    options: { getSubcommandGroup: () => null, getSubcommand: () => 'status' },
    reply: async (p) => { replied = p; return p; },
  };
  await statusCmd.execute(fakeI);
  const fields = replied.embeds[0].data.fields;
  assert.ok(fields.length <= 25, `Discord gioi han 25 field/embed, dang co ${fields.length}`);
  assert.match(fields.map((f) => f.name).join(' | '), /Keyword Filters/);
});

test('lenh /automod: tong so option cap cao nhat van <= 25 (gioi han cua Discord) sau khi them subcommand group "keyword"', () => {
  const { commands } = require('../src/moderation/commands');
  const automodCmd = commands.find((c) => c.data.toJSON().name === 'automod');
  assert.ok(automodCmd.data.toJSON().options.length <= 25);
});
