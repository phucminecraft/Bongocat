'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { makeEnv, addMember, addChannel, addRole, callsOf, makeVoiceState, P } = require('./helpers');
const core = require('../src/moderation/core');
const voiceProtection = require('../src/moderation/voiceProtection');

// Bat automod (cong tac tong) + Voice Protection cho 1 guild test, tra ve store de tuy chinh them.
function enableVoice(guild, patch = {}) {
  const store = core.load(guild.id);
  store.config.automod.enabled = true;
  Object.assign(store.config.automod.voice, { enabled: true, ...patch });
  return store;
}

test('joinLeave: vao/ra kenh thoai lien tuc vuot nguong -> bi timeout (hinh phat mac dinh)', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild);
  store.config.automod.voice.kinds.joinLeave = { count: 3, seconds: 30 };
  const member = addMember(guild);
  const vc = addChannel(guild, { name: 'General', type: 2 });

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, null), makeVoiceState(member, vc));
  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, vc), makeVoiceState(member, null));
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'chua du nguong thi chua bi phat');

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, null), makeVoiceState(member, vc));
  assert.equal(callsOf(guild, 'member.timeout').length, 1, 'du 3 lan vao/ra trong cua so -> bi timeout');
});

test('channelSwitch (VC hopping): nhay qua lai nhieu kenh thoai vuot nguong -> bi timeout', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild);
  store.config.automod.voice.kinds.channelSwitch = { count: 2, seconds: 30 };
  const member = addMember(guild);
  const a = addChannel(guild, { name: 'A', type: 2 });
  const b = addChannel(guild, { name: 'B', type: 2 });

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, a), makeVoiceState(member, b));
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, b), makeVoiceState(member, a));
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('camera: moi lan bat/tat deu duoc ghi log (bang chung cho admin), rieng biet voi viec xu phat khi vuot nguong', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild, { log: true });
  store.config.automod.voice.kinds.camera = { count: 3, seconds: 30 };
  const logCh = addChannel(guild, { name: 'log', type: 0 });
  store.config.logChannelId = logCh.id;
  const member = addMember(guild);
  const vc = addChannel(guild, { name: 'General', type: 2 });
  const toggle = (on) => voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, vc, { selfVideo: !on }), makeVoiceState(member, vc, { selfVideo: on }));

  await toggle(true);
  await toggle(false);
  assert.equal(callsOf(guild, 'channel.send').length, 2, 'moi lan bat/tat camera deu duoc ghi log, du chua vuot nguong');
  assert.equal(callsOf(guild, 'member.timeout').length, 0);

  await toggle(true); // lan thu 3 -> cham nguong
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('mute/deafen: KHONG ghi log tung lan (tranh spam kenh log vi day la hanh vi rat pho bien), nhung van bi phat khi vuot nguong', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild, { log: true });
  store.config.automod.voice.kinds.mute = { count: 3, seconds: 20 };
  const logCh = addChannel(guild, { name: 'log', type: 0 });
  store.config.logChannelId = logCh.id;
  const member = addMember(guild);
  const vc = addChannel(guild, { name: 'General', type: 2 });
  const toggleMute = (on) => voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, vc, { selfMute: !on }), makeVoiceState(member, vc, { selfMute: on }));

  await toggleMute(true);
  await toggleMute(false);
  assert.equal(callsOf(guild, 'channel.send').length, 0, 'bat/tat mic khong ghi log tung lan');
  await toggleMute(true); // du nguong
  assert.equal(callsOf(guild, 'member.timeout').length, 1);
});

test('mien tru: mod co quyen bypass (Administrator) hoac nam trong exemptRoles thi khong bao gio bi tinh', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild);
  store.config.automod.voice.kinds.joinLeave = { count: 2, seconds: 30 };
  const vc = addChannel(guild, { name: 'General', type: 2 });

  const admin = addMember(guild, { perms: P.Administrator });
  for (let i = 0; i < 5; i++) {
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(admin, null), makeVoiceState(admin, vc));
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(admin, vc), makeVoiceState(admin, null));
  }
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'Administrator luon duoc mien tru');

  const role = addRole(guild, { name: 'Mien tru VoiceProtection', position: 2 });
  store.config.automod.exemptRoles.push(role.id);
  const exempt = addMember(guild, { roles: [role.id] });
  for (let i = 0; i < 5; i++) {
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(exempt, null), makeVoiceState(exempt, vc));
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(exempt, vc), makeVoiceState(exempt, null));
  }
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'role trong exemptRoles cung duoc mien tru');
});

test('chu server duoc mien tru hoan toan: khong ghi log, khong bi phat', async () => {
  const { guild, client, ownerId } = makeEnv();
  const store = enableVoice(guild, { log: true });
  store.config.automod.voice.kinds.joinLeave = { count: 1, seconds: 30 };
  const logCh = addChannel(guild, { name: 'log', type: 0 });
  store.config.logChannelId = logCh.id;
  const owner = guild.members.cache.get(ownerId);
  const vc = addChannel(guild, { name: 'General', type: 2 });

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(owner, null), makeVoiceState(owner, vc));
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
  assert.equal(callsOf(guild, 'channel.send').length, 0);
});

test('soundboard: spam phat am thanh vuot nguong -> bi phat; hieu ung chi la emoji (khong soundId) thi bo qua', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild);
  store.config.automod.voice.kinds.soundboard = { count: 2, seconds: 20 };
  const vc = addChannel(guild, { name: 'General', type: 2 });
  const member = addMember(guild, { voiceChannelId: vc.id });
  const effect = (soundId) => ({ guild, userId: member.id, channelId: vc.id, soundId });

  await voiceProtection.handleVoiceChannelEffectSend(client, effect(null)); // chi la reaction emoji -> bo qua
  assert.equal(callsOf(guild, 'member.timeout').length, 0);

  await voiceProtection.handleVoiceChannelEffectSend(client, effect('sound-1'));
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'moi 1 lan phat, chua du nguong');
  await voiceProtection.handleVoiceChannelEffectSend(client, effect('sound-2'));
  assert.equal(callsOf(guild, 'member.timeout').length, 1, 'du 2 lan trong cua so -> bi phat');
});

test('tat theo doi 1 loai hanh vi (xoa khoi voice.kinds) -> khong dem, khong bao gio bi phat vi loai do nua', async () => {
  const { guild, client } = makeEnv();
  const store = enableVoice(guild);
  delete store.config.automod.voice.kinds.channelSwitch;
  const member = addMember(guild);
  const a = addChannel(guild, { name: 'A', type: 2 });
  const b = addChannel(guild, { name: 'B', type: 2 });

  for (let i = 0; i < 6; i++) {
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, a), makeVoiceState(member, b));
    await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, b), makeVoiceState(member, a));
  }
  assert.equal(callsOf(guild, 'member.timeout').length, 0, 'channelSwitch da bi tat bang /automod voice off');
});

test('cong tac tong automod.enabled = false -> Voice Protection khong lam gi ca (ke ca ghi log)', async () => {
  const { guild, client } = makeEnv();
  const store = core.load(guild.id);
  store.config.automod.enabled = false; // KHONG bat cong tac tong
  store.config.automod.voice.enabled = true;
  store.config.automod.voice.log = true;
  store.config.automod.voice.kinds.joinLeave = { count: 1, seconds: 30 };
  const logCh = addChannel(guild, { name: 'log', type: 0 });
  store.config.logChannelId = logCh.id;
  const member = addMember(guild);
  const vc = addChannel(guild, { name: 'General', type: 2 });

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(member, null), makeVoiceState(member, vc));
  assert.equal(callsOf(guild, 'channel.send').length, 0);
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
});

test('bo qua voiceStateUpdate cua chinh bot', async () => {
  const { guild, client, me } = makeEnv();
  const store = enableVoice(guild);
  store.config.automod.voice.kinds.joinLeave = { count: 1, seconds: 30 };
  const vc = addChannel(guild, { name: 'General', type: 2 });

  await voiceProtection.handleVoiceStateUpdate(client, makeVoiceState(me, null), makeVoiceState(me, vc));
  assert.equal(callsOf(guild, 'member.timeout').length, 0);
});

test('core.disconnectMember: ngat khoi kenh thoai hien tai (khac /kick: khong duoi khoi server) va tao case', async () => {
  const { guild } = makeEnv();
  const vc = addChannel(guild, { name: 'General', type: 2 });
  const member = addMember(guild, { voiceChannelId: vc.id });
  const mod = { id: '1', tag: 'mod1' };

  const c = await core.disconnectMember(guild, mod, member, 'test disconnect');
  assert.equal(callsOf(guild, 'member.voice.disconnect').length, 1);
  assert.equal(c.type, 'disconnect');
  assert.equal(member.voice.channelId, null, 'sau khi ngat thi khong con o kenh nao');
  assert.equal(callsOf(guild, 'member.kick').length, 0, 'khong duoi khoi server');

  const notInVoice = addMember(guild);
  const c2 = await core.disconnectMember(guild, mod, notInVoice, 'x');
  assert.equal(c2, null, 'khong dang trong kenh thoai nao thi khong co gi de ngat, khong tao case rac');
});

test('core.applyPunish: type=disconnect goi dung core.disconnectMember (dung chung giua automod tin nhan va Voice Protection)', async () => {
  const { guild, client } = makeEnv();
  const vc = addChannel(guild, { name: 'General', type: 2 });
  const member = addMember(guild, { voiceChannelId: vc.id });

  await core.applyPunish(client, guild, member, { type: 'disconnect' }, 'x');
  assert.equal(callsOf(guild, 'member.voice.disconnect').length, 1);
});
