'use strict';
// Chuyen huong require('discord.js') sang ban gia lap, va don du lieu test sau khi chay.
const Module = require('module');
const path = require('path');
const fs = require('fs');

const stub = path.join(__dirname, 'stubs', 'discord.js');
const orig = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === 'discord.js') return stub;
  return orig.call(this, request, ...rest);
};

// Moi guild dung trong test co ID bat dau bang "7777": xoa file du lieu cua chung khi ket thuc.
function cleanup() {
  for (const dir of ['guilds', 'mod']) {
    const d = path.join(__dirname, '..', 'data', dir);
    for (const f of fs.existsSync(d) ? fs.readdirSync(d) : []) if (f.startsWith('7777')) fs.rmSync(path.join(d, f), { force: true });
  }
}
process.on('exit', cleanup);
cleanup();

module.exports = { cleanup };
