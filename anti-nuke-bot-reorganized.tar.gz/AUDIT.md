# Báo cáo rà soát codebase

Phạm vi: toàn bộ 41 file của bản gốc (`anti-nuke-bot.zip`). Mỗi mục ghi **lỗi → hậu quả → cách sửa → test chứng minh**. Mức độ: 🔴 nghiêm trọng (bị lợi dụng để nuke / mất dữ liệu), 🟠 cao (bỏ sót hoặc phạt nhầm), 🟡 trung bình/nhỏ.

Phương pháp kiểm chứng: với các lỗi quan trọng, mình **chèn lại lỗi cũ vào code mới (mutation)** và xác nhận test tương ứng đỏ, rồi khôi phục — nghĩa là test thực sự bắt được lỗi, không phải test "xanh giả".

## A. Lỗ hổng cho phép qua mặt hoặc vô hiệu hóa anti-nuke

| # | Mức | Lỗi (bản gốc) | Hậu quả | Sửa |
|---|---|---|---|---|
| A1 | 🔴 | `/antinuke` chỉ dựa vào `setDefaultMemberPermissions(Administrator)` — đây chỉ là mặc định phía client, admin chỉnh lại được, và **mọi admin** đều dùng được | Đúng mô hình đe dọa của anti-nuke (admin bị chiếm/phản bội): tự `whitelist add-user` mình, `toggle` tắt module hoặc `config limit:100`, rồi nuke thoải mái | Lệnh thay đổi chỉ cho **chủ server + người được ủy quyền** (`/antinuke owners`); admin thường chỉ xem. `owners add/remove` chỉ chủ server. → `commands.test.js` "PHAN QUYEN" |
| A2 | 🔴 | Lệnh moderation gọi `markTrusted` khiến anti-nuke **bỏ qua** ban/timeout do `/ban`, `/timeout` thực hiện (và audit log ghi "bot" — vốn luôn được miễn trừ) | Ai có quyền Ban Members (hoặc tài khoản mod bị chiếm) ban/kick/timeout hàng loạt **qua bot** mà không bị đếm; `/kick` còn không có đường theo dõi nào | Bỏ `markTrusted`. Lệnh moderation báo thẳng cho engine **kèm danh tính mod ra lệnh**; vượt ngưỡng thì mod bị xử lý và nạn nhân được unban. Automod/timer của chính bot không bị tính. → "TICH HOP: mod ban hang loat QUA BOT..." |
| A3 | 🔴 | Không có module cho **Kick** và **Prune** | Kick/prune hàng loạt hoàn toàn không bị phát hiện | Thêm `massKick`, `massPrune` |
| A4 | 🔴 | Whitelist theo role **chỉ kiểm tra member trong cache** | Người thuộc role tin cậy nhưng chưa được cache bị coi là không whitelist → bị **phạt nhầm** khi làm việc hợp lệ | `isWhitelisted` chuyển sang `async`, fetch member khi cần (có cache "vắng mặt" 10s để không spam API) → "whitelist: role whitelist van hieu luc..." |
| A5 | 🔴 | Nâng quyền từng chút: cấp role Admin cho tài khoản phụ dưới ngưỡng `massRoleAdd` (5/10s), chờ hết cửa sổ, lặp lại; hoặc gán role đang whitelist cho tài khoản phụ (kế thừa miễn trừ) | Tài khoản phụ có toàn quyền mà không bị đếm | Module mới `privilegeEscalation`: hoàn tác **ngay** mỗi lần cấp role nguy hiểm/role whitelist hoặc thêm quyền nguy hiểm cho role, rồi xử lý người cấp → "nang quyen: ..." |
| A6 | 🔴 | Snapshot 1 file, **ghi đè** mỗi 15 phút, không kiểm tra | Nuke xảy ra ngay trước lần chụp kế tiếp → snapshot tốt bị thay bằng trạng thái đã bị phá → `restore` "khôi phục" ra một server trống | Lịch sử tối đa 6 bản khác nhau; đóng băng khi bị tấn công; **đánh dấu NGHI VẤN** khi số mục tụt < 70% và trạng thái nghi vấn không tự "sạch" khi chụp lại; `restore` mặc định dùng bản tốt gần nhất → "DAU DOC snapshot" |
| A7 | 🟠 | Kẻ tấn công tiếp tục hành động trong lúc đang bị xử phạt (sự kiện đang bay) — bản cũ đếm lại từ đầu | Hành động đến muộn không bị hoàn tác cho tới khi lại đủ ngưỡng | **Cách ly 2 phút** sau xử phạt: mỗi hành động muộn bị hoàn tác ngay, thử cách ly lại tối đa 5s/lần → "sau khi bi xu phat..." |

## B. Phát hiện sai / bỏ sót (audit log)

| # | Mức | Lỗi | Hậu quả | Sửa |
|---|---|---|---|---|
| B1 | 🔴 | Với sự kiện **không có `targetId`** (guildUpdate, webhook, integration), nếu không có dòng nào trong 5 giây gần nhất thì `fetchLatestExecutor` vẫn lấy `entries.first()` — bỏ qua mốc thời gian | Có thể là dòng của **người khác, từ trước đó** → **phạt nhầm người vô tội** | Bỏ hẳn cơ chế tra audit log; dùng `guildAuditLogEntryCreate` — Discord đẩy sẵn executor chính xác |
| B2 | 🟠 | Chờ cố định 300ms rồi đọc 5 dòng gần nhất, không thử lại | Nuke nhanh > 5 hành động hoặc audit log chậm hơn 300ms → bỏ sót; mỗi kiểm tra tốn 1 request → dễ dính rate limit đúng lúc bị nuke | Sự kiện đẩy chủ động, không tốn request, độ trễ ≈ 0 |
| B3 | 🟠 | Chỉ theo dõi `ChannelOverwriteUpdate` | Tạo/xóa permission overwrite (ẩn/cho phép hàng loạt) không bị đếm | Gộp cả 3 loại overwrite vào `massPermissionChange` |
| B4 | 🟠 | `Partials.GuildMember` bật và `guildMemberUpdate` so `oldMember.roles` với `newMember.roles` | `oldMember` dạng partial có danh sách role rỗng → có thể bị tính là "vừa được cấp *mọi* role", và khi đạt ngưỡng việc hoàn tác sẽ gỡ **mọi role** của người đó | Bỏ partial; dùng trực tiếp `$add`/`$remove` trong audit entry → "classify" |

## C. Xử phạt & hoàn tác

| # | Mức | Lỗi | Sửa |
|---|---|---|---|
| C1 | 🔴 | `strip` báo "đã xử lý" ngay cả khi không gỡ được role nào (role cao hơn bot / role managed của bot) | `contain()` trả kết quả trung thực; strip thất bại → **leo thang kick**; bot tấn công → kick; alert ghi "Đã vô hiệu hóa: KHÔNG" + lỗi cụ thể → "contain: ..." (mutation đã xác nhận) |
| C2 | 🔴 | `handleAction` reset bộ đếm rồi `await` cả chuỗi `defang → phạt → gửi cảnh báo → hoàn tác` tuần tự; trong lúc chờ, các sự kiện đến tiếp lại đếm từ 0 và **có thể đạt ngưỡng lần nữa → xử phạt/khôi phục chồng nhau** | Quarantine đặt **đồng bộ** trước mọi `await` → đúng 1 lần xử phạt; cảnh báo và hoàn tác chạy song song → "dong thoi: 10 su kien..." (mutation đã xác nhận) |
| C3 | 🟠 | `applyPunishment` `return` sớm nếu `guild.members.fetch` không thấy người thực hiện (đã rời/bị kick giữa chừng) → **bỏ luôn cả bước hoàn tác** | Ban theo ID (không cần là member); hoàn tác luôn chạy |
| C4 | 🟠 | Thiếu hoàn tác cho: timeout, bot lạ, role bị sửa, kênh bị sửa, kênh/role/emoji/webhook/invite/thread do kẻ tấn công tạo | Bổ sung trong `mitigate.js` |
| C5 | 🟠 | Không có cách hoàn trả role khi phạt nhầm | Ghi nhớ role đã gỡ + `/antinuke unstrip` |
| C6 | 🟠 | Không có kênh log (hoặc kênh bị xóa/không gửi được) → cảnh báo **mất im lặng** | Rơi xuống DM chủ server (giới hạn 1/phút); `status` cảnh báo chưa đặt kênh log |

## D. Khôi phục (`backup.js`)

| # | Mức | Lỗi | Sửa |
|---|---|---|---|
| D1 | 🟠 | Khớp theo **tên** | 2 kênh trùng tên chỉ tạo lại 1; kênh bị **đổi tên** (con sống) bị tạo thêm bản sao. Nay khớp **ID trước**, rồi tên từng cái một → "2 kenh TRUNG TEN", "DOI TEN" (mutation đã xác nhận) |
| D2 | 🟠 | 2 lượt restore chạy chồng nhau (tự động + thủ công) tạo kênh/role trùng | Khóa theo guild + gộp yêu cầu sát nhau + 1 lượt quét dư → "CHAY DONG THOI" (mutation đã xác nhận) |
| D3 | 🟠 | Category tạo lại không nhận lại kênh con; overwrite trỏ tới ID role đã chết | Ánh xạ ID cũ → mới; gắn lại kênh mồ côi (kể cả khi cache còn `parentId` trỏ vào category đã chết) |
| D4 | 🟠 | Role tạo lại **không có thành viên** | Lưu role→thành viên trong snapshot và gán lại (chạy nền, 4 luồng, báo vào kênh log) |
| D5 | 🟡 | Kênh/role do chủ server **chủ động xóa** vẫn bị hồi sinh | `markLegitDelete` khi người được miễn trừ xóa |
| D6 | 🟡 | Ghi file đồng bộ, không nguyên tử | Ghi tạm + `rename` (`util/fsx.js`), debounce theo file |
| D7 | 🟡 | `snapshot interval` đổi phải khởi động lại bot | `reschedule` có hiệu lực ngay |

## E. Lưu trữ, bộ nhớ, tài nguyên

| # | Mức | Lỗi | Sửa |
|---|---|---|---|
| E1 | 🔴 | File cấu hình/`data/mod` hỏng bị **âm thầm thay bằng mặc định**, rồi lần lưu kế tiếp **ghi đè** → mất whitelist/toàn bộ case | File hỏng được đổi tên `*.corrupt-<ts>`, log lỗi rõ → "file ... bi hong" |
| E2 | 🟡 | Giá trị xấu trên đĩa (limit=0, punishment lạ, ID rác) được tin tưởng | `sanitizeModuleConfig`, kiểm tra snowflake, kẹp giá trị |
| E3 | 🟡 | Tracker: map lồng nhau không bao giờ xóa mục rỗng → rò rỉ bộ nhớ chậm theo số người từng thực hiện hành động | Dọn định kỳ 60s (`sweep`) |
| E4 | 🟡 | `slowmodeLast` (đổi theo **mỗi tin nhắn**) bị ghi ra đĩa cùng toàn bộ case/cấu hình, gọi `saveSoon` mỗi tin | Không ghi ra đĩa nữa |

## F. Lỗi triển khai khác

| # | Mức | Lỗi | Sửa |
|---|---|---|---|
| F1 | 🟡 | Bản gốc có **đúng 25** module và dùng `addChoices` — vừa khít giới hạn 25 của Discord, nên **thêm bất kỳ module nào sẽ làm `npm run deploy` thất bại** (bẫy tiềm ẩn; bản này thêm 3 module) | Chuyển sang autocomplete (kèm kiểm tra giá trị phía server) → "lenh khai bao hop le" |
| F2 | 🟠 | Timer tự unban/unmute bị **xóa ngay khi gặp 1 lỗi** (mạng chập chờn, rate limit) | Tempban thành vĩnh viễn, mute không bao giờ hết. Nay xếp lại với backoff (tối đa 6 lần); lỗi vĩnh viễn (10004/10007/10013/10026) mới bỏ → "TIMER" |
| F3 | 🟡 | Nhiều `/mute` đồng thời khi chưa có role Muted tạo ra **nhiều role "Muted"** | Dùng chung 1 lần tạo → "mute dong thoi" |
| F4 | 🟡 | Timeout đặt đúng 28 ngày (giới hạn tối đa của Discord) — nguy cơ bị từ chối nếu đồng hồ máy chủ bot nhanh hơn Discord vài giây | Cắt xuống 28 ngày − 1 phút (`util/constants.js`) |
| F5 | 🟡 | `i.member.roles.highest` gây `TypeError` nếu `i.member` là dạng API thô (hiếm: guild chưa được cache) | Kiểm tra trước khi dùng |
| F6 | 🟡 | `ephemeral: true` (đã bị discord.js coi là deprecated) ở khắp nơi; tên sự kiện `ready` đang được các bản 14.x mới chuyển sang `clientReady` | Dùng `MessageFlags.Ephemeral`, `Events.ClientReady` (không phụ thuộc tên cụ thể) |
| F7 | 🟡 | Việc tắt máy nằm trong `moderation/index.js` (tự `process.exit`), không có `unhandledRejection`/`uncaughtException` — một lỗi không bắt được có thể làm sập cả bot đang bảo vệ server | Một điểm tắt máy duy nhất trong `src/index.js` (cần thiết vì nay anti-nuke ghi file bất đồng bộ); thêm 2 trình xử lý lỗi toàn cục |
| F8 | 🟡 | Intent thừa (Webhooks, Emojis, Invites, Integrations) + partial | Bỏ; thêm `sweepers` cho tin nhắn và `allowedMentions` mặc định không ping |

## G. Vòng rà soát bổ sung (đợt 2)

Rà soát lại toàn bộ codebase (kể cả các file đã sửa ở đợt 1) sau khi đợt 1 đã qua 131 test. Phương pháp kiểm chứng giống hệt đợt 1 (chèn lại lỗi, xác nhận test đỏ, khôi phục).

| # | Mức | Lỗi | Hậu quả | Sửa |
|---|---|---|---|---|
| G1 | 🔴 | Lệnh gọi qua **prefix/tag bot** (`textCommands.js`) gán `i.memberPermissions = message.member.permissions` — đây là quyền **cấp guild** (theo role). Một slash command thật nhận được `i.memberPermissions` đã được Discord tính **theo từng kênh** (có áp dụng channel overwrite) | Mod bị **thu hồi quyền ở một kênh cụ thể** bằng permission overwrite (vd bị chặn Ban Members trong 1 kênh riêng) vẫn có thể **lách qua lệnh prefix/tag-bot đúng kênh đó** để ban/kick/timeout — slash command thật sẽ đúng bị chặn nhưng đường prefix thì không | Dùng `member.permissionsIn(channel)` thay vì `member.permissions` → khớp đúng hành vi slash command thật. Test dựng 1 kênh có overwrite chặn `BanMembers` của role mod: xác nhận `!ban` trong kênh đó bị từ chối còn ở kênh khác thì vẫn ban được bình thường → `textCommands.test.js` "quyen phai tinh THEO KENH" (mutation đã xác nhận: tắt fix thì test đỏ) |
| G2 | 🟡 | `flushAllSync()` (chạy khi tắt bot) có thể ghi **đồng bộ** đè lên đúng lúc một lần ghi **bất đồng bộ** khác cho cùng file còn đang dở (`job.writing === true`) — cả 2 dùng chung 1 tên file tạm (`<file>.<pid>.tmp`) | Race hiếm khi tắt bot đúng lúc đang debounce-ghi: 2 lần ghi cùng đụng vào 1 file tạm, rename có thể chồng nhau, tối đa dẫn đến mất đúng bản ghi cuối cùng (whitelist/case/cấu hình) | Tên file tạm nay **duy nhất cho mỗi lần ghi** (pid + timestamp + counter + hậu tố ngẫu nhiên) → loại bỏ hoàn toàn khả năng đụng tên |
| G3 | 🟠 | (Nối tiếp B3/mục "Chưa làm" ở trên) `massPermissionChange` cho permission overwrite theo kênh (`ChannelOverwriteCreate/Update/Delete`) chỉ **đếm + xử phạt**, chưa từng hoàn tác — kẻ tấn công ẩn/mở hàng loạt kênh bằng overwrite thì dù bị phạt, các overwrite vẫn giữ nguyên | `auditStream.js` nay ghi lại overwrite TRƯỚC/SAU (allow/deny) dựa vào `entry.extra.id/type` (theo tài liệu API chính thức của Discord); `mitigate.js` hoàn tác: overwrite mới tạo → xóa; overwrite bị xóa → tạo lại đúng giá trị cũ; overwrite bị sửa → trả về giá trị gốc (thử `create()`, không được thì `edit()`, không cần biết trước overwrite hiện có tồn tại hay không) → `core-logic.test.js` "ChannelOverwrite* ghi lai...", `engine.test.js` 3 test "sua permission overwrite hang loat" (mutation đã xác nhận cả 3) — **CHƯA kiểm chứng trên Discord thật** (xem lưu ý ở mục "Chưa làm" bên dưới, áp dụng y hệt cho mục này: giả định về hình dạng `entry.extra` dựa trên tài liệu, không phải bản thật) |

## Thay đổi hành vi bạn cần biết trước khi triển khai

1. **Admin thường không còn đổi được cấu hình anti-nuke** — chỉ chủ server và người bạn `/antinuke owners add`.
2. **`privilegeEscalation` bật mặc định**: mod *không whitelist* cấp role quyền cao sẽ bị hoàn tác + bị `strip`. Whitelist mod đáng tin hoặc tắt module.
3. **Mod ban/kick/timeout hàng loạt qua lệnh bot giờ bị đếm.** Mod hay dọn raid → whitelist.
4. **Bot vượt ngưỡng bị kick** (thay vì "strip" vô nghĩa). Bot tin cậy (MEE6, Carl-bot…) → `/antinuke whitelist add-bot`.
5. Snapshot tự nâng định dạng (v2); snapshot cũ vẫn dùng được nhưng không có ID nên chỉ khớp theo tên — chụp lại bằng `/antinuke backup now`.
6. Cần **chạy lại `npm run deploy`** (có lệnh con mới) và cấp bot quyền **View Audit Log**.

## Chưa làm / khuyến nghị tiếp theo

- **Chưa chạy trên Discord thật.** Toàn bộ kiểm chứng là `node --check` + 136 test trên bản giả lập discord.js (môi trường không có mạng, `test/stubs/discord.js`). Bản giả lập phản ánh hiểu biết của mình về API nên **không bắt được** chỗ mình hiểu sai API thật — hãy thử trên server thử nghiệm với tài khoản phụ. Đặc biệt để ý mục G3 (hoàn tác permission overwrite): giả định `entry.extra.id`/`entry.extra.type`/`entry.extra.roleName` dựa trên tài liệu API chính thức của Discord (`options.id`/`options.type`/`options.role_name`) chứ chưa đối chiếu trực tiếp với dữ liệu `guildAuditLogEntryCreate` thật của discord.js — nếu tên trường thật khác đi, phần hoàn tác sẽ chỉ lặng lẽ không chạy (không throw, không ảnh hưởng phần đếm + xử phạt vốn đã hoạt động từ đợt 1), nên rủi ro nếu sai là **không mất chức năng sẵn có**, chỉ là chưa có thêm chức năng mới.
- Chưa có ngưỡng **tổng hợp xuyên module** (vd 2 xóa kênh + 2 xóa role + 2 ban mỗi thứ dưới ngưỡng riêng vẫn lọt). Có thể thêm bộ đếm chung cho mỗi người.
- Snapshot thành viên-role chỉ khi server ≤ 50.000 thành viên và cache thành viên đầy đủ.
- Chủ server / tài khoản whitelist bị chiếm thì bot không chặn được (mô hình tin cậy) — bật 2FA và giữ whitelist ngắn.
